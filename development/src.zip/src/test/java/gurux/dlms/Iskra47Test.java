//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.Conformance;
import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.ObjectType;
import gurux.dlms.enums.ServiceClass;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.objects.GXDLMSObjectCollection;
import gurux.dlms.objects.GXDLMSProfileGeneric;
import gurux.dlms.objects.GXDLMSRegister;

public class Iskra47Test {
    private GXDLMSClient target = null;

    public Iskra47Test() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress((short) 0x1);
        target.setClientAddress((short) 0x64);
        target.setUseLogicalNameReferencing(true);
        target.setInterfaceType(InterfaceType.WRAPPER);
        target.setServiceClass(ServiceClass.UN_CONFIRMED);
        target.getProposedConformance().remove(Conformance.GENERAL_PROTECTION);
        target.getProposedConformance().add(Conformance.EVENT_NOTIFICATION);
        target.getProposedConformance()
                .add(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_GET);
        target.getProposedConformance()
                .add(Conformance.PRIORITY_MGMT_SUPPORTED);
    }

    @After
    public final void tearDown() {
    }

    /**
     * A test for AARQ Request
     */
    @Test
    public final void aarqRequestTest() {
        byte[] expected = Helpers2.getMessage("/Iskra-47/AARQRequest.txt");
        target.setAuthentication(Authentication.LOW);
        try {
            target.setPassword("12345678".getBytes("ASCII"));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e.getMessage());
        }
        byte[] actual = target.aarqRequest()[0];

        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for AARE Response
     */
    @Test
    public final void aareResponseTest() {
        byte[] data = Helpers2.getMessage("/Iskra-47/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());
    }

    /**
     * A test for LNSettings
     */
    @Test
    public final void lnSettingsTest() {
        byte[] data = Helpers2.getMessage("/Iskra-47/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.ACTION));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_ACTION));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_GET));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_SET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.EVENT_NOTIFICATION));
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.GET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_GET_OR_READ));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.MULTIPLE_REFERENCES));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.PRIORITY_MGMT_SUPPORTED));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.SELECTIVE_ACCESS));
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.SET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_SET_OR_WRITE));
    }

    /**
     * A test for clock read request.
     */
    @Test
    public final void clockReadTest() {
        byte[] expected = { (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x64,
                (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x0d, (byte) 0xc0,
                (byte) 0x01, (byte) 0x81, (byte) 0x00, (byte) 0x08, (byte) 0x00,
                (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x00, (byte) 0xff,
                (byte) 0x02, (byte) 0x00 };
        byte[] actual = target.read("0.0.1.0.0.255", ObjectType.CLOCK, 2)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for clock read response.
     */
    @Test
    public final void clockReadReplyTest() {
        GXReplyData info = new GXReplyData();
        byte[] expected = new byte[] { (byte) 0x00, (byte) 0x01, (byte) 0x00,
                (byte) 0x01, (byte) 0x00, (byte) 0x64, (byte) 0x00, (byte) 0x12,
                (byte) 0xc4, (byte) 0x01, (byte) 0x40, (byte) 0x00, (byte) 0x09,
                (byte) 0x0c, (byte) 0x07, (byte) 0xda, (byte) 0x0a, (byte) 0x04,
                (byte) 0x01, (byte) 0x09, (byte) 0x36, (byte) 0x3b, (byte) 0x00,
                (byte) 0xFF, (byte) 0x88, (byte) 0x00 };
        target.getData(expected, info);
        GXDateTime actual = (GXDateTime) GXDLMSClient
                .changeType((byte[]) info.getValue(), DataType.DATETIME);

        SimpleDateFormat sd = new SimpleDateFormat();
        assertEquals(
                sd.format(Helpers2.fromFinlandTime(2010, 10, 4, 9, 54, 59)),
                sd.format(actual.getCalendar().getTime()));
    }

    /**
     * A test for Get Objects Request
     */
    @Test
    public final void getObjectsTest() {
        byte[] expected = new byte[] { (byte) 0x00, (byte) 0x01, (byte) 0x00,
                (byte) 0x64, (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x0D,
                (byte) 0xC0, (byte) 0x01, (byte) 0x81, (byte) 0x00, (byte) 0x0F,
                (byte) 0x00, (byte) 0x00, (byte) 0x28, (byte) 0x00, (byte) 0x00,
                (byte) 0xFF, (byte) 0x02, (byte) 0x00 };
        byte[] actual = (byte[]) target.getObjectsRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for read rows by entry message.
     */
    @Test
    public final void readRowsByEntry() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra-47/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/Iskra-47/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), false);

        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "00 01 00 64 00 01 00 20 C0 01 81 00 07 00 00 15 00 00 FF "
                        + "02 01 02 02 04 06 00 00 00 00 06 00 00 00 01 12 00 01 12 00 00 ");
        // CHECKSTYLE:ON
        GXDLMSProfileGeneric pg = (GXDLMSProfileGeneric) objects
                .getObjects(ObjectType.PROFILE_GENERIC).get(0);
        byte[] actual = target.readRowsByEntry(pg, 0, 1)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for read rows by range message.
     */
    @Test
    public final void readRowsByRange() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra-47/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/Iskra-47/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), false);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "00 01 00 64 00 01 00 40 C0 01 81 00 07 00 00 15 00 00 FF 02 01 01 02 04 02 04 12 00 08 09 06 00 00 01 00 00 FF 0F 02 12 00 00 09 0C 07 D0 07 01 FF 00 00 00 FF FF 88 80 09 0C 07 E5 01 01 FF 00 00 00 FF FF 88 80 01 00");
        // CHECKSTYLE:ON
        TimeZone fi;
        fi = TimeZone.getTimeZone("Europe/Helsinki");
        java.util.Calendar start = java.util.Calendar.getInstance(fi);
        // Summer time.
        start.set(2000, 6, 1, 0, 0, 0);
        // Winter time.
        java.util.Calendar end = java.util.Calendar.getInstance(fi);
        end.set(2020, 11, 31, 24, 0, 0);
        GXDLMSProfileGeneric pg = (GXDLMSProfileGeneric) objects
                .getObjects(ObjectType.PROFILE_GENERIC).get(0);
        pg.setSortObject(new GXDLMSClock("0.0.1.0.0.255"));
        byte[] actual = target.readRowsByRange(pg, start, end)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A action test.
     */
    @Test
    public final void actionTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra-47/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/Iskra-47/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), false);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "00 01 00 64 00 01 00 0F C3 01 81 00 03 00 00 80 08 00 FF 01 01 0F 00");
        // CHECKSTYLE:ON
        GXDLMSRegister register =
                (GXDLMSRegister) objects.getObjects(ObjectType.REGISTER).get(0);
        byte[] actual = target.method(register, 1, 0, DataType.INT8)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Parse Objects.
     */
    @Test
    public final void parseObjectsTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra-47/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());
        byte[] data = Helpers2.getMessage("/Iskra-47/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), false);
        assertEquals(401, objects.size());
    }

    /**
     * A test for Parse Objects.
     */
    @Test
    public final void parseObjectsMessagesTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra-47/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        String[] messages =
                Helpers2.getMessages("/Iskra-47/ParseObjectsMessages.txt");
        int cnt = messages.length;
        info.clear();
        info.setPeek(true);
        for (int pos = 0; pos < cnt; pos += 2) {
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            assertEquals(401, info.getTotalCount());
            assertTrue(0 != info.getCount());
            if (info.isMoreData()) {
                target.receiverReady(info.getMoreData());
            }
        }
        GXDLMSObjectCollection objects =
                target.parseObjects(info.getData(), true);
        assertEquals(401, objects.size());

        info.clear();
        TestServer server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        server.getItems().clear();
        server.getItems().addAll(objects);
        server.initialize();
        byte[] data = target.aarqRequest()[0];
        byte[] reply = server.handleRequest(data);
        target.getData(reply, info);
        target.parseAareResponse(info.getData());

        server.getLimits().setMaxInfoRX(target.getLimits().getMaxInfoTX());
        server.getLimits().setMaxInfoTX(target.getLimits().getMaxInfoRX());
        server.setMaxReceivePDUSize(1024);
        info.clear();
        data = target.getObjectsRequest();
        do {
            reply = server.handleRequest(data);
            target.getData(reply, info);
            if (info.isMoreData()) {
                data = target.receiverReady(info.getMoreData());
            }
        } while (info.isMoreData());
        GXDLMSObjectCollection objects2 =
                target.parseObjects(info.getData(), false);
        assertEquals(401, objects2.size());
    }

    /**
     * Server initial function test.
     */
    @Test
    public final void serverConnectionTest() {
        GXReplyData info = new GXReplyData();
        TestServer server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        GXDLMSClock clock = new GXDLMSClock("0.0.1.0.0.255");
        server.getItems().add(clock);
        server.initialize();
        byte[] data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        info.clear();
        /*
         * data = target.disconnectedModeRequest(); data =
         * server.handleRequest(data); target.getData(data, info); info.clear();
         */
        data = target.disconnectRequest();
        data = server.handleRequest(data);
        target.getData(data, info);
    }

    /**
     * A test server send all objects..
     */
    @Test
    public final void serverObjectsMessagesTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra-47/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        String[] messages =
                Helpers2.getMessages("/Iskra-47/ParseObjectsMessages.txt");
        int cnt = messages.length;
        info.clear();
        info.setPeek(true);
        for (int pos = 0; pos < cnt; pos += 2) {
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            assertEquals(401, info.getTotalCount());
            assertTrue(0 != info.getCount());
            if (info.isMoreData()) {
                target.receiverReady(info.getMoreData());
            }
        }
        GXDLMSObjectCollection objects =
                target.parseObjects(info.getData(), false);
        assertEquals(401, objects.size());

        info.clear();
        TestServer server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        server.getItems().clear();
        server.getItems().addAll(objects);
        server.initialize();
        byte[] data = target.aarqRequest()[0];
        byte[] reply = server.handleRequest(data);
        target.getData(reply, info);
        target.parseAareResponse(info.getData());
        // Get objects from the server.
        server.setMaxReceivePDUSize(1024);
        info.clear();
        data = target.getObjectsRequest();
        do {
            reply = server.handleRequest(data);
            target.getData(reply, info);
            if (info.isMoreData()) {
                data = target.receiverReady(info.getMoreData());
            }
        } while (info.isMoreData());
        GXDLMSObjectCollection objects2 =
                target.parseObjects(info.getData(), false);
        assertEquals(401, objects2.size());
    }

    /**
     * A test for Get Profile Generic columns.
     */
    @Test
    public final void getProfileGenericColumnsTest() {
        byte[] expected = { (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x64,
                (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x0d, (byte) 0xc0,
                (byte) 0x01, (byte) 0x81, (byte) 0x00, (byte) 0x07, (byte) 0x01,
                (byte) 0x00, (byte) 0x63, (byte) 0x62, (byte) 0x00, (byte) 0xff,
                (byte) 0x03, (byte) 0x00 };
        target.setServiceClass(ServiceClass.UN_CONFIRMED);
        byte[] actual = target.read("1.0.99.98.0.255",
                ObjectType.PROFILE_GENERIC, 3)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for parse Profile Generic columns.
     */
    @Test
    public final void parseProfileGenericColumnsTest() {
        GXReplyData info = new GXReplyData();
        byte[] reply = { (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x01,
                (byte) 0x00, (byte) 0x64, (byte) 0x00, (byte) 0x2a, (byte) 0xc4,
                (byte) 0x01, (byte) 0x40, (byte) 0x00, (byte) 0x01, (byte) 0x02,
                (byte) 0x02, (byte) 0x04, (byte) 0x12, (byte) 0x00, (byte) 0x08,
                (byte) 0x09, (byte) 0x06, (byte) 0x00, (byte) 0x00, (byte) 0x01,
                (byte) 0x00, (byte) 0x00, (byte) 0xff, (byte) 0x0f, (byte) 0x02,
                (byte) 0x12, (byte) 0x00, (byte) 0x00, (byte) 0x02, (byte) 0x04,
                (byte) 0x12, (byte) 0x00, (byte) 0x01, (byte) 0x09, (byte) 0x06,
                (byte) 0x01, (byte) 0x00, (byte) 0x60, (byte) 0xf1, (byte) 0x00,
                (byte) 0xff, (byte) 0x0f, (byte) 0x02, (byte) 0x12, (byte) 0x00,
                (byte) 0x00 };
        target.getData(reply, info);
        GXDLMSProfileGeneric p = new GXDLMSProfileGeneric();
        ValueEventArgs e = new ValueEventArgs(p, 3, 0, null);
        e.setValue(info.getValue());
        p.setValue(target.getSettings(), e);
        assertEquals(2, p.getCaptureObjects().size());
    }
}
