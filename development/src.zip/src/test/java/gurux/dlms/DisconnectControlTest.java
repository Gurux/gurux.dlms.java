//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.InterfaceType;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSDisconnectControl;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.enums.ControlMode;
import gurux.dlms.objects.enums.ControlState;

/**
 * @author Gurux Ltd
 */
public class DisconnectControlTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData reply = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, reply);
        reply.clear();
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, reply);
        reply.clear();
        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, reply);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, reply.getValue());
    }

    /**
     * A test for logical name (1st) attribute of DisconnectControl Object.
     */
    @Test
    public final void disconnectControlAttribute1Test() {
        String expected = "1.1.1.1.1.255";
        GXDLMSDisconnectControl item = new GXDLMSDisconnectControl(expected);
        assertEquals(expected, readTest(item, 1));
    }

    /**
     * A test for Value (2th) attribute of DisconnectControl Object.
     */
    @Test
    public final void disconnectControlAttribute2Test() {
        boolean expected = true;
        GXDLMSDisconnectControl item =
                new GXDLMSDisconnectControl("1.1.1.1.1.255");
        item.setOutputState(expected);
        readTest(item, 2);
        assertEquals(expected, item.getOutputState());
    }

    /**
     * A test for Value (3rd) attribute of DisconnectControl Object.
     */
    @Test
    public final void disconnectControlAttribute3Test() {
        ControlState expected = ControlState.READY_FOR_RECONNECTION;
        GXDLMSDisconnectControl item =
                new GXDLMSDisconnectControl("1.1.1.1.1.255");
        item.setControlState(expected);
        readTest(item, 3);
        assertEquals(expected, item.getControlState());
    }

    /**
     * A test for Value (4th) attribute of DisconnectControl Object.
     */
    @Test
    public final void disconnectControlAttribute4Test() {
        ControlMode expected = ControlMode.MODE_6;
        GXDLMSDisconnectControl item =
                new GXDLMSDisconnectControl("1.1.1.1.1.255");
        item.setControlMode(expected);
        readTest(item, 4);
        assertEquals(expected, item.getControlMode());
    }
}
