//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectCollection;
import gurux.dlms.objects.GXDLMSRegister;

/**
 * @author Gurux Ltd
 */
public class AssociationLogicalNameTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData reply = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, reply);
        reply.clear();
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, reply);
        reply.clear();
        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, reply);
        while (reply.isMoreData()) {
            buff = server
                    .handleRequest(target.receiverReady(reply.getMoreData()));
            target.getData(buff, reply);
        }
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, reply.getValue());
    }

    /**
     * A test for logical name (1st) attribute of association logical name
     * Object.
     */
    @Test
    public final void associationLogicalNameAttribute1Test() {
        String expected = "1.1.1.1.1.255";
        GXDLMSAssociationLogicalName item = new GXDLMSAssociationLogicalName();
        item.setLogicalName(expected);
        assertEquals(expected, readTest(item, 1));
    }

    /**
     * A test for object list (2th) attribute of association logical name
     * Object.
     */
    @Test
    public final void associationLogicalNameAttribute2Test() {
        GXDLMSObjectCollection list = new GXDLMSObjectCollection(target);
        GXDLMSRegister expected = new GXDLMSRegister("0.0.1.0.0.255");
        GXDLMSAssociationLogicalName item = new GXDLMSAssociationLogicalName();
        server.getItems().add(expected);
        list.add(expected);
        server.initialize();
        item.setObjectList(list);
        readTest(item, 2, false);
        assertEquals(2, item.getObjectList().size());
    }

    /**
     * A test for associated partners id (3rd) attribute of association logical
     * name Object.
     */
    @Test
    public final void associationLogicalNameAttribute3Test() {
        GXDLMSRegister expected = new GXDLMSRegister("0.0.1.0.0.255");
        GXDLMSAssociationLogicalName item = new GXDLMSAssociationLogicalName();
        server.getItems().add(expected);
        item.getObjectList().add(expected);
        readTest(item, 3, false);
        assertEquals(1, item.getObjectList().size());
    }

    /**
     * A test for changing LLS password.
     */
    @Test
    public final void llsChangeTest() {
        byte[] expected = "ABCDEFGH".getBytes();
        GXReplyData data = new GXReplyData();
        GXDLMSAssociationLogicalName item = new GXDLMSAssociationLogicalName();
        server.getItems().add(item);
        server.initialize();
        target.setPassword("Gurux".getBytes());
        target.setAuthentication(Authentication.LOW);
        GXByteBuffer tmp =
                new GXByteBuffer(server.handleRequest(target.snrmRequest()));
        target.getData(tmp, data);
        target.parseUAResponse(data.getData());
        tmp = new GXByteBuffer(server.handleRequest(target.aarqRequest()[0]));
        data.clear();
        target.getData(tmp, data);
        target.parseAareResponse(data.getData());
        item.setSecret(expected);
        byte[][] buff = target.write(item, 7);
        tmp = new GXByteBuffer(server.handleRequest(buff[0]));
        data.clear();
        target.getData(tmp, data);
        // Read LLS secret again.
        item = new GXDLMSAssociationLogicalName();
        buff = target.read(item, 7);
        tmp = new GXByteBuffer(server.handleRequest(buff[0]));
        data.clear();
        target.getData(tmp, data);
        assertEquals(GXCommon.toHex(expected),
                GXCommon.toHex((byte[]) data.getValue()));

        server.handleRequest(target.disconnectRequest());
        // Connect again using new password.
        target.setPassword(expected);
        tmp = new GXByteBuffer(server.handleRequest(target.snrmRequest()));
        target.getData(tmp, data);
        target.parseUAResponse(data.getData());
        tmp = new GXByteBuffer(server.handleRequest(target.aarqRequest()[0]));
        data.clear();
        target.getData(tmp, data);
        target.parseAareResponse(data.getData());
    }
}
