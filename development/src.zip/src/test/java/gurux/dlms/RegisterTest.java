//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.Unit;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectCollection;
import gurux.dlms.objects.GXDLMSRegister;

/**
 * @author Gurux Ltd
 */
public class RegisterTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient(true, 16, 1, Authentication.NONE, null,
                InterfaceType.WRAPPER);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = target.read(item, index);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, info.getValue());
    }

    /**
     * A test for Logical Name (1st) attribute of Register Object.
     */
    @Test
    public final void registerAttribute1Test() {
        String expected = "1.1.1.1.1.255";
        GXDLMSRegister item = new GXDLMSRegister(expected);
        assertEquals(expected, readTest(item, 1));
    }

    /**
     * A test for value (2th) attribute of Register Object.
     */
    @Test
    public final void registerAttribute2Test() {
        String expected = "Gurux";
        GXDLMSRegister item = new GXDLMSRegister("1.1.1.1.1.255");
        item.setValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for scaler and unit (3rt) attribute of Register Object.
     */
    @Test
    public final void registerAttribute3Test() {
        GXDLMSRegister item = new GXDLMSRegister("1.1.1.1.1.255");
        item.setScaler(0.01);
        item.setUnit(Unit.CURRENT);
        readTest(item, 3);
        assertEquals("0.01", String.valueOf(item.getScaler()));
        assertEquals(Unit.CURRENT, item.getUnit());
    }

    /**
     * A test for reset (1st) method of Register Object.
     */
    @Test
    public final void registerMethod1Test() {
        GXDLMSObjectCollection coll = new GXDLMSObjectCollection(target);
        GXDLMSRegister item = new GXDLMSRegister("1.1.1.1.1.255");
        item.setValue("Gurux Ltd");
        coll.add(item);
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = item.reset(target);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        assertEquals(null, item.getValue());
    }
}
