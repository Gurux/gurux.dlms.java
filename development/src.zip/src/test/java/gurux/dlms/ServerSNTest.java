//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.Unit;
import gurux.dlms.objects.GXDLMSAssociationShortName;
import gurux.dlms.objects.GXDLMSData;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectCollection;
import gurux.dlms.objects.GXDLMSRegister;

/**
 * @author Gurux Ltd
 */
public class ServerSNTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    private void init() {
        server.initialize();
        GXReplyData info = new GXReplyData();
        byte[] data = server.handleRequest(target.snrmRequest());
        target.getData(data, info);
        target.parseUAResponse(info.getData());
        info.clear();
        data = server.handleRequest(target.aarqRequest()[0]);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        info.clear();
        data = server.handleRequest(target.getObjectsRequest());
        target.getData(data, info);
        target.parseObjects(info.getData(), true);
    }

    @Before
    public final void setUp() {
        server = new TestServer(new GXDLMSAssociationShortName(),
                InterfaceType.HDLC);
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
    }

    @After
    public void tearDown() {
    }

    /**
     * A test for Server data object attribute index 1 read.
     */
    @Test
    public final void dataReadAtt1Test() {
        GXReplyData info = new GXReplyData();
        GXDLMSData item = new GXDLMSData("1.2.3.4.5.6");
        server.getItems().add(item);
        init();
        byte[] data = target.read(item, 1)[0];
        data = server.handleRequest(data);
        target.getData(data, info);
        String ln = GXDLMSClient
                .changeType((byte[]) GXDLMSClient.getValue(info.getData()),
                        DataType.OCTET_STRING)
                .toString();
        assertEquals(item.getLogicalName(), ln);
    }

    /**
     * A test for Server data object attribute index 1 read.
     */
    @Test
    public final void dataWriteAtt2Test() {
        GXReplyData info = new GXReplyData();
        GXDLMSData item = new GXDLMSData("1.2.3.4.5.6");
        item.setValue(123);
        server.getItems().add(item);
        init();
        byte[] data = target.write(item, 2)[0];
        data = server.handleRequest(data);
        target.getData(data, info);
        data = target.read(item, 2)[0];
        data = server.handleRequest(data);
        info.clear();
        target.getData(data, info);
        assertEquals(123, info.getValue());
    }

    /**
     * A test for Server register object attribute index 3 read.
     */
    @Test
    public final void registerReadAtt3Test() {
        GXReplyData info = new GXReplyData();
        GXDLMSRegister item = new GXDLMSRegister("1.2.3.4.5.6");
        item.setScaler(10);
        item.setUnit(Unit.ACTIVE);
        server.getItems().add(item);
        init();
        byte[] data = target.read(item, 3)[0];
        data = server.handleRequest(data);
        target.getData(data, info);
        Object[] scalerUnit = (Object[]) GXDLMSClient.getValue(info.getData());
        assertEquals((int) item.getScaler(),
                (int) Math.pow(10, ((Number) scalerUnit[0]).intValue()));
        assertEquals(item.getUnit().getValue(),
                ((Number) scalerUnit[1]).intValue());
    }

    /**
     * A test for server list read.
     */
    @Test
    public final void serverListRead() {
        List<Entry<GXDLMSObject, Integer>> list =
                new ArrayList<Entry<GXDLMSObject, Integer>>();
        GXReplyData info = new GXReplyData();
        GXDLMSData item = new GXDLMSData("0.0.0.0.0.0", 200);
        server.getItems().add(item);
        init();
        byte[] data = target.getObjectsRequest();
        data = server.handleRequest(data);
        target.getData(data, info);
        GXDLMSObjectCollection objs =
                target.parseObjects(info.getData(), false);
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(0), 1));
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(0), 1));
        data = target.readList(list)[0];
        data = server.handleRequest(data);
        info.clear();
        target.getData(data, info);
        List<Object> values = new ArrayList<Object>();
        values.addAll(Arrays.asList((Object[]) info.getValue()));
        target.updateValues(list, values);
    }
}
