//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.Conformance;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.Security;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.secure.GXDLMSSecureClient;

public class GloTest {
    private GXDLMSSecureClient target = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSSecureClient();
        target.setServerAddress(0x1);
        target.setClientAddress(0x1);
        target.setUseLogicalNameReferencing(true);
        target.setInterfaceType(InterfaceType.WRAPPER);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        target.getProposedConformance().remove(Conformance.GENERAL_PROTECTION);
        target.getProposedConformance()
                .add(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_GET);
        target.getProposedConformance()
                .add(Conformance.PRIORITY_MGMT_SUPPORTED);
        target.getProposedConformance().add(Conformance.EVENT_NOTIFICATION);
    }

    @After
    public final void tearDown() {
    }

    /*
     * A test for AARQ Request
     */
    @Test
    public final void aarqRequestTest() {
        // CHECKSTYLE:OFF
        byte[] expected = GXCommon.hexToBytes(
                "00010001000100576055A109060760857405080103A60A04084D4D4D0000BC614E8A0207808B0760857405080201AC0A80083132333435363738BE230421211F3001234567801212FF9D0558536827457AB8AE83BE3AB13B7ADE78EF2EE9BD");
        // CHECKSTYLE:ON
        target.setAuthentication(Authentication.LOW);
        target.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000BC614E"));
        target.getCiphering().setInvocationCounter(0x01234567);
        target.setMaxReceivePDUSize(1200);
        target.setCtoSChallenge(
                GXCommon.hexToBytes("00112233445566778899AABBCCDDEEFF"));
        target.setPassword("12345678".getBytes());
        byte[] actual = target.aarqRequest()[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for AARE Response
     */
    @Test
    public final void aareResponseTest() {
    }
}
