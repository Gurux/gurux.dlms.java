//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.crypto.KeyAgreement;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.asn.GXAsn1Converter;
import gurux.dlms.asn.GXPkcs10;
import gurux.dlms.asn.GXx509Certificate;
import gurux.dlms.asn.enums.KeyUsage;
import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.Conformance;
import gurux.dlms.enums.ErrorCode;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.Security;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.objects.GXDLMSSecuritySetup;
import gurux.dlms.objects.enums.CertificateType;
import gurux.dlms.objects.enums.GlobalKeyType;
import gurux.dlms.objects.enums.SecurityPolicy;
import gurux.dlms.objects.enums.SecurityPolicy1;
import gurux.dlms.objects.enums.SecuritySuite;
import gurux.dlms.secure.GXASymmetric;
import gurux.dlms.secure.GXDLMSSecureClient;

/*
 * @author Gurux Ltd
 */
public class SecuritySetupTest {
    private GXDLMSSecureClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSSecureClient(true, 16, 1, Authentication.NONE, null,
                InterfaceType.WRAPPER);
        target.getCiphering().setSecurity(Security.ENCRYPTION);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        server.setKek("Gurux000Gurux123".getBytes());
    }

    @After
    public final void tearDown() {
    }

    /*
     * A Global key transfer fail test.
     */
    @Test
    public final void failedGlobalKeyTransferTest() {
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] tmp;
        tmp = server.handleRequest(target.aarqRequest()[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());
        info.clear();
        List<GXSimpleEntry<GlobalKeyType, byte[]>> list =
                new ArrayList<GXSimpleEntry<GlobalKeyType, byte[]>>();
        list.add(new GXSimpleEntry<GlobalKeyType, byte[]>(
                GlobalKeyType.UNICAST_ENCRYPTION,
                "Gurux01234567890".getBytes()));
        byte[][] buff = item.globalKeyTransfer(target, server.getKek(), list);
        tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        assertEquals(ErrorCode.READ_WRITE_DENIED.getValue(), info.getError());
    }

    /*
     * A Global key transfer test.
     */
    @Test
    public final void globalKeyTransferTest() {
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] tmp;
        tmp = server.handleRequest(target.aarqRequest()[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());
        info.clear();
        List<GXSimpleEntry<GlobalKeyType, byte[]>> list =
                new ArrayList<GXSimpleEntry<GlobalKeyType, byte[]>>();
        list.add(new GXSimpleEntry<GlobalKeyType, byte[]>(
                GlobalKeyType.AUTHENTICATION, "Gurux01234567890".getBytes()));
        byte[][] buff = item.globalKeyTransfer(target, server.getKek(), list);
        tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
    }

    /*
     * A Global key transfer test.
     */
    @Test
    public final void globalKeyTransferServerTest() {
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] tmp;
        tmp = server.handleRequest(target.aarqRequest()[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());
        info.clear();
        List<GXSimpleEntry<GlobalKeyType, byte[]>> list =
                new ArrayList<GXSimpleEntry<GlobalKeyType, byte[]>>();
        list.add(new GXSimpleEntry<GlobalKeyType, byte[]>(
                GlobalKeyType.AUTHENTICATION, "Gurux01234567890".getBytes()));
        byte[][] buff = item.globalKeyTransfer(target, server.getKek(), list);
        tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
    }

    /*
     * Activate security policy for SecuritySetup version 0.
     */
    @Test
    public final void securityActivate0Test() {
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] tmp;
        tmp = server.handleRequest(target.aarqRequest()[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());
        info.clear();
        byte[][] buff =
                item.activate(target, SecurityPolicy.AUTHENTICATED_ENCRYPTED);
        tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        assertEquals(item.getSecurityPolicy(),
                SecurityPolicy.AUTHENTICATED_ENCRYPTED);
        // Read value.
        // Create new item for client.
        info.clear();
        item = new GXDLMSSecuritySetup();
        buff = target.read(item, 2);
        tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        target.updateValue(item, 2, info.getValue());
        assertEquals(0, info.getError());
        assertEquals(item.getSecurityPolicy(),
                SecurityPolicy.AUTHENTICATED_ENCRYPTED);
    }

    /*
     * Activate security policy for SecuritySetup version 1.
     */
    @Test
    public final void securityActivate1Test() {
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        item.setVersion(1);
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] tmp;
        tmp = server.handleRequest(target.aarqRequest()[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());
        info.clear();

        HashSet<SecurityPolicy1> sp = new HashSet<SecurityPolicy1>();
        sp.add(SecurityPolicy1.DIGITALLY_SIGNED_RESPONSE);
        sp.add(SecurityPolicy1.ENCRYPTED_RESPONSE);
        byte[][] buff = item.activate(target, sp);
        tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        assertTrue(item.getSecurityPolicy1()
                .contains(SecurityPolicy1.DIGITALLY_SIGNED_RESPONSE));
        assertTrue(item.getSecurityPolicy1()
                .contains(SecurityPolicy1.ENCRYPTED_RESPONSE));
    }

    /*
     * Activate security policy for SecuritySetup version 1.
     */
    @Test
    public final void digitalSignatureTest() throws Exception {
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        item.setVersion(1);
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] tmp;
        tmp = server.handleRequest(target.aarqRequest()[0]);
        target.getData(tmp, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());
        info.clear();
        // generate_key_pair
        tmp = item.generateKeyPair(target,
                CertificateType.DIGITAL_SIGNATURE)[0];
        tmp = server.handleRequest(tmp);
        info.clear();
        target.getData(tmp, info);
        // generate_certificate_request
        tmp = item.generateCertificate(target,
                CertificateType.DIGITAL_SIGNATURE)[0];
        tmp = server.handleRequest(tmp);
        info.clear();
        target.getData(tmp, info);
        // TODO: This is removed for now because all JVMs are not supporting
        // this.
        // PKCS10 request = new PKCS10((byte[]) info.getValue());
        // System.out.println(
        // Base64.getEncoder().encodeToString(request.getEncoded()));
        // // Use example this to convert to string.
        // // http://developerutils.com/CSRDecoder.php
        //
        // // Client public key.
        // PublicKey clientPublic =
        // GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
        // "917DBFECA43307375247989F07CC23F53D4B963AF8026C749DB"
        // + "33852011056DFDBE8327BD69CC149F018A8E446DD"
        // + "A6C55BCD78E596A56D403236233F93CC89B3"));
        // // Client private key.
        // PrivateKey clientPrivate = GXAsn1Converter.getPrivateKey(
        // GXCommon.hexToBytes("E9A045346B2057F1820318AB125493E9AB"
        // + "36CE590011C0FF30090858A118DD2E"));
        // // Server public key.
        // PublicKey serverPublic =
        // GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
        // "E4D07CEB0A5A6DA9D2228B054A1F5E295E1747A963974AF7509"
        // + "1A0B0BC2FB92DA7D2ABD9FDD41579F36A1C8171A0"
        // + "CB638221DF1949FD95C8FAE148896920450D"));
        // // Server private key.
        // PrivateKey serverPrivate = Helpers2
        // .getPrivateKey(GXCommon.hexToBytes("B582D8C910018302BA3131BAB9"
        // + "BB6838108BB9408C30B2E49285985256A59038"));
        //
        // KeyPair clientKp = new KeyPair(clientPublic, clientPrivate);
        // X509Certificate clientCertificate =
        // Helpers2.createSelfSignedCertificate(clientKp);
        // System.out.println(Base64.getEncoder()
        // .encodeToString(clientCertificate.getEncoded()));
        //
        // KeyPair serverKp = new KeyPair(serverPublic, serverPrivate);
        // X509Certificate serverCertificate =
        // Helpers2.createSelfSignedCertificate(serverKp);
        //
        // // import_certificate
        // tmp = item.importCertificate(target, serverCertificate)[0];
        // tmp = server.handleRequest(tmp);
        // info.clear();
        // target.getData(tmp, info);
        // // Get list of certificates.
        // tmp = target.read(item, 6)[0];
        // tmp = server.handleRequest(tmp);
        // info.clear();
        // target.getData(tmp, info);
        // target.updateValue(item, 6, info.getValue());
        // assertEquals(1, item.getCertificates().size());
        // GXDLMSCertificateInfo c = item.getCertificates().get(0);
        // tmp = item.removeCertificateBySerial(target, c.getSerialNumber(),
        // c.getIssuer())[0];
        // tmp = server.handleRequest(tmp);
        // info.clear();
        // target.getData(tmp, info);
    }

    /*
     * @return Client signing key pair from the Blue.
     */
    final KeyPair getClientTestSigningKeyPair()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        byte[] pk = GXCommon.hexToBytes(
                "BAAFFDE06A8CB1C9DAE8D94023C601DBBB249254BA22EDD827E820BCA2BCC64362FBB83D86A82B87BB8B7161D2AAB5521911A946B97A284A90F7785CD9047D25");
        PublicKey pubKc = GXAsn1Converter.getPublicKey(pk);
        PrivateKey priKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "418073C239FA6125011DE4D6CD2E645780289F761BB21BFB0835CB5585E8B373"));
        return new KeyPair(pubKc, priKc);
    }

    /*
     * @return Server signing key pair from the Blue book.
     */
    final KeyPair getServerTestSigningKeyPair()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        PrivateKey priKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "AE55414FFE079F9FC95649536BD1C2B5653D200813727E07D501A8B550C69207"));
        PublicKey pubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "933ACF15B03A9248E029B2787FB52A0AECAF635F07C42A0019FB3197E38F8F549A125EA36781B0CA96BE89A0E1FE2CF9B7361ED48B3C5E24592B9C0F4EDD31D1"));
        return new KeyPair(pubKs, priKs);
    }

    /*
     * @return Client key agreement key pair from the Blue book C. 2.
     */
    final KeyPair getClientTestKeyAgreementKeyPairC2()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        PublicKey aPubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "07C56DE2DCAF0FD793EF29F019C89B4A0CC1E001CE94F4FFBE10BC05E7E66F7671A13FBCF9E662B9826FFF6A6938546D524ED6D3405F020296BDE16B04F7A7C2"));
        PrivateKey aPrivKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "A51C16FF5C498FCC89323D4A9267CD71BF81FD6F6A891CD240DA7F3D6F283E65"));
        return new KeyPair(aPubKc, aPrivKc);
    }

    /*
     * @return Server key agreement key pair from the Blue book Table C. 2.
     */
    final KeyPair getServerTestKeyAgreementKeyPairC2()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        PublicKey aPubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "A653565B0E06070BAE9FBE140A5D2156812AEE2DD525053E3EFC850BF13BFDFFCB240BC7B77BFF5883344E7275908D2287BEFA3725017295A096989D2338290B"));
        PrivateKey aPrivKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "AAD3FD0732E991CF52A74C66C1F2827DDC53522A2E0A169D7C4FFCC0FB5D6A4D"));
        return new KeyPair(aPubKs, aPrivKs);
    }

    /*
     * @return Client ephemeral key pair from the Blue book Table C. 2.
     */
    final KeyPair getClientEphemeralKeyPairC2()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        // Ephemeral key pair Client.
        PrivateKey ePriKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "47DAB03842E5B6E74828EF4F449B378D7DD1A5DAE1FFCA5AE0B0BE0AD18EC57E"));
        PublicKey ePubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "C323C2BD45711DE4688637D919F92E9DB8FB2DFC213A88D21C9DC8DCBA917D8170511DE1BADB360D50058F794B0960AE11FA28D392CFF907A62D13E3357B1DC0"));
        return new KeyPair(ePubKc, ePriKc);
    }

    /*
     * @return Server ephemeral key pair from the Blue book Table C. 2.
     */
    final KeyPair getServerEphemeralKeyPairC2()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        PrivateKey ePriKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "819B1BEACC955E29139E368BF4119C126FF799EE16BCBA3F45C1EF16749BCB95"));
        PublicKey ePubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "6439724714B47CD9CB988897D8424AB946DCD083D37A954637616011B9C2378773295F0F850D8DAFD1BBE9FE666E53E4F097CD10B38B69622152724A90987444"));
        return new KeyPair(ePubKs, ePriKs);
    }

    /*
     * @return Client ephemeral key pair from the Blue book Table C. 1.
     */
    final KeyPair getClientEphemeralKeyPairC1()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        // Ephemeral key pair Client.
        PrivateKey ePriKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "1BAC19FC1D52A1E5102622EDFA36584C05E12FA8CDEAA450F2F1E9A7DCCF7628"));
        PublicKey ePubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "2914D60E10AB705F62ED6CC349D7CB99B9AB3F3978E59278C7AF595B3AF987941372DAB6D5AF1FA867E134167E6F23DE664A6693E05F43414611058D1B48F894"));
        return new KeyPair(ePubKc, ePriKc);
    }

    /*
     * @return Server ephemeral key pair from the Blue book Table C. 1.
     */
    final KeyPair getServerEphemeralKeyPairC1()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        PrivateKey ePriKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "34A8C23A34DBB519D09B245754C85A6CFE05D14A063EFA5AA41545AA8241EFAE"));
        PublicKey ePubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "95F41066009B185B074F5FFFF736B71C325FCADB2BC0CF1A4F4B17BBE7AB81D62946506BC8169C7B539B39A5D8463787F449C9BD2583FA67A1075B0DBFC638BA"));
        return new KeyPair(ePubKs, ePriKs);
    }

    /*
     * @return Client agreement key pair from the Blue book Table C. 3.
     */
    final KeyPair getClientAgreementKeyPairC3()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        // Private Key Agreement Key Client
        PrivateKey aPriKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "A51C16FF5C498FCC89323D4A9267CD71BF81FD6F6A891CD240DA7F3D6F283E65"));
        // Public Key Agreement Key Client
        PublicKey aPubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "07C56DE2DCAF0FD793EF29F019C89B4A0CC1E001CE94F4FFBE10BC05E7E66F7671A13FBCF9E662B9826FFF6A6938546D524ED6D3405F020296BDE16B04F7A7C2"));
        return new KeyPair(aPubKc, aPriKc);
    }

    /*
     * @return Server agreement key pair from the Blue book Table C. 3.
     */
    final KeyPair getServerAgreementKeyPairC3()
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        // Private Key Agreement Key Server
        PrivateKey aPriKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "AAD3FD0732E991CF52A74C66C1F2827DDC53522A2E0A169D7C4FFCC0FB5D6A4D"));
        // Public Key Agreement Key Server
        PublicKey aPubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "A653565B0E06070BAE9FBE140A5D2156812AEE2DD525053E3EFC850BF13BFDFFCB240BC7B77BFF5883344E7275908D2287BEFA3725017295A096989D2338290B"));
        return new KeyPair(aPubKs, aPriKs);

    }

    /*
     * Generate Ephemeral Public Key Signature Test
     */
    @Test
    public final void generateEphemeralSignatureTest() throws Exception {
        byte keyId = 0;
        KeyPair kc = getClientTestSigningKeyPair();
        KeyPair eKc = getClientEphemeralKeyPairC1();

        // byte[] expected = GXCommon.hexToBytes(
        // "06F0607702AA0E2435A183E2F6B1ECD19629712E389A213610C03F77B2590860EA840AF5C3FA1F2BCDF055D4744E9A01CE9A0E55026BCAA4EEBEB764CED64BB3");

        byte[] data = GXDLMSSecuritySetup.getEphemeralPublicKeyData(keyId,
                eKc.getPublic());
        byte[] sign = GXASymmetric.getEphemeralPublicKeySignature(keyId,
                eKc.getPublic(), kc.getPrivate());

        assertEquals(true, GXASymmetric.validateEphemeralPublicKeySignature(
                data, sign, kc.getPublic()));
    }

    /*
     * Static-Unified Model test.
     */
    @Test
    public final void staticUnifiedModelTest() throws Exception {
        // Use security suite 1.
        target.setSecuritySuite(SecuritySuite.ECDH_ECDSA_AES_GCM_128_SHA_256);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        // target.getNegotiatedConformance().add(Conformance.GENERAL_PROTECTION);

        target.getCiphering().getPublicKeys()
                .add(new GXSimpleEntry<CertificateType, PublicKey>(
                        CertificateType.KEY_AGREEMENT,
                        getServerAgreementKeyPairC3().getPublic()));

        target.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000BC614E"));
        target.getCiphering().setInvocationCounter(0x102030405060708L);
        target.getCiphering()
                .setKeyAgreementKeyPair(getClientAgreementKeyPairC3());
        target.getCiphering().setRecipientSystemTitle(
                GXCommon.hexToBytes("4D4D4D0000000001"));

        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        server.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000000001"));

        server.getCiphering()
                .setKeyAgreementKeyPair(getClientAgreementKeyPairC3());
        server.getCiphering().setInvocationCounter(0x0123456789012345L);

        server.getCiphering().getPublicKeys()
                .add(new GXSimpleEntry<CertificateType, PublicKey>(
                        CertificateType.KEY_AGREEMENT,
                        getServerAgreementKeyPairC3().getPublic()));

        GXDLMSClock clock = new GXDLMSClock();
        GXDLMSSecuritySetup ss = new GXDLMSSecuritySetup();
        server.getItems().add(clock);
        server.getItems().add(ss);
        server.initialize();
        byte[] data = server.handleRequest(target.read(clock, 2)[0]);
        GXReplyData reply = new GXReplyData();
        target.getData(data, reply);
        assertEquals(0, reply.getError());
    }

    /*
     * Key agreement test.
     */
    @Test
    public final void keyAgreementTest() throws Exception {
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        target.getProposedConformance().add(Conformance.GENERAL_PROTECTION);
        // Generate keys for the client.
        target.getCiphering().setSigningKeyPair(getClientTestSigningKeyPair());
        target.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000BC614E"));
        target.getCiphering().setRecipientSystemTitle(
                GXCommon.hexToBytes("4D4D4D0000000001"));

        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        server.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000000001"));
        target.getCiphering().setInvocationCounter(0x0123456789012345L);
        server.getCiphering().setInvocationCounter(0x0123456789012345L);
        GXDLMSClock clock = new GXDLMSClock();
        GXDLMSSecuritySetup ss = new GXDLMSSecuritySetup();
        server.getItems().add(clock);
        server.getItems().add(ss);
        server.initialize();
        GXReplyData info = new GXReplyData();
        byte[] reply = server.handleRequest(target.aarqRequest()[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());

        ////////////////////////////////////////////////////////////////
        // Generate signing keys.
        Date from = new Date();
        Date to = new Date(from.getTime() + 365L * 24L * 60L * 60L * 1000L);
        // Create client certificate for digital signature.
        GXx509Certificate certificate =
                GXx509Certificate.createSelfSignedCertificate(
                        target.getCiphering().getSigningKeyPair(), from, to,
                        target.getCiphering().getSystemTitle(),
                        "CN=Test, O=Gurux, L=Tampere, C=FI", KeyUsage.forValue(
                                (KeyUsage.DIGITAL_SIGNATURE.getValue())));

        // Send client's digital signature to the server.
        reply = server
                .handleRequest(ss.importCertificate(target, certificate)[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
        ////////////////////////////////////////////////////////////////
        // Create server certificate and export it.
        reply = server.handleRequest(ss.generateKeyPair(target,
                CertificateType.DIGITAL_SIGNATURE)[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
        // Note! This is not used. We are using signing key pair from Green Book
        // C1.
        server.getCiphering().setSigningKeyPair(getServerTestSigningKeyPair());

        reply = server.handleRequest(ss.generateCertificate(target,
                CertificateType.DIGITAL_SIGNATURE)[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
        GXPkcs10 cert = new GXPkcs10((byte[]) info.getValue());

        certificate = GXx509Certificate.createSelfSignedCertificate(
                server.getCiphering().getSigningKeyPair(), from, to,
                cert.getSubject(), "CN=Test, O=Gurux, L=Tampere, C=FI",
                KeyUsage.forValue((KeyUsage.DIGITAL_SIGNATURE.getValue())));

        // Send server's digital signature to the server.
        reply = server
                .handleRequest(ss.importCertificate(target, certificate)[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());

        // Export server's certificate.
        reply = server.handleRequest(target.getServerCertificate(ss,
                CertificateType.DIGITAL_SIGNATURE)[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
        certificate = new GXx509Certificate((byte[]) info.getValue());

        // Disconnect.
        reply = server.handleRequest(target.disconnectRequest());
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());

        /////////////////////////////////////////////////////////////////
        // Change security suite 1 after signature is sent to the server.
        target.setSecuritySuite(SecuritySuite.ECDH_ECDSA_AES_GCM_128_SHA_256);
        reply = server.handleRequest(target.aarqRequest()[0]);
        // target.getCiphering().getPublicKeys()
        // .add(new GXSimpleEntry<CertificateType, PublicKey>(
        // CertificateType.DIGITAL_SIGNATURE,
        // cert.getPublicKey()));

        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
        target.parseAareResponse(info.getData());
        // Generate client's Ephemeral keys and send it to the server.
        target.getCiphering()
                .setEphemeralKeyPair(getClientEphemeralKeyPairC1());
        server.getCiphering()
                .setEphemeralKeyPair(getServerEphemeralKeyPairC1());
        reply = server.handleRequest(
                ss.keyAgreement(target, GlobalKeyType.UNICAST_ENCRYPTION)[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
        target.getSharedSecret((byte[]) info.getValue(),
                certificate.getPublicKey());

        // Check shared secret.
        byte[] z = GXCommon.hexToBytes(
                "C1 CF 8F E7 89 1A EF 36 17 D7 19 07 95 E6 1F E6 C2 4E FC 3C CA 2E 08 46 9B AD 1A 22 5C E6 EA 08");

        // Client generates shared secret.
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(target.getCiphering().getEphemeralKeyPair().getPrivate());
        ka.doPhase(target.getSettings().getTargetEphemeralKey(), true);
        byte[] actual = ka.generateSecret();
        assertEquals(GXCommon.toHex(z), GXCommon.toHex(actual));
        reply = server.handleRequest(target.read(clock, 2)[0]);
        info.clear();
        target.getData(reply, info);
        assertEquals(0, info.getError());
    }

    /*
     * kdf test using test vector from Green book page 496.
     * @throws Exception
     */
    @Test
    public final void kdfTestC1() throws Exception {
        byte[] z = GXCommon.hexToBytes(
                "C1CF8FE7891AEF3617D7190795E61FE6C24EFC3CCA2E08469BAD1A225CE6EA08");
        byte[] algID = GXCommon.hexToBytes("60857405080300"); // AES-GCM-128
        byte[] kdf = GXCommon.hexToBytes(
                "C5F4512846EDE51CFB8CCF59F08A694E002EDF66B4CB1739AC26A74E49712F46");
        byte[] sysTC = GXCommon.hexToBytes("4D4D4D0000BC614E");
        byte[] sysTS = GXCommon.hexToBytes("4D4D4D0000000001");
        byte[] actual = GXASymmetric.generateKDF("SHA-256", z, 256, algID,
                sysTC, sysTS, null, null,
                SecuritySuite.ECDHE_CDSA_AES_GCM_256_SHA_384);
        assertEquals(GXCommon.toHex(kdf), GXCommon.toHex(actual));
    }

    /*
     * kdf test using test vector from Green book page 500.
     * @throws Exception
     */
    @Test
    public final void kdfTestC2() throws Exception {
        byte[] z = GXCommon.hexToBytes(
                "0D4385BA0DD756CBCAB9887EB538396EE8F090A14C1079B4359F115B977F4615");
        byte[] algID = GXCommon.hexToBytes("60857405080300"); // AES-GCM-128
        byte[] kdf = GXCommon.hexToBytes(
                "59A71FD81C929A86A99438DA17A66C058C6A93FD3065F5EE16A05D775927659B");
        byte[] sysTC = GXCommon.hexToBytes("4D4D4D0000BC614E");
        byte[] sysTS = GXCommon.hexToBytes("4D4D4D0000000001");
        byte[] actual = GXASymmetric.generateKDF("SHA-256", z, 256, algID,
                sysTC, sysTS, null, null,
                SecuritySuite.ECDHE_CDSA_AES_GCM_256_SHA_384);
        assertEquals(GXCommon.toHex(kdf), GXCommon.toHex(actual));
    }

    /*
     * kdf test using test vector from Green book page 503.
     * @throws Exception
     */
    @Test
    public final void kdfTestC3() throws Exception {
        byte[] z = GXCommon.hexToBytes(
                "B1455B2AD5F68BCFFE6AD5412BA89548ACA7E0CBF4B1560D6A57496F15E931AD");
        byte[] algID = GXCommon.hexToBytes("60857405080300"); // AES-GCM-128
        byte[] kdf = GXCommon.hexToBytes(
                "56C46B57DF675515C31025455822514AFA2CDEB3E0BF1CADA84576159E84DE7E");
        byte[] sysTC = GXCommon.hexToBytes("4D4D4D0000BC614E");
        byte[] nonsesysTS =
                GXCommon.hexToBytes("0801020304050607084D4D4D0000000001");
        byte[] actual = GXASymmetric.generateKDF("SHA-256", z, 256, algID,
                sysTC, nonsesysTS, null, null,
                SecuritySuite.ECDHE_CDSA_AES_GCM_256_SHA_384);
        assertEquals(GXCommon.toHex(kdf), GXCommon.toHex(actual));
    }

    /*
     * Test shared secret generating using test vector from Green book. Source
     * ephemeral private key and target ephemeral public key m (d e, v, Q e, U)
     * </p> Table C. 1 – Test vector for key agreement using the Ephemeral
     * Unified Model C(2e, 0s, ECC CDH) scheme Step 3.
     * @throws Exception
     */
    @Test
    public final void generateSharedSecretEphemeralUnifiedModelTest()
            throws Exception {
        byte[] z = GXCommon.hexToBytes(
                "C1 CF 8F E7 89 1A EF 36 17 D7 19 07 95 E6 1F E6 C2 4E FC 3C CA 2E 08 46 9B AD 1A 22 5C E6 EA 08");

        PrivateKey ePriKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "1BAC19FC1D52A1E5102622EDFA36584C05E12FA8CDEAA450F2F1E9A7DCCF7628"));
        PublicKey ePubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "2914D60E10AB705F62ED6CC349D7CB99B9AB3F3978E59278C7AF595B3AF987941372DAB6D5AF1FA867E134167E6F23DE664A6693E05F43414611058D1B48F894"));
        PrivateKey ePriKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "34A8C23A34DBB519D09B245754C85A6CFE05D14A063EFA5AA41545AA8241EFAE"));
        PublicKey ePubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "95F41066009B185B074F5FFFF736B71C325FCADB2BC0CF1A4F4B17BBE7AB81D62946506BC8169C7B539B39A5D8463787F449C9BD2583FA67A1075B0DBFC638BA"));

        // Client generates shared secret.
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(ePriKc);
        ka.doPhase(ePubKs, true);
        byte[] actual = ka.generateSecret();
        assertEquals(GXCommon.toHex(z), GXCommon.toHex(actual));

        // Server generates shared secret.
        ka = KeyAgreement.getInstance("ECDH");
        ka.init(ePriKs);
        ka.doPhase(ePubKc, true);
        actual = ka.generateSecret();
        assertEquals(GXCommon.toHex(z), GXCommon.toHex(actual));
    }

    /*
     * Test shared secret generating using test vector from Green book. Source
     * ephemeral private key and target ephemeral public key m (d e, v, Q e, U)
     * </p> Table C. 2 – Test vector for key agreement using the One-pass
     * Diffie-Hellman (1e, 1s, ECC CDH) scheme.
     * @throws Exception
     */
    @Test
    public final void generateSharedSecretOnePassDiffieHellmanTest()
            throws Exception {
        byte[] Zc = GXCommon.hexToBytes(
                "0D4385BA0DD756CBCAB9887EB538396EE8F090A14C1079B4359F115B977F4615");
        byte[] Zs = GXCommon.hexToBytes(
                "2B4302DC49790E2E78D990CFB52ED6E2F273DECE441A2D95E4301B93812A9FAC");

        // Ephemeral Private Key Client.
        PrivateKey ePriKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "47DAB03842E5B6E74828EF4F449B378D7DD1A5DAE1FFCA5AE0B0BE0AD18EC57E"));
        // Public Key Agreement Key Client
        PublicKey aPubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "07C56DE2DCAF0FD793EF29F019C89B4A0CC1E001CE94F4FFBE10BC05E7E66F7671A13FBCF9E662B9826FFF6A6938546D524ED6D3405F020296BDE16B04F7A7C2"));
        // Ephemeral Private Key Server.
        PrivateKey ePriKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "819B1BEACC955E29139E368BF4119C126FF799EE16BCBA3F45C1EF16749BCB95"));

        // Public Key Agreement Key Server
        PublicKey aPubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "A653565B0E06070BAE9FBE140A5D2156812AEE2DD525053E3EFC850BF13BFDFFCB240BC7B77BFF5883344E7275908D2287BEFA3725017295A096989D2338290B"));

        // Client generates shared secret.
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(ePriKc);
        ka.doPhase(aPubKs, true);
        byte[] actual = ka.generateSecret();
        assertEquals(GXCommon.toHex(Zc), GXCommon.toHex(actual));

        // Server generates shared secret.
        ka = KeyAgreement.getInstance("ECDH");
        ka.init(ePriKs);
        ka.doPhase(aPubKc, true);
        actual = ka.generateSecret();
        assertEquals(GXCommon.toHex(Zs), GXCommon.toHex(actual));
    }

    /*
     * Test shared secret generating using test vector from Green book. Source
     * ephemeral private key and target ephemeral public key m (d e, v, Q e, U)
     * </p> Table C. 3 – Test vector for key agreement using the Static-Unified
     * Model (0e, 2s, ECC CDH) scheme.
     * @throws Exception
     */
    @Test
    public final void generateSharedSecretStaticUnifiedModelTest()
            throws Exception {
        byte[] z = GXCommon.hexToBytes(
                "B1 45 5B 2A D5 F6 8B CF FE 6A D5 41 2B A8 95 48 AC A7 E0 CB F4 B1 56 0D 6A 57 49 6F 15 E9 31 AD");

        // Private Key Agreement Key Client
        PrivateKey aPriKc = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "A51C16FF5C498FCC89323D4A9267CD71BF81FD6F6A891CD240DA7F3D6F283E65"));
        // Public Key Agreement Key Client
        PublicKey aPubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "07C56DE2DCAF0FD793EF29F019C89B4A0CC1E001CE94F4FFBE10BC05E7E66F7671A13FBCF9E662B9826FFF6A6938546D524ED6D3405F020296BDE16B04F7A7C2"));
        // Private Key Agreement Key Server
        PrivateKey aPriKs = GXAsn1Converter.getPrivateKey(GXCommon.hexToBytes(
                "AAD3FD0732E991CF52A74C66C1F2827DDC53522A2E0A169D7C4FFCC0FB5D6A4D"));
        // Public Key Agreement Key Server
        PublicKey aPubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "A653565B0E06070BAE9FBE140A5D2156812AEE2DD525053E3EFC850BF13BFDFFCB240BC7B77BFF5883344E7275908D2287BEFA3725017295A096989D2338290B"));

        // Client generates shared secret.
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(aPriKc);
        ka.doPhase(aPubKs, true);
        byte[] actual = ka.generateSecret();
        assertEquals(GXCommon.toHex(z), GXCommon.toHex(actual));

        // Server generates shared secret.
        ka = KeyAgreement.getInstance("ECDH");
        ka.init(aPriKs);
        ka.doPhase(aPubKc, true);
        actual = ka.generateSecret();
        assertEquals(GXCommon.toHex(z), GXCommon.toHex(actual));
    }
}
