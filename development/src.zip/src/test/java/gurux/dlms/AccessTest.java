//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.AccessMode;
import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.MethodAccessMode;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSAssociationShortName;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.objects.GXDLMSObject;

/**
 * Object attribute and method access tests.
 */
public class AccessTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient(true, 16, 1, Authentication.NONE, null,
                InterfaceType.WRAPPER);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = target.read(item, index);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(new GXByteBuffer(tmp), info);
        if (info.getError() != 0) {
            throw new GXDLMSException(info.getError());
        }
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, info.getValue());
    }

    /**
     * LN Access test for Get.
     * 
     * @throws Exception
     *             Occurred exception.
     */
    @Test
    public final void getNoAccessLNTest() throws Exception {
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        server.attributeAccess = AccessMode.NO_ACCESS;
        try {
            readTest(item, 9);
            throw new Exception("Access right is not handled.");
        } catch (GXDLMSException e) {
            if (e.getErrorCode() != 3) {
                throw new Exception("Access right is not handled.");
            }
        }
    }

    /**
     * SN Access test for Read.
     * 
     * @throws Exception
     *             Occurred exception.
     */
    @Test
    public final void readNoAccessSNTest() throws Exception {
        target.setUseLogicalNameReferencing(false);
        server = new TestServer(new GXDLMSAssociationShortName(),
                InterfaceType.WRAPPER);
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        server.attributeAccess = AccessMode.NO_ACCESS;
        try {
            readTest(item, 9);
            throw new Exception("Access right is not handled.");
        } catch (GXDLMSException e) {
            if (e.getErrorCode() != 3) {
                throw new Exception("Access right is not handled.");
            }
        }
    }

    /**
     * LN Access test for methods.
     * 
     * @throws Exception
     *             Occurred exception.
     */
    @Test
    public final void methodNoAccessLNTest() throws Exception {
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        GXReplyData info = new GXReplyData();
        server.methodAccessMode = MethodAccessMode.NO_ACCESS;
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = item.adjustToQuarter(target);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        if (info.getError() != 3) {
            throw new Exception("Access right is not handled.");
        }
    }

    /**
     * LN Access test for methods.
     * 
     * @throws Exception
     *             Occurred exception.
     */
    @Test
    public final void methodNoAccessSNTest() throws Exception {
        target.setUseLogicalNameReferencing(false);
        server = new TestServer(new GXDLMSAssociationShortName(),
                InterfaceType.WRAPPER);
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        GXReplyData info = new GXReplyData();
        server.methodAccessMode = MethodAccessMode.NO_ACCESS;
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = item.adjustToQuarter(target);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        if (info.getError() != 3) {
            throw new Exception("Access right is not handled.");
        }
    }
}
