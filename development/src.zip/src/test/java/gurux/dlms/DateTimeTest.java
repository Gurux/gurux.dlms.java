//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSData;
import gurux.dlms.objects.GXDLMSObject;

/**
 * @author Gurux Ltd
 */
public class DateTimeTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData reply = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, reply);
        reply.clear();
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, reply);
        reply.clear();
        // Write new value.
        buff = target.write(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, reply);
        reply.clear();
        // Read value.
        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, reply);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, reply.getValue());
    }

    /**
     * A test for date time set with Local time.
     */
    @Test
    public final void dateTimeSetTestLocal() {
        GXDateTime expected = new GXDateTime(new Date());
        GXDLMSData item = new GXDLMSData("0.0.1.0.0.255");
        item.setValue(expected);
        item.setDataType(2, DataType.OCTET_STRING);
        item.setUIDataType(2, DataType.DATETIME);
        readTest(item, 2, true);
        assertEquals(expected.toString(), item.getValue().toString());
    }

    /**
     * A test for date time set with UTC time.
     */
    @Test
    public final void dateTimeSetTestUtc() {
        Object expected =
                new GXDateTime(java.util.Calendar.getInstance().getTime());
        GXDLMSData item = new GXDLMSData("0.0.1.0.0.255");
        item.setValue(expected);
        item.setDataType(2, DataType.OCTET_STRING);
        item.setUIDataType(2, DataType.DATETIME);
        readTest(item, 2, true);
        assertEquals(expected.toString(), item.getValue().toString());
    }
}
