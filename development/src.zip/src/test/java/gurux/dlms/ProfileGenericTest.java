//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSCaptureObject;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.objects.GXDLMSData;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSProfileGeneric;
import gurux.dlms.objects.enums.SortMethod;

/**
 * @author Gurux Ltd
 */
public class ProfileGenericTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData reply = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, reply);
        reply.clear();
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, reply);
        reply.clear();

        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, reply);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        if (item instanceof GXDLMSProfileGeneric) {
            ((GXDLMSProfileGeneric) item).clearBuffer();
        }
        return target.updateValue(item, index, reply.getValue());
    }

    /**
     * A test for Logical name (1st) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute1Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        String expected = "1.1.1.1.1.255";
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric(expected);
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        assertEquals(expected, readTest(item, 1));
    }

    /**
     * A test for buffer (2) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute2Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);

        Object[][] expected = new Object[][] {
                new Object[] { Calendar.getInstance().getTime(), 10 },
                new Object[] { Calendar.getInstance().getTime(), 20 } };
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        item.setBuffer(expected);
        readTest(item, 2, false);
        assertEquals(expected.length, item.getBuffer().length);
    }

    /**
     * A test for buffer (2) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute2RangeTest() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);
        target.getSettings().setSkipFrameCheck(true);

        Object[][] expected = new Object[][] {
                new Object[] { Calendar.getInstance().getTime(), 10 },
                new Object[] { Calendar.getInstance().getTime(), 20 } };
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        item.setBuffer(expected);
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.getSettings().setSkipFrameCheck(true);
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        ///////////////////////////////////////////////////////////////////
        // Read last day.
        java.util.Calendar start = Calendar.getInstance();
        start.set(java.util.Calendar.HOUR_OF_DAY, 0); // set hour to midnight
        start.set(java.util.Calendar.MINUTE, 0); // set minute in hour
        start.set(java.util.Calendar.SECOND, 0); // set second in minute
        start.set(java.util.Calendar.MILLISECOND, 0);
        start.add(java.util.Calendar.DATE, -1);
        java.util.Calendar end = Calendar.getInstance();
        end.add(java.util.Calendar.SECOND, 1); // Add one second so we can read
                                               // all values.
        byte[] buff =
                target.readRowsByRange(item, start.getTime(), end.getTime())[0];
        byte[] tmp = server.handleRequest(buff);
        target.getData(tmp, info);
        item.clearBuffer();
        target.updateValue(item, 2, info.getValue());
        assertEquals(expected.length, item.getBuffer().length);
    }

    /**
     * A test for capture objects (3) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute3Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        readTest(item, 3);
        assertEquals(clock.getObjectType(),
                item.getCaptureObjects().get(0).getKey().getObjectType());
    }

    /**
     * A test for capture period (4) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute4Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);
        int expected = 123;
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setCapturePeriod(expected);
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        assertEquals(expected, readTest(item, 4));
    }

    /**
     * A test for sort_method (5) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute5Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);

        SortMethod expected = SortMethod.LARGEST;
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setSortMethod(expected);
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        readTest(item, 5);
        assertEquals(expected, item.getSortMethod());
    }

    /**
     * A test for sort object (6) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute6Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);

        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        item.setSortObject(clock);
        readTest(item, 6);
        GXDLMSObject ret = item.getSortObject();
        assertEquals(clock.getObjectType(), ret.getObjectType());
    }

    /**
     * A test for entries_in_use (7) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute7Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);

        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        item.setSortObject(clock);
        readTest(item, 7);
        assertEquals(0, item.getEntriesInUse());
    }

    /**
     * A test for buffer (2) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute2SelectiveRangeTest() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);
        target.getSettings().setSkipFrameCheck(true);
        Object[][] expected = new Object[][] {
                new Object[] { Calendar.getInstance().getTime(), 10 },
                new Object[] { Calendar.getInstance().getTime(), 20 } };
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        item.setBuffer(expected);
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        ///////////////////////////////////////////////////////////////////
        // Read last day.
        java.util.Calendar start = Calendar.getInstance();
        start.set(java.util.Calendar.HOUR_OF_DAY, 0); // set hour to midnight
        start.set(java.util.Calendar.MINUTE, 0); // set minute in hour
        start.set(java.util.Calendar.SECOND, 0); // set second in minute
        start.set(java.util.Calendar.MILLISECOND, 0);
        start.add(java.util.Calendar.DATE, -1);
        java.util.Calendar end = Calendar.getInstance();
        end.add(java.util.Calendar.SECOND, 1); // Add one second so we can read
                                               // all values.

        List<Entry<GXDLMSObject, GXDLMSCaptureObject>> cols =
                new ArrayList<Entry<GXDLMSObject, GXDLMSCaptureObject>>();
        cols.addAll(item.getCaptureObjects());
        cols.remove(1);
        byte[] buff = target.readRowsByRange(item, start.getTime(),
                end.getTime(), cols)[0];
        byte[] tmp = server.handleRequest(buff);
        target.getData(tmp, info);
        item.clearBuffer();
        target.updateValue(item, 2, info.getValue(), cols);
        assertEquals(expected.length, item.getBuffer().length);
    }

    /**
     * A test for buffer (2) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute2SelectiveEntryTest() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);
        target.getSettings().setSkipFrameCheck(true);
        Object[][] expected = new Object[][] {
                new Object[] { Calendar.getInstance().getTime(), 10 },
                new Object[] { Calendar.getInstance().getTime(), 20 } };
        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(100);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        item.setBuffer(expected);
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        ///////////////////////////////////////////////////////////////////
        // Read last day.
        java.util.Calendar start = Calendar.getInstance();
        start.set(java.util.Calendar.HOUR_OF_DAY, 0); // set hour to midnight
        start.set(java.util.Calendar.MINUTE, 0); // set minute in hour
        start.set(java.util.Calendar.SECOND, 0); // set second in minute
        start.set(java.util.Calendar.MILLISECOND, 0);
        start.add(java.util.Calendar.DATE, -1);
        java.util.Calendar end = Calendar.getInstance();
        // Add one second so we can read all values.
        end.add(java.util.Calendar.SECOND, 1);
        // Read only dates.
        List<Entry<GXDLMSObject, GXDLMSCaptureObject>> cols =
                new ArrayList<Entry<GXDLMSObject, GXDLMSCaptureObject>>();
        cols.addAll(item.getCaptureObjects());
        cols.remove(1);
        byte[] buff = target.readRowsByEntry(item, 0, 2, cols)[0];
        byte[] tmp = server.handleRequest(buff);
        target.getData(tmp, info);
        item.clearBuffer();
        target.updateValue(item, 2, info.getValue(), cols);
        assertEquals(expected.length, item.getBuffer().length);
    }

    /**
     * A test for profile entries (8) attribute of profile generic Object.
     */
    @Test
    public final void profileGenericAttribute8Test() {
        GXDLMSClock clock = new GXDLMSClock("1.2.1.1.1.255");
        GXDLMSData value = new GXDLMSData("1.2.1.1.1.255");
        value.setDataType(2, DataType.INT32);

        GXDLMSProfileGeneric item = new GXDLMSProfileGeneric("1.1.1.1.1.255");
        item.setProfileEntries(99);
        item.addCaptureObject(clock, 2, 0);
        item.addCaptureObject(value, 2, 0);
        item.setSortObject(clock);
        readTest(item, 8);
        assertEquals(99, item.getProfileEntries());
    }
}
