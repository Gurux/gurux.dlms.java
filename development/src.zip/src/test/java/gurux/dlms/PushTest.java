//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Conformance;
import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.Priority;
import gurux.dlms.enums.RequestTypes;
import gurux.dlms.enums.Security;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSCaptureObject;
import gurux.dlms.objects.GXDLMSData;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSPushSetup;
import gurux.dlms.secure.GXCiphering;
import gurux.dlms.secure.GXDLMSSecureNotify;

public class PushTest {
    private GXDLMSClient target = null;

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress((short) 0x1);
        target.setClientAddress((short) 0x1);
        target.setUseLogicalNameReferencing(true);
        target.setInterfaceType(InterfaceType.WRAPPER);
    }

    @After
    public final void tearDown() {
    }

    /**
     * On installation push test.
     */
    @Test
    public final void onInstallationTest() {
        GXReplyData info = new GXReplyData();
        // CHECKSTYLE:OFF
        byte[] packet1 = Helpers2.getBytes(
                "00 01 00 01 00 01 00 F4 E0 00 00 01 00 00 0F 00 00 00 02 00 "
                        + "01 08 01 08 02 04 12 00 28 09 06 00 07 19 09 00 FF 0F 02 12 "
                        + "00 00 02 04 12 00 01 09 06 00 00 2A 00 00 FF 0F 02 12 00 00 "
                        + "02 04 12 00 01 09 06 00 00 60 01 01 FF 0F 02 12 00 00 02 04 "
                        + "12 00 01 09 06 01 00 00 02 00 FF 0F 02 12 00 00 02 04 12 00 "
                        + "01 09 06 00 00 60 04 00 FF 0F 02 12 00 00 02 04 12 00 01 09 "
                        + "06 00 00 60 05 00 FF 0F 02 12 00 00 02 04 12 00 01 09 06 00 "
                        + "00 61 61 00 FF 0F 02 12 00 00 02 04 12 00 0F 09 06 00 00 28 "
                        + "00 00 FF 0F 04 12 00 00 09 10 4D 45 4C 31 30 31 30 37 31 30 "
                        + "35 30 30 30 32 37 09 40 4D 45 54 35 30 30 2D 45 33 34 4E 2D 49 30 35 20 49 4D 31 30 30 20 55 4E 32 33 30 2D 41 33 31 30 30 33 20 52 33 32 30 30 33 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");
        // CHECKSTYLE:ON
        target.getData(packet1, info);
        assertTrue(info.getMoreData() == RequestTypes.DATABLOCK);
        // CHECKSTYLE:OFF
        byte[] packet2 =
                Helpers2.getBytes("00 01 00 01 00 01 00 3A E0 80 00 02 00 00 "
                        + "0F 00 00 00 03 00 09 0A 56 30 33 30 35 30 39 2E 35 38 04 20 00 00 00 "
                        + "80 04 20 00 00 00 80 06 00 00 20 00 02 07 11 02 11 10 12 02 F4 11 05 "
                        + "11 08 11 01 11 01");
        // CHECKSTYLE:ON
        target.getData(packet2, info);
        assertTrue(info.getMoreData() == RequestTypes.NONE);

        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        List<Entry<GXDLMSObject, Integer>> objects =
                n.parsePush((Object[]) info.getValue());
        objects.get(4).getKey().setDataType(2, DataType.BITSTRING);
        objects.get(5).getKey().setDataType(2, DataType.BITSTRING);
        objects.get(6).getKey().setDataType(2, DataType.UINT32);
        n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.setPriority(Priority.NORMAL);
        n.getConformance().add(Conformance.GENERAL_BLOCK_TRANSFER);
        n.setMaxReceivePDUSize(0xF4);
        byte[][] actual = n.generateDataNotificationMessages(null, objects);
        objects = n.parsePush((Object[]) info.getValue());
        assertEquals(2, actual.length);
    }

    /**
     * This test is used to test two Push message on one TCP/IP message.
     */
    @Test
    public final void twoPushMessagesOnOnepacketTest() {
        GXReplyData info = new GXReplyData();
        GXByteBuffer data = new GXByteBuffer();
        // CHECKSTYLE:OFF
        data.set(Helpers2.getBytes(
                "00 01 00 01 00 01 00 F4 E0 00 00 01 00 00 0F 00 00 00 02 00 "
                        + "01 08 01 08 02 04 12 00 28 09 06 00 07 19 09 00 FF 0F 02 12 "
                        + "00 00 02 04 12 00 01 09 06 00 00 2A 00 00 FF 0F 02 12 00 00 "
                        + "02 04 12 00 01 09 06 00 00 60 01 01 FF 0F 02 12 00 00 02 04 "
                        + "12 00 01 09 06 01 00 00 02 00 FF 0F 02 12 00 00 02 04 12 00 "
                        + "01 09 06 00 00 60 04 00 FF 0F 02 12 00 00 02 04 12 00 01 09 "
                        + "06 00 00 60 05 00 FF 0F 02 12 00 00 02 04 12 00 01 09 06 00 "
                        + "00 61 61 00 FF 0F 02 12 00 00 02 04 12 00 0F 09 06 00 00 28 "
                        + "00 00 FF 0F 04 12 00 00 09 10 4D 45 4C 31 30 31 30 37 31 30 "
                        + "35 30 30 30 32 37 09 40 4D 45 54 35 30 30 2D 45 33 34 4E 2D 49 30 35 20 49 4D 31 30 30 20 55 4E 32 33 30 2D 41 33 31 30 30 33 20 52 33 32 30 30 33 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00"));
        data.set(Helpers2.getBytes("00 01 00 01 00 01 00 3A E0 80 00 02 00 00 "
                + "0F 00 00 00 03 00 09 0A 56 30 33 30 35 30 39 2E 35 38 04 20 00 00 00 "
                + "80 04 20 00 00 00 80 06 00 00 20 00 02 07 11 02 11 10 12 02 F4 11 05 "
                + "11 08 11 01 11 01"));
        // CHECKSTYLE:ON

        target.getData(data, info);
        assertTrue(info.getMoreData() == RequestTypes.DATABLOCK);
        // CHECKSTYLE:OFF

        target.getData(data, info);
        assertTrue(info.getMoreData() == RequestTypes.NONE);

        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        List<Entry<GXDLMSObject, Integer>> objects =
                n.parsePush((Object[]) info.getValue());
        objects.get(4).getKey().setDataType(2, DataType.BITSTRING);
        objects.get(5).getKey().setDataType(2, DataType.BITSTRING);
        objects.get(6).getKey().setDataType(2, DataType.UINT32);
        n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.setPriority(Priority.NORMAL);
        n.getConformance().add(Conformance.GENERAL_BLOCK_TRANSFER);
        n.setMaxReceivePDUSize(0xF4);
        byte[][] actual = n.generateDataNotificationMessages(null, objects);
        objects = n.parsePush((Object[]) info.getValue());
        assertEquals(2, actual.length);
    }

    /**
     * On connectivity push test.
     */
    @Test
    public final void onConnectivityTest() {
        GXReplyData info = new GXReplyData();
        // CHECKSTYLE:OFF
        byte[] packet1 = Helpers2.getBytes(
                "00010001000100570f0000001f0002030103020412002809060000190900ff0f021200000204120001090600002a0000ff0f02120000020412002a09060000190100ff0f0312000009104d454c313031303731303530303032370655edf798");
        // CHECKSTYLE:ON
        target.getData(packet1, info);
        assertTrue(info.getMoreData() == RequestTypes.NONE);
        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        // Get objects.
        n.parsePush((Object[]) info.getValue());
    }

    /**
     * A simple data notification test.
     */
    @Test
    public final void dataNotificationTest() {
        // CHECKSTYLE:OFF
        byte[] data = Helpers2.getBytes(
                "00010001000100a20f0000044f0002060106020412002809060004190900ff0f021200000204120001090600002a0000ff0f02120000020412000809060000010000ff0f02120000020412000109060000616214ff0f02120000020412000109060000616215ff0f02120000020412000109060000600b01ff0f0212000009104d454c31303130373130353030313031090c07e00310030d392a00ffc400060000200006000000001628");
        // CHECKSTYLE:ON
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        assertEquals(RequestTypes.NONE, info.getMoreData());
        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        List<Entry<GXDLMSObject, Integer>> objects =
                n.parsePush((Object[]) info.getValue());
        assertEquals(6, objects.size());
    }

    /**
     * A data notification test.
     */
    @Test
    public final void dataNotification2Test() {
        byte[] data = Helpers2
                .getBytes("000100010001000F0F8000000100020109054755525558");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        assertEquals(RequestTypes.NONE, info.getMoreData());
        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);

        GXDLMSData obj = new GXDLMSData();
        obj.setUIDataType(2, DataType.STRING);
        List<Entry<GXDLMSObject, Integer>> objects =
                new ArrayList<Entry<GXDLMSObject, Integer>>();
        objects.add(new GXSimpleEntry<GXDLMSObject, Integer>(obj, 2));
        n.parsePush(objects, (Object[]) info.getValue());
        assertEquals(1, objects.size());
        assertEquals("GURUX", obj.getValue().toString());
    }

    /**
     * A data notification date time test.
     */
    @Test
    public final void dataNotificationDateTimeTest() {
        Date expected = Calendar.getInstance().getTime();
        GXReplyData info = new GXReplyData();
        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        byte[][] messages =
                n.generateDataNotificationMessages(expected, new byte[] { 0 });
        n.getData(new GXByteBuffer(messages[0]), info);
        assertEquals(expected.toString(),
                info.getTime().getCalendar().getTime().toString());
        List<Entry<GXDLMSObject, Integer>> objects =
                n.parsePush((Object[]) info.getValue());
        assertEquals(0, objects.size());
    }

    /**
     * A ciphered data notification test.
     */
    @Test
    public final void cipheredDataNotificationTest() {
        GXReplyData info = new GXReplyData();
        GXDLMSSecureNotify n =
                new GXDLMSSecureNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        GXDLMSData obj = new GXDLMSData();
        obj.setUIDataType(2, DataType.STRING);
        String expected = "GURUX";
        obj.setValue(expected);
        GXDLMSPushSetup push = new GXDLMSPushSetup();
        push.getPushObjectList()
                .add(new GXSimpleEntry<GXDLMSObject, GXDLMSCaptureObject>(push,
                        new GXDLMSCaptureObject(2, 0)));
        push.getPushObjectList()
                .add(new GXSimpleEntry<GXDLMSObject, GXDLMSCaptureObject>(obj,
                        new GXDLMSCaptureObject(2, 0)));
        byte[][] reply = n.generatePushSetupMessages(null, push);
        n.getData(new GXByteBuffer(reply[0]), info);
        assertEquals(expected, ((Object[]) info.getValue())[1].toString());
    }

    /**
     * A ciphered data notification test.
     */
    @Test(expected = IllegalArgumentException.class)
    public final void cipheredDataNotificationFailTest() {
        String expected = "GURUX";
        GXReplyData info = new GXReplyData();
        GXDLMSSecureNotify n =
                new GXDLMSSecureNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        n.getConformance().add(Conformance.GENERAL_PROTECTION);

        GXCiphering ciphering = n.getCiphering();
        ciphering.setBlockCipherKey(
                GXCommon.hexToBytes("ABABABABABABABABABABABABABABABAB"));
        GXDLMSData obj = new GXDLMSData();
        obj.setValue(expected);
        obj.setUIDataType(2, DataType.STRING);
        GXDLMSPushSetup push = new GXDLMSPushSetup();
        push.getPushObjectList()
                .add(new GXSimpleEntry<GXDLMSObject, GXDLMSCaptureObject>(push,
                        new GXDLMSCaptureObject(2, 0)));
        push.getPushObjectList()
                .add(new GXSimpleEntry<GXDLMSObject, GXDLMSCaptureObject>(obj,
                        new GXDLMSCaptureObject(2, 0)));
        byte[][] reply = n.generatePushSetupMessages(null, push);
        n = new GXDLMSSecureNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.getData(new GXByteBuffer(reply[0]), info);
    }

    /**
     * Test data notification with give data.
     * 
     * @param expected
     *            Data to send.
     * @param count
     *            Expected message count.
     */
    static void testDatanotfication(final GXDLMSNotify n, final byte[] expected,
            final int count) {
        GXReplyData info = new GXReplyData();
        GXByteBuffer data = new GXByteBuffer();
        data.setUInt8(DataType.OCTET_STRING.getValue());
        GXCommon.setObjectCount(expected.length, data);
        data.set(expected);
        byte[][] messages = n.generateDataNotificationMessages(null, data);
        assertEquals(count, messages.length);
        int pos = 0;
        do {
            n.getData(new GXByteBuffer(messages[pos]), info);
            ++pos;
        } while (info.isMoreData());
    }

    /**
     * A data notification test for multiple packets.
     */
    @Test
    public final void dataNotificationMultiplePacketsTest() {
        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.setMaxReceivePDUSize(128);
        n.getConformance().add(Conformance.GENERAL_BLOCK_TRANSFER);
        byte[] expected = new byte[2 * n.getMaxReceivePDUSize()];
        for (int pos = 0; pos != expected.length; ++pos) {
            expected[pos] = (byte) (pos % 0xFF);
        }
        testDatanotfication(n, expected, 3);
    }

    /**
     * Data notification test with ONE packet where data size is PDU size.
     */
    @Test
    public final void dataNotificationFullPacketTest() {
        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.setMaxReceivePDUSize(128);
        n.getConformance().add(Conformance.GENERAL_BLOCK_TRANSFER);
        // Remove command, long index and empty date time size from data.
        // data type and size is also removed.
        byte[] expected = new byte[n.getMaxReceivePDUSize() - 12 - 6];
        for (int pos = 0; pos != expected.length; ++pos) {
            expected[pos] = (byte) (pos % 0xFF);
        }
        testDatanotfication(n, expected, 1);
    }

    /**
     * Data notification test with TWO packets where data size is 2 * PDU size.
     */
    @Test
    public final void dataNotificationFullMultiplePacketsTest() {
        GXDLMSNotify n = new GXDLMSNotify(true, 1, 1, InterfaceType.WRAPPER);
        n.setMaxReceivePDUSize(128);
        n.getConformance().add(Conformance.GENERAL_BLOCK_TRANSFER);
        byte[] expected = new byte[2 * (n.getMaxReceivePDUSize() - 13) - 3];
        for (int pos = 0; pos != expected.length; ++pos) {
            expected[pos] = (byte) (pos % 0xFF);
        }
        testDatanotfication(n, expected, 2);
    }
}
