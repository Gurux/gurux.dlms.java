//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.InterfaceType;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSImageActivateInfo;
import gurux.dlms.objects.GXDLMSImageTransfer;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.enums.ImageTransferStatus;

/**
 * @author Gurux Ltd
 */
public class ImageTransferTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);

    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, info);
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, info);
        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, info);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, info.getValue());
    }

    /**
     * A test for Logical Name (1st) attribute of Image Transfer Object.
     */
    @Test
    public final void imageTransferAttribute1Test() {
        String expected = "1.1.1.1.1.255";
        GXDLMSImageTransfer item = new GXDLMSImageTransfer(expected);
        assertEquals(expected, readTest(item, 1));
    }

    /**
     * A test for Image Block Size (2rt) attribute of Image Transfer Object.
     */
    @Test
    public final void imageTransferAttribute2Test() {
        long expected = 100;
        GXDLMSImageTransfer item = new GXDLMSImageTransfer("1.1.1.1.1.255");
        item.setImageBlockSize(expected);
        readTest(item, 2);
        assertEquals(expected, item.getImageBlockSize());
    }

    /**
     * A test for image transferred blocks status (3rd) attribute of Image
     * Transfer Object.
     */
    @Test
    public final void imageTransferAttribute3Test() {
        String expected = "01";
        GXDLMSImageTransfer item = new GXDLMSImageTransfer("1.1.1.1.1.255");
        item.setImageTransferredBlocksStatus(expected);
        readTest(item, 3);
        assertEquals(expected, item.getImageTransferredBlocksStatus());
    }

    /**
     * A test for image first not transferred nlock number (4) attribute of
     * Image Transfer Object.
     */
    @Test
    public final void imageTransferAttribute4Test() {
        long expected = 98;
        GXDLMSImageTransfer item = new GXDLMSImageTransfer("1.1.1.1.1.255");
        item.setImageFirstNotTransferredBlockNumber(expected);
        readTest(item, 4);
        assertEquals(expected, item.getImageFirstNotTransferredBlockNumber());
    }

    /**
     * A test for image transfer enabled (5) attribute of Image Transfer Object.
     */
    @Test
    public final void imageTransferAttribute5Test() {
        boolean expected = true;
        GXDLMSImageTransfer item = new GXDLMSImageTransfer("1.1.1.1.1.255");
        item.setImageTransferEnabled(expected);
        readTest(item, 5);
        assertEquals(expected, item.getImageTransferEnabled());
    }

    /**
     * A test for image transfer status (6) attribute of Image Transfer Object.
     */
    @Test
    public final void imageTransferAttribute6Test() {
        ImageTransferStatus expected =
                ImageTransferStatus.IMAGE_VERIFICATION_FAILED;
        GXDLMSImageTransfer item = new GXDLMSImageTransfer("1.1.1.1.1.255");
        item.setImageTransferStatus(expected);
        readTest(item, 6);
        assertEquals(expected, item.getImageTransferStatus());
    }

    /**
     * A test for ImageActivateInfo (7) attribute of Image Transfer Object.
     */
    @Test
    public final void imageTransferAttribute7Test() {
        GXDLMSImageActivateInfo expected =
                new GXDLMSImageActivateInfo(10, "Gurux Ltd", "Gurux");
        GXDLMSImageTransfer item = new GXDLMSImageTransfer("1.1.1.1.1.255");
        item.setImageActivateInfo(new GXDLMSImageActivateInfo[] { expected });
        readTest(item, 7);
        assertEquals(10, item.getImageActivateInfo()[0].getSize());
        assertEquals("Gurux Ltd",
                item.getImageActivateInfo()[0].getIdentification());
        assertEquals("Gurux", item.getImageActivateInfo()[0].getSignature());
    }
}
