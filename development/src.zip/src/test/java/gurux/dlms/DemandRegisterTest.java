//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.Unit;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSDemandRegister;
import gurux.dlms.objects.GXDLMSObject;

/**
 * @author Gurux Ltd
 */
public class DemandRegisterTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData reply = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, reply);
        reply.clear();
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, reply);
        reply.clear();
        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, reply);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, reply.getValue());
    }

    /**
     * A test for Logical Name (1st) attribute of DemandRegister Object.
     */
    @Test
    public final void demandRegisterAttribute1Test() {
        String expected = "1.1.1.1.1.255";
        GXDLMSDemandRegister item = new GXDLMSDemandRegister(expected);
        assertEquals(expected, readTest(item, 1));
    }

    /**
     * A test for current average value (2th) attribute of Demand Register
     * Object.
     */
    @Test
    public final void demandRegisterAttribute2Test() {
        String expected = "Gurux";
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setCurrentAvarageValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for last average value (2th) attribute of Demand Register Object.
     */
    @Test
    public final void demandRegisterAttribute3Test() {
        String expected = "Gurux";
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setLastAvarageValue(expected);
        assertEquals(expected, readTest(item, 3));
    }

    /**
     * A test for scaler and unit (4th) attribute of Demand Register Object.
     */
    @Test
    public final void demandRegisterAttribute4Test() {
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setScaler(0.01);
        item.setUnit(Unit.CURRENT);
        readTest(item, 4);
        assertEquals("0.01", String.valueOf(item.getScaler()));
        assertEquals(Unit.CURRENT, item.getUnit());
    }

    /**
     * A test for status (5th) attribute of Demand Register Object.
     */
    @Test
    public final void demandRegisterAttribute5Test() {
        Object expected = (short) 123;
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setStatus(expected);
        readTest(item, 5);
        assertEquals(expected, item.getStatus());
    }

    /**
     * A test for capture time (5th) attribute of Demand Register Object.
     */
    @Test
    public final void demandRegisterAttribute6Test() {
        SimpleDateFormat sd = new SimpleDateFormat();
        java.util.Date expected = Calendar.getInstance().getTime();
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setCaptureTime(new GXDateTime(expected));
        readTest(item, 6);
        assertEquals(sd.format(expected), item.getCaptureTime().toString());
    }

    /**
     * A test for start time current (7th) attribute of Demand Register Object.
     */
    @Test
    public final void demandRegisterAttribute7Test() {
        SimpleDateFormat sd = new SimpleDateFormat();
        java.util.Date expected = Calendar.getInstance().getTime();
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setStartTimeCurrent(new GXDateTime(expected));
        readTest(item, 7);
        assertEquals(sd.format(expected),
                item.getStartTimeCurrent().toString());
    }

    /**
     * A test for period (8th) attribute of Demand Register Object.
     */
    @Test
    public final void demandRegisterAttribute8Test() {
        BigInteger expected = BigInteger.valueOf(0xABBA);
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setPeriod(expected);
        readTest(item, 8);
        assertEquals(expected, item.getPeriod());
    }

    /**
     * A test for number of periods (9th) attribute of Demand Register Object.
     */
    @Test
    public final void demandRegisterAttribute9Test() {
        int expected = 0xABBA;
        GXDLMSDemandRegister item = new GXDLMSDemandRegister("1.1.1.1.1.255");
        item.setNumberOfPeriods(expected);
        readTest(item, 9);
        assertEquals(expected, item.getNumberOfPeriods());
    }
}
