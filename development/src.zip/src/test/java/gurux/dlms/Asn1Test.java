//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.asn.GXAsn1BitString;
import gurux.dlms.asn.GXAsn1Converter;
import gurux.dlms.asn.GXPkcs10;
import gurux.dlms.asn.GXPkcs8;
import gurux.dlms.asn.GXx509Certificate;
import gurux.dlms.asn.enums.HashAlgorithm;
import gurux.dlms.internal.GXCommon;

public class Asn1Test {

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
    }

    @After
    public final void tearDown() {
    }

    /*
     * Test byte to hex.
     */
    @Test
    public final void byteHexTest() {
        byte[] expected = GXCommon.hexToBytes("02 01 02");
        String xml = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(xml);
        assertEquals("<Byte>2</Byte>\r\n", xml);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * Test long to hex.
     */
    @Test
    public final void longHexTest() {
        byte[] expected = GXCommon.hexToBytes("02 08 1A 8F 44 EE F9 B5 CD 6E");
        String xml = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(xml);
        assertEquals("<Long>1913824159838096750</Long>\r\n", xml);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * Test 61 bit integer to hex.
     */
    @Test
    public final void integerHexTest() {
        byte[] expected = GXCommon.hexToBytes("02 08 1A 8F 44 EE F9 B5 CD 6E");
        String xml = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(xml);
        assertEquals("<Long>1913824159838096750</Long>\r\n", xml);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * Test object identifier.
     */
    @Test
    public final void objectIdTest() {
        byte[] expected =
                GXCommon.hexToBytes("06 09 2A 86 48 86 F7 0D 01 01 0B");
        String xml = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(xml);
        assertEquals(
                "<ObjectIdentifier>1.2.840.113549.1.1.11</ObjectIdentifier>\r\n",
                xml);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * Test null.
     */
    @Test
    public final void nullTest() {
        byte[] expected = GXCommon.hexToBytes("05 00");
        String xml = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(xml);
        assertEquals("<Null></Null>\r\n", xml);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * Test UTC time.
     */
    @Test
    public final void utcTimeTest() {
        byte[] expected = GXCommon
                .hexToBytes("17 0D 31 36 31 31 30 33 30 30 30 30 30 30 5A");
        String xml = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(xml);
        assertEquals("<UtcTime>3.11.2016 2:00</UtcTime>\r\n", xml);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * Bit string to hex test
     */
    @Test
    public final void bitStringHexTest() {
        byte[] expected = GXCommon.hexToBytes("03 02 07 80");
        String xml = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(xml);
        assertEquals("<BitString>1</BitString>\r\n", xml);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * Bit string test
     */
    @Test
    public final void bitStringTest() {
        GXAsn1BitString bs = new GXAsn1BitString("011011100101110111");
        byte[] actual = GXAsn1Converter.toByteArray(bs);
        assertEquals(6, bs.getPadBits());
        assertEquals("03 04 06 6E 5D C0", GXCommon.toHex(actual));
        assertEquals("18 bit 011011100101110111", bs.toString());

    }

    /*
     * Test converter.
     */
    @Test
    public final void converterTest() {
        byte[] expected = GXCommon.fromBase64(
                "MIICpDCCAYygAwIBAgIIGo9E7vm1zW4wDQYJKoZIhvcNAQELBQAwEjEQMA4GA1UEAwwHcm9vdCBjYTAeFw0xNjExMDMwMDAwMDBaFw0xODExMDMwMDAwMDBaMBIxEDAOBgNVBAMMB3Jvb3QgY2EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCbyS9Qze7Z20xeL1pclF09c0mPShS+j4r/ClopxnZrNoATmCR1or/PeWupVU3jso9zxEEeZLzyDxqEJieS7xqlV9uLABQDMp9X/iWw2Sk9g4SOw5gdhBHdshfA7u+b0BD1iVWUgDDAutjHh+XlOidftjl8vPTqTZzvvxJaAFdfIEP53qCWFx0e6iEp3TXPRSqGzBMnjQlSbkpq7A8sAtpd2pNv8+/WyQI2Q2VPLLesLkePj/fFiPCpv+BEi/9/741efbWigEA+cTGbu1D7JBPYrY4pVy7AeWwmxCy5BYkUQL7vaumCTdTdbI3nzAFc+fkdzRKywk/BpTlnDCPkdzgVAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAAVDA98lUt8tQTMyhxlo6MMjQDXGLoYQVgtKjmL7iZoKNLZBLW27sO9HLrhfQDTEMrFOZaEdHu6FkF+p5HrB4SCw32nR6LLlg8wqgiUU8QaOIQEepB308zeE9PjdRhv9cRagVDbldOLFR3LETVbxHfHtE52LneEfeHdRCKSgZ+HTazJiMnMWfe46OCL7+vQUjmAb1e6NIYVh1Ofg6Y5QTkWQ3ksLNeZrBdErxdLf/pQE9OV7BJWmBpdE4VONh1Kq1dG/gc8Gm7bM1Z2XjblgU6gYM68VBPmWsEUqzls2LUb4ogPdBluBrX9HCD/t8XpaHhz47eGOgkq+YWVZjt/+vz0=");
        String tmp = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(tmp);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    private static KeyPair generateRSAKeys() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(512);
        return keyGen.genKeyPair();
    }

    private static KeyPair generateECDSAKeys() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("EC");
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        keyGen.initialize(256, random);
        return keyGen.generateKeyPair();
    }

    /*
     * Converter RSA private key to hex and back.
     */
    @Test
    public final void rsaPrivateKeyHexTest() throws NoSuchAlgorithmException {
        KeyPair pair = generateRSAKeys();
        byte[] expected = pair.getPrivate().getEncoded();
        String tmp = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(tmp);
        // assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /*
     * Converter RSA private key to hex and back.
     */
    @Test
    public final void rsaPrivateKeyTest() throws NoSuchAlgorithmException {
        KeyPair pair = generateRSAKeys();
        GXPkcs8 p = new GXPkcs8(pair.getPrivate().getEncoded());
    }

    /*
     * Converter ECDSA private key to hex and back.
     */
    @Test
    public final void ecdsaPrivateKeyHexTest() throws NoSuchAlgorithmException {
        KeyPair pair = generateECDSAKeys();
        byte[] expected = pair.getPrivate().getEncoded();
        String tmp = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(tmp);
        // assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /*
     * Converter ECDSA private key to hex and back.
     */
    @Test
    public final void ecdsaPrivateKeyTest() throws NoSuchAlgorithmException {
        // Generate a key pair
        KeyPair pair = generateECDSAKeys();
        GXPkcs8 p = new GXPkcs8(pair.getPrivate().getEncoded());
    }

    /*
     * Converter RSA public key to hex and back.
     */
    @Test
    public final void rsaPublicKeyHexTest() throws NoSuchAlgorithmException {
        KeyPair pair = generateRSAKeys();
        byte[] expected = pair.getPublic().getEncoded();
        String tmp = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(tmp);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /*
     * Converter RSA public key to hex and back.
     */
    @Test
    public final void rsaPublicKeyTest() throws NoSuchAlgorithmException {
        KeyPair pair = generateRSAKeys();
        byte[] expected = pair.getPublic().getEncoded();
        GXPkcs8 p = new GXPkcs8(expected);
    }

    /*
     * Converter ECDSA public key to hex and back.
     */
    @Test
    public final void ecdsaPublicKeyHexTest() throws NoSuchAlgorithmException {
        KeyPair pair = generateECDSAKeys();
        byte[] expected = pair.getPublic().getEncoded();
        String tmp = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(tmp);
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /*
     * Converter ECDSA public key to hex and back.
     */
    @Test
    public final void ecdsaPublicKeyTest() throws NoSuchAlgorithmException {
        KeyPair pair = generateECDSAKeys();
        byte[] expected = pair.getPublic().getEncoded();
        GXPkcs8 p = new GXPkcs8(expected);
    }

    /*
     * Converter CRS to hex and back.
     */
    @Test
    public final void crsHexTest() {
        byte[] expected = GXCommon.fromBase64(
                "MIIBgDCCASYCAQAwgZAxCzAJBgNVBAYTAkZJMRIwEAYDVQQIDAlQaXJrYW5tYWExEDAOBgNVBAcMB1RhbXBlcmUxEjAQBgNVBAoMCUd1cnV4IEx0ZDEUMBIGA1UECwwLZGV2ZWxvcG1lbnQxEjAQBgNVBAMMCUd1cnV4IEx0ZDEdMBsGCSqGSIb3DQEJARYOZ3VydXhAZ3VydXguZmkwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAAS8RwOUZXv/MYYxaE2/NCofycZRhM8pOsCdyb0rTU2VQ90NhcTICKveQf+KVomzgc1lmnCJvcUPfzQt0ZLhnAVroDMwFwYJKoZIhvcNAQkHMQoMCG1haHRhdmFhMBgGCSqGSIb3DQEJAjELDAlHdXJ1eCBMdGQwCgYIKoZIzj0EAwIDSAAwRQIhAMqMnPBVUo1nUDQ/g1eAS//okeY0EqVPS2DucLI7K5X7AiBT1M1RciREm1uCirLJGXxN4fj+yRlvquhJ9HybzWIJNQ==");
        String tmp = GXAsn1Converter.pduToXml(expected);
        byte[] actual = GXAsn1Converter.xmlToPdu(tmp);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        assertEquals(GXCommon.toBase64(expected), GXCommon.toBase64(actual));
    }

    /*
     * All JMEs are not supporting base 64 parser.
     */
    @Test
    public final void base64Test() {
        String expectedString =
                "MIICpDCCAYygAwIBAgIIGo9E7vm1zW4wDQYJKoZIhvcNAQELBQAwEjEQMA4GA1UEAwwHcm9vdCBjYTAeFw0xNjExMDMwMDAwMDBaFw0xODExMDMwMDAwMDBaMBIxEDAOBgNVBAMMB3Jvb3QgY2EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCbyS9Qze7Z20xeL1pclF09c0mPShS+j4r/ClopxnZrNoATmCR1or/PeWupVU3jso9zxEEeZLzyDxqEJieS7xqlV9uLABQDMp9X/iWw2Sk9g4SOw5gdhBHdshfA7u+b0BD1iVWUgDDAutjHh+XlOidftjl8vPTqTZzvvxJaAFdfIEP53qCWFx0e6iEp3TXPRSqGzBMnjQlSbkpq7A8sAtpd2pNv8+/WyQI2Q2VPLLesLkePj/fFiPCpv+BEi/9/741efbWigEA+cTGbu1D7JBPYrY4pVy7AeWwmxCy5BYkUQL7vaumCTdTdbI3nzAFc+fkdzRKywk/BpTlnDCPkdzgVAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAAVDA98lUt8tQTMyhxlo6MMjQDXGLoYQVgtKjmL7iZoKNLZBLW27sO9HLrhfQDTEMrFOZaEdHu6FkF+p5HrB4SCw32nR6LLlg8wqgiUU8QaOIQEepB308zeE9PjdRhv9cRagVDbldOLFR3LETVbxHfHtE52LneEfeHdRCKSgZ+HTazJiMnMWfe46OCL7+vQUjmAb1e6NIYVh1Ofg6Y5QTkWQ3ksLNeZrBdErxdLf/pQE9OV7BJWmBpdE4VONh1Kq1dG/gc8Gm7bM1Z2XjblgU6gYM68VBPmWsEUqzls2LUb4ogPdBluBrX9HCD/t8XpaHhz47eGOgkq+YWVZjt/+vz0=";
        byte[] expected = GXCommon.fromBase64(expectedString);

        byte[] actual = GXCommon.fromBase64(expectedString);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        String actualString = GXCommon.toBase64(expected);
        assertEquals(expectedString, actualString);
    }

    /*
     * All JMEs are not supporting base 64 parser.
     */
    @Test
    public final void base64Test2() {
        String expectedString = "TWFodGF2YWEgDQpWYWkgDQoNCk1pdMOkPw==";
        byte[] expected = GXCommon.fromBase64(expectedString);
        byte[] actual = GXCommon.fromBase64(expectedString);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        String actualString = GXCommon.toBase64(expected);
        assertEquals(expectedString, actualString);
    }

    @Test
    public final void crsTest()
            throws SignatureException, NoSuchAlgorithmException, IOException {
        byte[] expected = GXCommon.fromBase64(
                "MIICqDCCAZACAQAwZTERMA8GA1UEAwwIZ3VydXguZmkxEjAQBgNVBAoMCUd1cnV4IEx0ZDEQMA4GA1UEBwwHVGFtcGVyZTELMAkGA1UEBhMCRkkxHTAbBgkqhkiG9w0BCQEWDmd1cnV4QGd1cnV4LmZpMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuy8bkZRSmjj4ecROGqfRNCU/P86GxFqAz/UaJMXHgdAayO+/+bWPsCSY44bcHfhWrOS3OElffIDaw1d4r0yZG3lSvOqjgrc6SFmsNdjhzOpNRM3uw8Qiqri43r1iczSoKyo5/4AtwNippLVC1rGaqkE4mS+cEEQuvWdknPJ5PPCWU4sOj8XzBMpgpFy7L0dPwFkXO6d1Exux1ZUD00kI9D46LcMsWGyo/Vs0WYF93CxkAv4hIgN2BQEWdvOY7v+EuRqXxeeGMkB3Rnla7PTm+B6AKx+GVudx9Si6tT1vetLgchH7GQQwMri3aac5tajo7cPowF0GDUB8g4D2Q3Cr8QIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAIZBJrxstNBOKhWcIH9LnoGG8xUWx+zEK0AOwo6zOJqJwu/rh9+KSV4r2SCtnGZxfB0IRdD88CnFUHazisK/xu34OWboS6Ml/emCWi+P+vsZvFEupySjYjos+DdjO/EjlRc7Woj37ghHRZiS0tvFyxPHkJmPDyYZK0tiwiwfkfN56whbVv/7MoB8eCJW6aG87Ikzm0kBkAyi2p3oaMjEekT8+2kBICoUAUb9YQDHMrc319tKCib8KnMB+09U1iZk/Y7gqaGKv1ItZV1QvnCpo9RoxEbK/Fai7rRilWDo2POt+zN94uZnyvESZYYgvd5y+iWPCuCxX0Dg/POEKRiWEX");
        GXPkcs10 c = new GXPkcs10(expected);
        byte[] actual = c.getEncoded();
        // Hex values are not same.
        // assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        // assertEquals(
        // "PKCS#10certificaterequest:Version:V1Subject:CN=gurux.fi,O=GuruxLtd,L=Tampere,C=FI,E=gurux@gurux.fiAlgorithm:RsaEncryptionParameters:PublicKey:SunRSApublickey,2048bitsmodulus:23629792696430309451171285387820433780969681166269290493021296461127412423488705282146670657120814178718675745362049253754016411061818957619840199125189897999756563287589266002297477219413617382816951380902340764244337143925925526959997589963069656991425311312629748677864752086856353686125911841298033626632564314627190162301131564920268167290514762075986774406015714357713007615499827274986724212505846592952707899714124233525427457081690216847546782744355313582981375133082777601068822480633543237159802046530325102453187924325198867108385577506593529973459228548199418527165475067151774157135493630776392983555057publicexponent:65537Signaturealgorithm:SHA_256_RSASignatureparameters:Signature:0864126BC6CB4D04E2A159C207F4B9E8186F31516C7ECC42B400EC28EB3389A89C2EFEB87DF8A495E2BD920AD9C66717C1D0845D0FCF029C55076B38AC2BFC6EDF83966E84BA325FDE9825A2F8FFAFB19BC512EA724A3623A2CF837633BF12395173B5A88F7EE0847459892D2DBC5CB13C790998F0F26192B4B62C22C1F91F379EB085B56FFFB32807C782256E9A1BCEC89339B4901900CA2DA9DE868C8C47A44FCFB6901202A140146FD6100C732B737D7DB4A0A26FC2A7301FB4F54D62664FD8EE0A9A18ABF522D655D50BE70A9A3D468C446CAFC56A2EEB4629560E8D8F3ADFB337DE2E667CAF112658620BDDE72FA258F0AE0B15F40E0FCF384291896117",
        // c.toString().replace(" ", "").replace("\r", "").replace("\n",""));
    }

    @Test
    public final void gurux() throws NoSuchAlgorithmException,
            InvalidKeyException, SignatureException {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        KeyPair kp = kpg.genKeyPair();
        Signature instance = Signature.getInstance("SHA1withRSA");
        instance.initSign(kp.getPrivate());
        instance.update("Gurux".getBytes());
        byte[] signature = instance.sign();
        instance = Signature.getInstance("SHA1withRSA");
        instance.initVerify(kp.getPublic());
        instance.update("Gurux".getBytes());
        assertEquals(true, instance.verify(signature));
    }

    /*
     * ECDSA CRS generated with open SSL.
     */
    @Test
    public final void openSslCrsTest()
            throws SignatureException, NoSuchAlgorithmException, IOException {
        byte[] expected = GXCommon.fromBase64(
                "MIIBgDCCASYCAQAwgZAxCzAJBgNVBAYTAkZJMRIwEAYDVQQIDAlQaXJrYW5tYWExEDAOBgNVBAcMB1RhbXBlcmUxEjAQBgNVBAoMCUd1cnV4IEx0ZDEUMBIGA1UECwwLZGV2ZWxvcG1lbnQxEjAQBgNVBAMMCUd1cnV4IEx0ZDEdMBsGCSqGSIb3DQEJARYOZ3VydXhAZ3VydXguZmkwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAAS8RwOUZXv/MYYxaE2/NCofycZRhM8pOsCdyb0rTU2VQ90NhcTICKveQf+KVomzgc1lmnCJvcUPfzQt0ZLhnAVroDMwFwYJKoZIhvcNAQkHMQoMCG1haHRhdmFhMBgGCSqGSIb3DQEJAjELDAlHdXJ1eCBMdGQwCgYIKoZIzj0EAwIDSAAwRQIhAMqMnPBVUo1nUDQ/g1eAS//okeY0EqVPS2DucLI7K5X7AiBT1M1RciREm1uCirLJGXxN4fj+yRlvquhJ9HybzWIJNQ==");
        GXPkcs10 c = new GXPkcs10(expected);
        c = new GXPkcs10(c.getEncoded());

        byte[] actual = c.getEncoded();
        // Hex values are not same.
        // assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        // assertEquals("", c.toString());
    }

    /*
     * ASN-1 test.
     */
    @Test
    public final void asn1Test() {
        GXAsn1Converter.pduToXml("03 04 06 6E 5D C0");
    }

    /*
     * ASN-1 Base 64 test.
     */
    @Test
    public final void asn1Base64Test() {
        GXAsn1Converter.pduToXml(
                "MIICpDCCAYygAwIBAgIIGo9E7vm1zW4wDQYJKoZIhvcNAQELBQAwEjEQMA4GA1UEAwwHcm9vdCBjYTAeFw0xNjExMDMwMDAwMDBaFw0xODExMDMwMDAwMDBaMBIxEDAOBgNVBAMMB3Jvb3QgY2EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCbyS9Qze7Z20xeL1pclF09c0mPShS+j4r/ClopxnZrNoATmCR1or/PeWupVU3jso9zxEEeZLzyDxqEJieS7xqlV9uLABQDMp9X/iWw2Sk9g4SOw5gdhBHdshfA7u+b0BD1iVWUgDDAutjHh+XlOidftjl8vPTqTZzvvxJaAFdfIEP53qCWFx0e6iEp3TXPRSqGzBMnjQlSbkpq7A8sAtpd2pNv8+/WyQI2Q2VPLLesLkePj/fFiPCpv+BEi/9/741efbWigEA+cTGbu1D7JBPYrY4pVy7AeWwmxCy5BYkUQL7vaumCTdTdbI3nzAFc+fkdzRKywk/BpTlnDCPkdzgVAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAAVDA98lUt8tQTMyhxlo6MMjQDXGLoYQVgtKjmL7iZoKNLZBLW27sO9HLrhfQDTEMrFOZaEdHu6FkF+p5HrB4SCw32nR6LLlg8wqgiUU8QaOIQEepB308zeE9PjdRhv9cRagVDbldOLFR3LETVbxHfHtE52LneEfeHdRCKSgZ+HTazJiMnMWfe46OCL7+vQUjmAb1e6NIYVh1Ofg6Y5QTkWQ3ksLNeZrBdErxdLf/pQE9OV7BJWmBpdE4VONh1Kq1dG/gc8Gm7bM1Z2XjblgU6gYM68VBPmWsEUqzls2LUb4ogPdBluBrX9HCD/t8XpaHhz47eGOgkq+YWVZjt/+vz0=");
    }

    @Test
    public final void crsGenerateTest() throws NoSuchAlgorithmException {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
        KeyPair kp = kpg.genKeyPair();
        GXPkcs10 actual = new GXPkcs10();
        actual.setPublicKey(kp.getPublic());
        actual.setSubject(
                "CN=gurux.fi, O=Gurux Ltd, L=Tampere, C=FI, E=gurux@gurux.fi");
        actual.sign(kp, HashAlgorithm.SHA256withECDSA);
        actual = new GXPkcs10(actual.getEncoded());
    }

    /*
     * X509 certificate test.
     */
    @Test
    public final void x509CertificateTest() throws CertificateException {
        byte[] expected = GXCommon.fromBase64(
                "MIICpDCCAYygAwIBAgIIGo9E7vm1zW4wDQYJKoZIhvcNAQELBQAwEjEQMA4GA1UEAwwHcm9vdCBjYTAeFw0xNjExMDMwMDAwMDBaFw0xODExMDMwMDAwMDBaMBIxEDAOBgNVBAMMB3Jvb3QgY2EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCbyS9Qze7Z20xeL1pclF09c0mPShS+j4r/ClopxnZrNoATmCR1or/PeWupVU3jso9zxEEeZLzyDxqEJieS7xqlV9uLABQDMp9X/iWw2Sk9g4SOw5gdhBHdshfA7u+b0BD1iVWUgDDAutjHh+XlOidftjl8vPTqTZzvvxJaAFdfIEP53qCWFx0e6iEp3TXPRSqGzBMnjQlSbkpq7A8sAtpd2pNv8+/WyQI2Q2VPLLesLkePj/fFiPCpv+BEi/9/741efbWigEA+cTGbu1D7JBPYrY4pVy7AeWwmxCy5BYkUQL7vaumCTdTdbI3nzAFc+fkdzRKywk/BpTlnDCPkdzgVAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAAVDA98lUt8tQTMyhxlo6MMjQDXGLoYQVgtKjmL7iZoKNLZBLW27sO9HLrhfQDTEMrFOZaEdHu6FkF+p5HrB4SCw32nR6LLlg8wqgiUU8QaOIQEepB308zeE9PjdRhv9cRagVDbldOLFR3LETVbxHfHtE52LneEfeHdRCKSgZ+HTazJiMnMWfe46OCL7+vQUjmAb1e6NIYVh1Ofg6Y5QTkWQ3ksLNeZrBdErxdLf/pQE9OV7BJWmBpdE4VONh1Kq1dG/gc8Gm7bM1Z2XjblgU6gYM68VBPmWsEUqzls2LUb4ogPdBluBrX9HCD/t8XpaHhz47eGOgkq+YWVZjt/+vz0=");

        // expected = GXCommon.fromBase64(
        // "MIID2TCCAsGgAwIBAgIJAK+6wroNsSKCMA0GCSqGSIb3DQEBCwUAMIGCMQswCQYDVQQGEwJBVTETMBEGA1UECAwKU29tZS1TdGF0ZTEOMAwGA1UEBwwFR3VydXgxDjAMBgNVBAoMBU1pa2tvMQ8wDQYDVQQLDAZUZXN0YWExDjAMBgNVBAMMBUthdGphMR0wGwYJKoZIhvcNAQkBFg5ndXJ1eEBndXJ1eC5maTAeFw0xNzAyMjMxNzA5MzlaFw0xNzAzMjUxNzA5MzlaMIGCMQswCQYDVQQGEwJBVTETMBEGA1UECAwKU29tZS1TdGF0ZTEOMAwGA1UEBwwFR3VydXgxDjAMBgNVBAoMBU1pa2tvMQ8wDQYDVQQLDAZUZXN0YWExDjAMBgNVBAMMBUthdGphMR0wGwYJKoZIhvcNAQkBFg5ndXJ1eEBndXJ1eC5maTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMmMSnmUgxL35EqlSY72+WeHxzP9xxDFK8rQhgYS1WztdODD+I6n0BwLE/5SUJJ7HbEg7Mawqzvyp2f/eee0qKLrjb4F+CMr3l+81MgNal2I3oPaWkclLd4GWQYtv6SctTy3p9w76ba31N438Br8ZMtQQfraqonnfL+xvcsxde59z06yeqaKWf4tam4IDdRrJVmyUumWJelTuXev0c31op4TeI3LlYsjLye20ncgPiy1lWzIS1y/3TzbmxYuGWyl1FbAVJjebPzHtTRFlpkGaGiTJEntxSrABgN47OEim5nls70nBabsIqGqqntj8v1XNMRL4CvIKRQJI8tRqjKfK6kCAwEAAaNQME4wHQYDVR0OBBYEFL2WVoQDGDitCy8MGEeNtgRyfaqVMB8GA1UdIwQYMBaAFL2WVoQDGDitCy8MGEeNtgRyfaqVMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQELBQADggEBAIzLPbVBqZ+XcDoEJl1G/LTj/xsygB0gfNZ8kF8nnArog0shIab5yZlwXZY57xLeItw1byqxET9n6YwyXACv5e7+G9fv7knDYpy6foNOxH7PDVQs6F/Tk+nr7Lgcnoo7erdTDMwFB+1+0LEFNgvmyEUd/oLK0UJEz80bCkonMMFCBj/hbi8bySBIuwA5dZb3188lxhPXNTVZ7SZrcaVFk3smHpyn/as7lpunr9+SoN2WWaEgDjyTTDCZ+dUsSWnfVYxRuRFIK71WueLxa7cnYIsScE4Mo9WV+2bCczmaGx7NTsF2gDByeCjvyQo+l4ibEftdhX+jfM22LbYSmL9/RV0=");

        expected = GXCommon.fromBase64(
                "MIIDrTCCApWgAwIBAgIJAPFjqcOo6H7sMA0GCSqGSIb3DQEBCwUAMIGHMQswCQYDVQQGEwJTVjESMBAGA1UECAwJUGlya2FubWFhMRAwDgYDVQQHDAdUYW1wZXJlMQ4wDAYDVQQKDAVHdXJ1eDEMMAoGA1UECwwDRGV2MRQwEgYDVQQDDAsxOTIuMTY4LjEuMTEeMBwGCSqGSIb3DQEJARYPZ3VydXhAZ3VydXguY29tMB4XDTE3MDIyMzIxMTE1OFoXDTI3MDIyMTIxMTE1OFowgYcxCzAJBgNVBAYTAlNWMRIwEAYDVQQIDAlQaXJrYW5tYWExEDAOBgNVBAcMB1RhbXBlcmUxDjAMBgNVBAoMBUd1cnV4MQwwCgYDVQQLDANEZXYxFDASBgNVBAMMCzE5Mi4xNjguMS4xMR4wHAYJKoZIhvcNAQkBFg9ndXJ1eEBndXJ1eC5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDJgjZXNpX2YBCqYN7ytMmi71XV97Yl2wgFin5onXPJ5H1q2nPRAeGv3nXwFT4Li4oItMJUpCYmDccqMXzUpkkqFgfhU2BnL0ikA24feDBztBn334NodBEoH5HPYs4hD1S8PvXHv2k12onPT7QHXmr7x6u3ZFNR3ZFzimfkW4tCSS+FraKsuIHAwGwP6+h6fNFb/ZVxYNFrfE9vnvqTrnkEkgdAvN7WMbSqWXJN+WW8JSmuNfY8HXgMg/UaU4titD4V6qKVT/XPuT32LOGE2ThUTg54uUzyB778UpND1WxobsaopDQ8g4NLb5gUBBX+4FQjZXpYTkZFVomUvA/i9iMXAgMBAAGjGjAYMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgXgMA0GCSqGSIb3DQEBCwUAA4IBAQCXkksIa58m++KF4Wpc1mSuJv4PEsqoMKeN+44MKsv8fGy/VWHYoNL9KC7Kc1NgPo89iNc4oSAR/XaJ6OT/RylwT7LLOQugV/+xHNAf47PVzcpM1dMivjfHobS7YgCmqaIFfWwow542ZUsc6Gv0+wUTfURLDMSE6UpRCA/mtrDQ73bqXzkqhFvWm8DA12E3KJkofQJjamAb95IvmgM4+x2ty2ajqR/l8uUQqqikcyHIj6ObUE47DqR+ePeYWFIAMLQ3HpthDNAf7WG1dXiVdxdA5uIyUvoHiD6iGsVgsHH2HwfrD28TwuLSMc2x4fb3i38eCvs0jiMOh5gPEMXbpZ44");

        InputStream stream = new ByteArrayInputStream(expected);
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        String str =
                cf.generateCertificates(stream).iterator().next().toString();
        System.out.println(str);
        GXx509Certificate c = new GXx509Certificate(expected);
        byte[] actual = c.getEncoded();
        GXx509Certificate c2 = new GXx509Certificate(actual);
        actual = c2.getEncoded();
        actual = null;
        // TODO: UTC time is serialized as normal time.
        // assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /*
     * ECDSA CRS generated with open SSL.
     */
    @Test
    public final void openSslCrstoXmlTest() {
        byte[] expected = GXCommon.fromBase64(
                "MIIBgDCCASYCAQAwgZAxCzAJBgNVBAYTAkZJMRIwEAYDVQQIDAlQaXJrYW5tYWExEDAOBgNVBAcMB1RhbXBlcmUxEjAQBgNVBAoMCUd1cnV4IEx0ZDEUMBIGA1UECwwLZGV2ZWxvcG1lbnQxEjAQBgNVBAMMCUd1cnV4IEx0ZDEdMBsGCSqGSIb3DQEJARYOZ3VydXhAZ3VydXguZmkwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAAS8RwOUZXv/MYYxaE2/NCofycZRhM8pOsCdyb0rTU2VQ90NhcTICKveQf+KVomzgc1lmnCJvcUPfzQt0ZLhnAVroDMwFwYJKoZIhvcNAQkHMQoMCG1haHRhdmFhMBgGCSqGSIb3DQEJAjELDAlHdXJ1eCBMdGQwCgYIKoZIzj0EAwIDSAAwRQIhAMqMnPBVUo1nUDQ/g1eAS//okeY0EqVPS2DucLI7K5X7AiBT1M1RciREm1uCirLJGXxN4fj+yRlvquhJ9HybzWIJNQ==");
        String expectedXml =
                "<Sequence>\r\n <Sequence>\r\n  <Byte>0</Byte>\r\n  <Sequence>\r\n   <Set>\r\n    <Sequence>\r\n     <ObjectIdentifier>2.5.4.6</ObjectIdentifier>\r\n     <String>FI</String>\r\n    </Sequence>\r\n   </Set>\r\n   <Set>\r\n    <Sequence>\r\n     <ObjectIdentifier>2.5.4.8</ObjectIdentifier>\r\n     <UTF8>Pirkanmaa</UTF8>\r\n    </Sequence>\r\n   </Set>\r\n   <Set>\r\n    <Sequence>\r\n     <ObjectIdentifier>2.5.4.7</ObjectIdentifier>\r\n     <UTF8>Tampere</UTF8>\r\n    </Sequence>\r\n   </Set>\r\n   <Set>\r\n    <Sequence>\r\n     <ObjectIdentifier>2.5.4.10</ObjectIdentifier>\r\n     <UTF8>Gurux Ltd</UTF8>\r\n    </Sequence>\r\n   </Set>\r\n   <Set>\r\n    <Sequence>\r\n     <ObjectIdentifier>2.5.4.11</ObjectIdentifier>\r\n     <UTF8>development</UTF8>\r\n    </Sequence>\r\n   </Set>\r\n   <Set>\r\n    <Sequence>\r\n     <ObjectIdentifier>2.5.4.3</ObjectIdentifier>\r\n     <UTF8>Gurux Ltd</UTF8>\r\n    </Sequence>\r\n   </Set>\r\n   <Set>\r\n    <Sequence>\r\n     <ObjectIdentifier>1.2.840.113549.1.9.1</ObjectIdentifier>\r\n     <IA5>gurux@gurux.fi</IA5>\r\n    </Sequence>\r\n   </Set>\r\n  </Sequence>\r\n  <Sequence>\r\n   <Sequence>\r\n    <ObjectIdentifier>1.2.840.10045.2.1</ObjectIdentifier>\r\n    <ObjectIdentifier>1.2.840.10045.3.1.7</ObjectIdentifier>\r\n   </Sequence>\r\n   <BitString>0000010010111100010001110000001110010100011001010111101111111111001100011000011000110001011010000100110110111111001101000010101000011111110010011100011001010001100001001100111100101001001110101100000010011101110010011011110100101011010011010100110110010101010000111101110100001101100001011100010011001000000010001010101111011110010000011111111110001010010101101000100110110011100000011100110101100101100110100111000010001001101111011100010100001111011111110011010000101101110100011001001011100001100111000000010101101011</BitString>\r\n  </Sequence>\r\n  <Context>\r\n   <Sequence>\r\n    <ObjectIdentifier>1.2.840.113549.1.9.7</ObjectIdentifier>\r\n    <Set>\r\n     <UTF8>mahtavaa</UTF8>\r\n    </Set>\r\n   </Sequence>\r\n   <Sequence>\r\n    <ObjectIdentifier>1.2.840.113549.1.9.2</ObjectIdentifier>\r\n    <Set>\r\n     <UTF8>Gurux Ltd</UTF8>\r\n    </Set>\r\n   </Sequence>\r\n  </Context>\r\n </Sequence>\r\n <Sequence>\r\n  <ObjectIdentifier>1.2.840.10045.4.3.2</ObjectIdentifier>\r\n </Sequence>\r\n <BitString>0011000001000101000000100010000100000000110010101000110010011100111100000101010101010010100011010110011101010000001101000011111110000011010101111000000001001011111111111110100010010001111001100011010000010010101001010100111101001011011000001110111001110000101100100011101100101011100101011111101100000010001000000101001111010100110011010101000101110010001001000100010010011011010110111000001010001010101100101100100100011001011111000100110111100001111110001111111011001001000110010110111110101010111010000100100111110100011111001001101111001101011000100000100100110101</BitString>\r\n</Sequence>\r\n";
        String actualXml = GXAsn1Converter.pduToXml(expected);
        assertEquals(expectedXml, actualXml);
        byte[] actual = GXAsn1Converter.xmlToPdu(expectedXml);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }
}
