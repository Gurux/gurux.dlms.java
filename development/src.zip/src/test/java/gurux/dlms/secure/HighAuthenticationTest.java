//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms.secure;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.internal.GXCommon;

/**
 * @author Gurux Ltd
 */
public class HighAuthenticationTest {
    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
    }

    @After
    public final void tearDown() {
    }

    /**
     * A test for High authentication generation using Indian standard.
     */
    @Test
    public final void highAuthenticationIndianTest() {
        byte[] secret1 = new byte[] { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06,
                0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f };
        byte[] data = GXCommon.hexToBytes("00112233445566778899aabbccddeeff");
        GXDLMSChipperingStream.aes1Encrypt(data, 0, secret1);
        assertEquals("69 C4 E0 D8 6A 7B 04 30 D8 CD B7 80 70 B4 C5 5A",
                GXCommon.toHex(data));
        GXDLMSChipperingStream.aes1Decrypt(data, secret1);
        assertEquals("00 11 22 33 44 55 66 77 88 99 AA BB CC DD EE FF",
                GXCommon.toHex(data));
    }
}
