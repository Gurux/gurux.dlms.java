//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.ClockStatus;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectCollection;
import gurux.dlms.objects.enums.ClockBase;

/**
 * @author Gurux Ltd
 */
public class ClockTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient(true, 16, 1, Authentication.NONE, null,
                InterfaceType.WRAPPER);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = target.read(item, index);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(new GXByteBuffer(tmp), info);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, info.getValue());
    }

    /**
     * A test for Logical Name (1st) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute1Test() {
        String expected = "1.1.1.1.1.255";
        GXDLMSClock item = new GXDLMSClock(expected);
        assertEquals(expected, readTest(item, 1));
    }

    /**
     * A test for time (2rt) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute2Test() {
        SimpleDateFormat sd = new SimpleDateFormat();
        java.util.Date expected = Calendar.getInstance().getTime();
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setTime(new GXDateTime(expected));
        assertEquals(sd.format(expected), readTest(item, 2).toString());
    }

    /**
     * A test for time zone (3rd) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute3Test() {
        int expected = -60;
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setTimeZone(expected);
        assertEquals(expected, readTest(item, 3));
    }

    /**
     * A test for Status (4) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute4Test() {
        java.util.Set<ClockStatus> expected =
                EnumSet.of(ClockStatus.DAYLIGHT_SAVE_ACTIVE);
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setStatus(expected);
        readTest(item, 4);
        assertEquals(expected, item.getStatus());
    }

    /**
     * A test for begin time (5) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute5Test() {
        DateFormat df = new SimpleDateFormat("MM/dd");
        java.util.Date expected = Calendar.getInstance().getTime();
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setBegin(new GXDateTime(expected));
        readTest(item, 5);
        assertEquals(df.format(expected),
                df.format(item.getBegin().getCalendar().getTime()));
    }

    /**
     * A test for end time (6) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute6Test() {
        DateFormat df = new SimpleDateFormat("MM/dd");
        java.util.Date expected = Calendar.getInstance().getTime();
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setEnd(new GXDateTime(expected));
        readTest(item, 6);
        assertEquals(df.format(expected),
                df.format(item.getEnd().getCalendar().getTime()));
    }

    /**
     * A test for devitation (7) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute7Test() {
        int expected = 12;
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setDeviation(expected);
        assertEquals(expected, readTest(item, 7));
    }

    /**
     * A test for enabled (8) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute8Test() {
        boolean expected = true;
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setEnabled(expected);
        assertEquals(expected, readTest(item, 8));
    }

    /**
     * A test for clock base (9) attribute of Clock Object.
     */
    @Test
    public final void clockAttribute9Test() {
        ClockBase expected = ClockBase.GPS;
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        item.setClockBase(expected);
        assertEquals(expected, readTest(item, 9));
    }

    /**
     * A test for adjust to quarter (1) attribute of Clock Object.
     */
    @Test
    public final void clockMethod1Test() {
        java.util.Calendar start = Calendar.getInstance();
        start.set(java.util.Calendar.HOUR_OF_DAY, 23);
        start.set(java.util.Calendar.MINUTE, 53);
        start.set(java.util.Calendar.SECOND, 10);
        start.set(java.util.Calendar.MILLISECOND, 10);

        DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
        java.util.Calendar expected = Calendar.getInstance();
        expected.set(java.util.Calendar.HOUR_OF_DAY, 00);
        expected.set(java.util.Calendar.MINUTE, 00);
        expected.set(java.util.Calendar.SECOND, 00);
        expected.set(java.util.Calendar.MILLISECOND, 00);
        expected.add(java.util.Calendar.DATE, 1);

        GXDLMSObjectCollection coll = new GXDLMSObjectCollection(target);
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        coll.add(item);
        item.setTime(new GXDateTime(start.getTime()));
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = item.adjustToQuarter(target);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        readTest(item, 2);
        assertEquals(df.format(expected.getTime()),
                df.format(item.getTime().getCalendar().getTime()));
    }

    /**
     * A test for adjust to minute (3) attribute of Clock Object.
     */
    @Test
    public final void clockMethod3Test() {
        java.util.Calendar start = Calendar.getInstance();
        start.set(java.util.Calendar.HOUR_OF_DAY, 23);
        start.set(java.util.Calendar.MINUTE, 53);
        start.set(java.util.Calendar.SECOND, 31);
        start.set(java.util.Calendar.MILLISECOND, 10);

        DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
        java.util.Calendar expected = Calendar.getInstance();
        expected.set(java.util.Calendar.HOUR_OF_DAY, 23);
        expected.set(java.util.Calendar.MINUTE, 54);
        expected.set(java.util.Calendar.SECOND, 0);
        expected.set(java.util.Calendar.MILLISECOND, 00);

        GXDLMSObjectCollection coll = new GXDLMSObjectCollection(target);
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        coll.add(item);
        item.setTime(new GXDateTime(start.getTime()));
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = item.adjustToMinute(target);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        readTest(item, 2);
        assertEquals(df.format(expected.getTime()),
                df.format(item.getTime().getCalendar().getTime()));
    }

    /**
     * A test for preset adjusting time (5) attribute of Clock Object.
     */
    @Test
    public final void clockMethod5Test() {
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
        Date expected = Calendar.getInstance().getTime();

        GXDLMSObjectCollection coll = new GXDLMSObjectCollection(target);
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        coll.add(item);
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff =
                item.presetAdjustingTime(target, expected, expected, expected);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        readTest(item, 2);
        assertEquals(df.format(expected),
                df.format(item.getTime().getCalendar().getTime()));
    }

    /**
     * A test for time shift (6) attribute of Clock Object.
     */
    @Test
    public final void clockMethod6Test() {
        java.util.Calendar start = Calendar.getInstance();
        start.set(java.util.Calendar.HOUR_OF_DAY, 22);
        start.set(java.util.Calendar.MINUTE, 00);
        start.set(java.util.Calendar.SECOND, 00);
        start.set(java.util.Calendar.MILLISECOND, 10);

        DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
        java.util.Calendar expected = Calendar.getInstance();
        expected.set(java.util.Calendar.HOUR_OF_DAY, 21);
        expected.set(java.util.Calendar.MINUTE, 59);
        expected.set(java.util.Calendar.SECOND, 30);
        expected.set(java.util.Calendar.MILLISECOND, 00);

        GXDLMSObjectCollection coll = new GXDLMSObjectCollection(target);
        GXDLMSClock item = new GXDLMSClock("1.1.1.1.1.255");
        coll.add(item);
        item.setTime(new GXDateTime(start.getTime()));
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        server.handleRequest(target.snrmRequest());
        server.handleRequest(target.aarqRequest()[0]);
        byte[][] buff = item.shiftTime(target, -30);
        byte[] tmp = server.handleRequest(buff[0]);
        target.getData(tmp, info);
        readTest(item, 2);
        assertEquals(df.format(expected.getTime()),
                df.format(item.getTime().getCalendar().getTime()));
    }
}
