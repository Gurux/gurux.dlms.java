//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TimeZone;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.ClockStatus;
import gurux.dlms.enums.Conformance;
import gurux.dlms.enums.DataType;
import gurux.dlms.enums.DateTimeSkips;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.ObjectType;
import gurux.dlms.enums.RequestTypes;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationShortName;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectCollection;
import gurux.dlms.objects.GXDLMSProfileGeneric;
import gurux.dlms.objects.GXDLMSRegister;
import gurux.dlms.secure.GXDLMSSecureClient;

/**
 * This class implements unit tests for Landis + Gyr.
 */
public class LGZTest {
    /**
     * DLMS Client.
     */
    private GXDLMSSecureClient target = null;

    /**
     * Constructor.
     */
    public LGZTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSSecureClient();
        target.setClientAddress(16);
        target.setServerAddress(1);
        target.getSettings().setSkipFrameCheck(true);
    }

    @After
    public final void tearDown() {
    }

    /**
     * A test for SNRM Request
     */
    @Test
    public final void snrmRequestTest() {
        byte[] expected = Helpers2.getMessage("/LG/SNRMRequest.txt");
        byte[] actual = target.snrmRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for UA response
     */
    @Test
    public final void uaResponseTest() {
        byte[] data = Helpers2.getMessage("/LG/UAResponse.txt");
        GXReplyData reply = new GXReplyData();
        target.getData(data, reply);
        target.parseUAResponse(reply.getData());
        assertEquals((short) 128, target.getLimits().getMaxInfoRX());
        assertEquals((short) 62, target.getLimits().getMaxInfoTX());
        assertEquals((long) 1, target.getLimits().getWindowSizeRX());
        assertEquals((long) 1, target.getLimits().getWindowSizeTX());
    }

    /**
     * A test for AARQ Request
     */
    @Test
    public final void aarqRequestTest() {
        byte[] expected = Helpers2.getMessage("/LG/AARQRequest.txt");
        target.getProposedConformance().remove(Conformance.GENERAL_PROTECTION);
        byte[][] actual = target.aarqRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual[0]));
    }

    /**
     * A test for AARE Response
     */
    @Test
    public final void aareResponseTest() {
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());
    }

    /**
     * A test for HDLC frame in multiple parts.
     */
    @Test
    public final void frameInMultiplePartsTest() {
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXByteBuffer tmp = new GXByteBuffer();
        GXReplyData info = new GXReplyData();
        for (byte it : data) {
            tmp.setUInt8(it);
            target.getData(tmp, info);
        }
        if (!info.isComplete() || info.isMoreData()) {
            throw new RuntimeException("Failed");
        }
        target.parseAareResponse(info.getData());

    }

    /**
     * A test for SNSettings
     */
    @Test
    public final void snSettingsTest() {
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.READ));
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.WRITE));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.INFORMATION_REPORT));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.MULTIPLE_REFERENCES));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.PARAMETERIZED_ACCESS));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.UN_CONFIRMED_WRITE));
    }

    /**
     * A test for Disconnected Request
     */
    @Test
    public final void disconnectRequestTest() {
        byte[] expected = Helpers2.getMessage("/LG/DisconnectRequest.txt");
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        byte[] actual = (byte[]) target.disconnectRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Get Objects Request
     */
    @Test
    public final void getObjectsTest() {
        byte[] expected = Helpers2.getMessage("/LG/GetObjects.txt");
        byte[] actual = (byte[]) target.getObjectsRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Keep Alive request.
     */
    @Test
    public final void keepAliveTest() {
        byte[] expected = Helpers2.getMessage("/LG/KeepAlive.txt");
        byte[] actual = target.keepAlive();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Parse Objects.
     */
    @Test
    public final void parseObjectsTest() {
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        data = Helpers2.getMessage("/LG/ParseObjects.txt");
        GXDLMSObjectCollection objs =
                target.parseObjects(new GXByteBuffer(data), true);
        assertEquals(186, objs.size());
    }

    /**
     * A test for Parse Objects.
     */
    @Test
    public final void parseObjectsMessagesTest() {
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        info.setPeek(true);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        String[] messages =
                Helpers2.getMessages("/LG/ParseObjectsMessages.txt");
        int cnt = messages.length;
        info.clear();
        for (int pos = 0; pos < cnt; pos += 2) {
            // byte[] send = Helpers2.getBytes(messages[pos]);
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            assertEquals(240, info.getTotalCount());
            assertEquals(((Object[]) info.getValue()).length, info.getCount());
        }
        GXDLMSObjectCollection objects =
                target.parseObjects(info.getData(), true);
        assertEquals(190, objects.size());
    }

    /**
     * Server initial function test.
     */
    @Test
    public final void serverConnectionTest() {
        GXReplyData info = new GXReplyData();
        TestServer server = new TestServer(new GXDLMSAssociationShortName(),
                InterfaceType.HDLC);
        GXDLMSClock clock = new GXDLMSClock("0.0.1.0.0.255");
        server.getItems().add(clock);
        server.initialize();
        byte[] data = target.snrmRequest();
        data = server.handleRequest(data);
        target.getData(data, info);
        target.parseUAResponse(info.getData());
        info.clear();
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        info.clear();
        /*
         * data = target.disconnectedModeRequest(); data =
         * server.handleRequest(data); target.getData(data, info); info.clear();
         */
        data = target.disconnectRequest();
        data = server.handleRequest(data);
        target.getData(data, info);
    }

    /**
     * A test server send all objects..
     */
    @Test
    public final void serverObjectsMessagesTest() {
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        info.setPeek(true);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        String[] messages =
                Helpers2.getMessages("/LG/ParseObjectsMessages.txt");
        int cnt = messages.length;
        info.clear();
        int pos;
        for (pos = 0; pos < cnt; pos += 2) {
            // byte[] send = Helpers2.getBytes(messages[pos]);
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            assertEquals(240, info.getTotalCount());
            assertEquals(((Object[]) info.getValue()).length, info.getCount());
        }
        GXDLMSObjectCollection objects =
                target.parseObjects(info.getData(), false);
        assertEquals(240, objects.size());

        // Get only known objects.
        info.getData().position(0);
        objects = target.parseObjects(info.getData(), true);
        info.clear();
        TestServer server = new TestServer(new GXDLMSAssociationShortName(),
                InterfaceType.HDLC);
        server.getItems().clear();
        server.getItems().addAll(objects);
        server.initialize();
        data = target.aarqRequest()[0];
        byte[] reply = server.handleRequest(data);
        target.getData(reply, info);
        target.parseAareResponse(info.getData());

        server.getLimits().setMaxInfoRX(target.getLimits().getMaxInfoRX());
        server.getLimits().setMaxInfoTX(target.getLimits().getMaxInfoTX());
        server.setMaxReceivePDUSize(target.getMaxReceivePDUSize());
        info.clear();
        data = target.getObjectsRequest();
        pos = 0;
        do {
            reply = server.handleRequest(data);
            pos += 2;
            target.getData(reply, info);
            if (info.isMoreData()) {
                data = target.receiverReady(info.getMoreData());
            }
        } while (info.isMoreData());
        GXDLMSObjectCollection objects2 =
                target.parseObjects(info.getData(), false);
        assertEquals(190, objects2.size());
    }

    /**
     * A test for Keep Alive request.
     */
    @Test
    public final void receiverReadyTest() {
        byte[] expected = Helpers2.getMessage("/LG/ReceiverReady.txt");
        byte[] actual = target.receiverReady(RequestTypes.FRAME);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Is More Data Available Block Test
     */
    @Test
    public final void isMoreDataAvailableBlockTest() {
        byte[] data = Helpers2.getMessage("/LG/IsMoreDataAvailableFrame.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        assertEquals(RequestTypes.FRAME, info.getMoreData());
    }

    /**
     * A test for Is More Data Available None Test
     */
    @Test
    public final void isMoreDataAvailableNoneTest() {
        byte[] data = Helpers2.getMessage("/LG/IsMoreDataAvailableNone.txt");
        GXReplyData info = new GXReplyData();
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        assertEquals(RequestTypes.NONE, info.getMoreData());
    }

    /**
     * A test for clock write.
     */
    @Test
    public final void writeTest() {
        target.setClientAddress(0x20);
        target.getSettings().setSkipFrameCheck(true);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 20 03 41 32 AB 08 E6 E6 00 06 01 02 2B C8 01 09 0C 07 DF 06 0F FF 00 00 00 FF FF 88 80 84 C2 7E");
        // CHECKSTYLE:ON
        GXDLMSClock c = new GXDLMSClock("0.0.1.0.0.255", 0x2BC0);
        GXDateTime dt = new GXDateTime(2015, 6, 15, 0, 0, 0, 0);
        java.util.Set<ClockStatus> s = dt.getStatus();
        s.add(ClockStatus.DAYLIGHT_SAVE_ACTIVE);
        dt.getSkip().add(DateTimeSkips.DAY_OF_WEEK);
        dt.setStatus(s);
        c.setTime(dt);
        byte[] actual = target.write(c, 2)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for read rows by entry message.
     */
    @Test
    public final void readRowsByEntry() {
        GXReplyData info = new GXReplyData();
        target.getSettings().setSkipFrameCheck(true);
        target.getData(Helpers2.getMessage("/LG/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/LG/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), true);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 24 03 21 32 12 1F E6 E6 00 05 01 04 60 E8 02 02 04 06 00 00 00 00 06 00 00 00 01 12 00 01 12 00 00 74 34 7E");
        // CHECKSTYLE:ON
        GXDLMSProfileGeneric pg = (GXDLMSProfileGeneric) objects
                .getObjects(ObjectType.PROFILE_GENERIC).get(0);
        byte[] actual = target.readRowsByEntry(pg, 0, 1)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for read rows by range message.
     */
    @Test
    public final void readRowsByRange() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/LG/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/LG/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), true);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 44 03 21 32 F6 86 E6 E6 00 05 01 04 60 E8 01 02 04 02 04 12 00 08 09 06 00 00 01 00 00 FF 0F 02 12 00 00 09 0C 07 D0 01 01 FF 00 00 00 FF FF 88 80 09 0C 07 E5 01 01 FF 00 00 00 FF FF 88 80 01 00 9A 0B 7E");
        // CHECKSTYLE:ON
        TimeZone fi;
        fi = TimeZone.getTimeZone("Europe/Helsinki");
        java.util.Calendar start = java.util.Calendar.getInstance(fi);
        start.set(2000, 0, 1, 0, 0, 0);
        java.util.Calendar end = java.util.Calendar.getInstance(fi);
        end.set(2020, 11, 31, 24, 0, 0);
        GXDLMSProfileGeneric pg = (GXDLMSProfileGeneric) objects
                .getObjects(ObjectType.PROFILE_GENERIC).get(0);
        pg.setSortObject(new GXDLMSClock("0.0.1.0.0.255"));
        byte[] actual = target.readRowsByRange(pg, start, end)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A action test.
     */
    @Test
    public final void actionTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/LG/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/LG/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), false);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 14 03 21 32 E0 53 E6 E6 00 05 01 04 72 38 01 0F 00 BF 5B 7E");
        // CHECKSTYLE:ON
        GXDLMSRegister register =
                (GXDLMSRegister) objects.getObjects(ObjectType.REGISTER).get(0);
        byte[] actual = target.method(register, 1, 0, DataType.INT8)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A read list of objects.
     */
    @Test
    public final void readObjectsTest() {
        byte[] data = Helpers2.getMessage("/LG/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        data = Helpers2.getMessage("/LG/ParseObjects.txt");
        GXDLMSObjectCollection objs =
                target.parseObjects(new GXByteBuffer(data), false)
                        .getObjects(ObjectType.REGISTER);
        List<Entry<GXDLMSObject, Integer>> list =
                new ArrayList<Entry<GXDLMSObject, Integer>>();
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(0), 1));
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(1), 1));
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 14 03 21 32 E0 53 E6 E6 00 05 02 02 72 10 02 71 48 5C CA 7E");
        // CHECKSTYLE:ON
        byte[][] actual = target.readList(list);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual[0]));
    }
}
