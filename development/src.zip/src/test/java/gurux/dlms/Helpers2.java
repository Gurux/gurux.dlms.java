//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class Helpers2 {

    /**
     * Constructor.
     */
    private Helpers2() {

    }

    static byte[] getBytes(final String str) {
        return javax.xml.bind.DatatypeConverter
                .parseHexBinary(str.replace(" ", "").replace("\r\n", "")
                        .replace("\r", "").replace("\n", ""));
    }

    static byte[] getMessage(final String path) {
        InputStream in = Helpers2.class.getResourceAsStream(path);
        if (in == null) {
            throw new RuntimeException("File not found: " + path);
        }
        Reader fr = null;
        try {
            fr = new InputStreamReader(in);
            char[] chars = new char[in.available()];
            fr.read(chars);
            return getBytes(new String(chars));
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    throw new RuntimeException(e.getMessage());
                }
            }
        }
    }

    /**
     * Get date from Finland time. This is used in Unit tests.
     * 
     * @param year
     *            Year.
     * @param month
     *            Month.
     * @param day
     *            Day.
     * @param hour
     *            Hour.
     * @param min
     *            Minutes.
     * @param sec
     *            Seconds.
     * @return Date as a string.
     */
    public static Date fromFinlandTime(final int year, final int month,
            final int day, final int hour, final int min, final int sec) {
        Calendar tm = Calendar.getInstance();
        int offset = tm.getTimeZone().getRawOffset();
        offset /= 60000;
        // Difference to Finland time zone.
        offset = offset - 120;
        tm.set(year, month - 1, day, hour, min, sec);
        tm.add(Calendar.MINUTE, offset);
        return tm.getTime();
    }

    static String[] getMessages(final String path) {
        InputStream in = Helpers2.class.getResourceAsStream(path);
        if (in == null) {
            throw new RuntimeException("File not found: " + path);
        }
        Reader fr = null;
        try {
            fr = new InputStreamReader(in);
            char[] chars = new char[in.available()];
            fr.read(chars);
            List<String> arr = new ArrayList<String>();
            arr.addAll(Arrays.asList(String.copyValueOf(chars).split("\n")));
            int cnt = arr.size();
            for (int pos = 0; pos != cnt; ++pos) {
                if (arr.get(pos).length() == 0
                        || arr.get(pos).trim().startsWith("#")) {
                    arr.remove(pos);
                    --pos;
                    --cnt;
                }
            }
            return arr.toArray(new String[arr.size()]);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    throw new RuntimeException(e.getMessage());
                }
            }
        }
    }

    public static final Pattern JAVA_VERSION =
            Pattern.compile("([0-9]*.[0-9]*)(.*)?");

    public static boolean isJavaAtLeast(final double version) {
        String javaVersion = System.getProperty("java.version");
        if (javaVersion == null) {
            return false;
        }

        // if the retrieved version is one three digits, remove the last one.
        Matcher matcher = JAVA_VERSION.matcher(javaVersion);
        if (matcher.matches()) {
            javaVersion = matcher.group(1);
        }

        try {
            double v = Double.parseDouble(javaVersion);
            return v >= version;
        } catch (NumberFormatException e) { // NOSONAR
            return false;
        }
    }

    public static final String DN_NAME = "CN=Test, O=Gurux, L=Tampere, C=FI";
}
