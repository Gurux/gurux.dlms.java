//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSData;
import gurux.dlms.objects.GXDLMSObject;

/**
 * @author Gurux Ltd
 */
public class CosemTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData info = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, info);
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, info);

        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, info);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, info.getValue());
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2StringTest() {
        Object expected = "Gurux";
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2INT8Test() {
        Object expected = (byte) 0xAB;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2UINT8Test() {
        byte expected = (byte) 0xAB;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setDataType(2, DataType.UINT8);
        item.setValue(expected);
        assertEquals((int) (expected & 0xFF), readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2INT16Test() {
        Object expected = (short) 0x1234;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2UINT16Test() {
        Object expected = (short) 0xAB;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setDataType(2, DataType.UINT16);
        item.setValue(expected);
        assertEquals(((Number) expected).intValue(), readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2INT32Test() {
        Object expected = (int) 0x12345678;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2UINT32Test() {
        Object expected = 0xAB;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setDataType(2, DataType.UINT32);
        item.setValue(expected);
        assertEquals(((Number) expected).longValue(), readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2INT64Test() {
        Object expected = (long) 0x12345678;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2UINT64Test() {
        Object expected = (long) 0xAB;
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setDataType(2, DataType.UINT64);
        item.setValue(expected);
        assertEquals(BigInteger.valueOf(((Number) expected).intValue()),
                readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2OctetStringTest() {
        Object expected = "1.2.3.4.5.6";
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setDataType(2, DataType.OCTET_STRING);
        item.setUIDataType(2, DataType.OCTET_STRING);
        item.setValue(expected);
        assertEquals(expected, readTest(item, 2));
    }

    /**
     * A test for Value (2th) attribute of Data Object.
     */
    @Test
    public final void dataAttribute2DateTimeTest() {
        Object expected = new GXDateTime(Calendar.getInstance().getTime());
        GXDLMSData item = new GXDLMSData("1.1.1.1.1.255");
        item.setUIDataType(2, DataType.DATETIME);
        item.setValue(expected);
        assertEquals(expected.toString(), readTest(item, 2).toString());
    }
}
