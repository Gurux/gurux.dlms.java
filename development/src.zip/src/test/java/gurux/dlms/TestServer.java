//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import java.util.logging.Level;
import java.util.logging.Logger;

import gurux.dlms.enums.AccessMode;
import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.ErrorCode;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.MethodAccessMode;
import gurux.dlms.enums.ObjectType;
import gurux.dlms.enums.Security;
import gurux.dlms.enums.SourceDiagnostic;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSAssociationShortName;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSSecuritySetup;
import gurux.dlms.objects.enums.GlobalKeyType;
import gurux.dlms.objects.enums.SecurityPolicy;
import gurux.dlms.objects.enums.SecurityPolicy1;
import gurux.dlms.secure.GXDLMSSecureClient;
import gurux.dlms.secure.GXDLMSSecureServer2;

public final class TestServer extends GXDLMSSecureServer2 {
    private static final Logger LOGGER =
            Logger.getLogger(GXDLMSServer.class.getName());

    /**
     * Constructor.
     * 
     * @param ln
     *            Association logical name.
     * @param type
     *            Interface type.
     */
    public TestServer(final GXDLMSAssociationLogicalName ln,
            final InterfaceType type) {
        super(ln, type);
        getItems().clear();
    }

    /**
     * Constructor.
     * 
     * @param sn
     *            Association short name.
     * @param type
     *            Interface type.
     */
    public TestServer(final GXDLMSAssociationShortName sn,
            final InterfaceType type) {
        super(sn, type);
        getItems().clear();
    }

    @Override
    public void onPreRead(final ValueEventArgs[] args) {
        for (ValueEventArgs e : args) {
            LOGGER.log(Level.INFO, "read " + e.getTarget().toString());
        }
    }

    @Override
    protected void onPreWrite(final ValueEventArgs[] args) {
        for (ValueEventArgs e : args) {
            LOGGER.log(Level.INFO,
                    "write " + e.getTarget().toString() + " : " + e.getValue());
        }
    }

    private void updateSecuritySetupKeys(final ValueEventArgs e,
            final Object[] keys) {
        for (Object k : keys) {
            GlobalKeyType type =
                    GlobalKeyType.values()[(Short) ((Object[]) k)[0]];
            byte[] key = (byte[]) ((Object[]) k)[1];
            switch (type) {
            case UNICAST_ENCRYPTION:
            case BROADCAST_ENCRYPTION:
                // Invalid type
                e.setError(ErrorCode.READ_WRITE_DENIED);
            case AUTHENTICATION:
                // if settings.Cipher is null non secure server is used.
                key = GXDLMSSecureClient.decrypt(e.getSettings().getKek(), key);
                // Update authentication key right a way.
                e.getSettings().getCipher().setAuthenticationKey(key);
                LOGGER.log(Level.INFO,
                        "New authentication key is: " + new String(key));
                break;
            case KEK:
                key = GXDLMSSecureClient.decrypt(e.getSettings().getKek(), key);
                // Update master key right a way.
                e.getSettings().setKek(key);
                LOGGER.log(Level.INFO,
                        "New master key (KEK) is: " + GXCommon.toHex(key));
                break;
            default:
                e.setError(ErrorCode.READ_WRITE_DENIED);
            }
        }
    }

    @Override
    protected void onPreAction(final ValueEventArgs[] args) {
        for (ValueEventArgs e : args) {
            if (e.getTarget() instanceof GXDLMSSecuritySetup) {
                if (e.getIndex() == 1) {
                    GXDLMSSecuritySetup ss =
                            (GXDLMSSecuritySetup) e.getTarget();
                    if (ss.getVersion() == 0) {
                        SecurityPolicy policy = SecurityPolicy
                                .values()[((Number) e.getParameters())
                                        .byteValue()];
                        ss.setSecurityPolicy(policy);
                        switch (policy) {
                        case AUTHENTICATED:
                            getSettings().getCipher()
                                    .setSecurity(Security.AUTHENTICATION);
                            break;
                        case AUTHENTICATED_ENCRYPTED:
                            getSettings().getCipher().setSecurity(
                                    Security.AUTHENTICATION_ENCRYPTION);
                            break;
                        case ENCRYPTED:
                            getSettings().getCipher()
                                    .setSecurity(Security.ENCRYPTION);
                            break;
                        case NOTHING:
                            getSettings().getCipher()
                                    .setSecurity(Security.NONE);
                            break;
                        default:
                            throw new IllegalArgumentException();
                        }
                    } else if (ss.getVersion() == 1) {
                        Security security =
                                getSettings().getCipher().getSecurity();
                        java.util.Set<SecurityPolicy1> policy = SecurityPolicy1
                                .forValue(((Number) e.getParameters())
                                        .byteValue());
                        ss.setSecurityPolicy1(policy);
                        if (policy.contains(
                                SecurityPolicy1.AUTHENTICATED_RESPONSE)) {
                            security = Security.forValue(security.getValue()
                                    | Security.AUTHENTICATION.getValue());
                            getSettings().getCipher().setSecurity(security);
                        }
                        if (policy
                                .contains(SecurityPolicy1.ENCRYPTED_RESPONSE)) {
                            security = Security.forValue(security.getValue()
                                    | Security.ENCRYPTION.getValue());
                            getSettings().getCipher().setSecurity(security);
                        }
                    }
                } else if (e.getIndex() == 1) {
                    updateSecuritySetupKeys(e, (Object[]) e.getParameters());
                }
            }
            LOGGER.log(Level.INFO, "action " + e.getTarget().toString());
        }
    }

    @Override
    protected GXDLMSObject onFindObject(final ObjectType objectType,
            final int sn, final String ln) {
        LOGGER.log(Level.INFO, "findObject " + ln);
        return null;
    }

    @Override
    protected boolean isTarget(final int serverAddress,
            final int clientAddress) {
        return true;
    }

    @Override
    protected SourceDiagnostic onValidateAuthentication(
            final Authentication authentication, final byte[] password) {
        if (password != null) {
            LOGGER.log(Level.INFO, "Try to authenticate with " + authentication
                    + " authentication. PW: " + new String(password));
        } else {
            LOGGER.log(Level.INFO, "Try to authenticate with " + authentication
                    + " authentication.");

        }
        // If Low authentication is used and password don't match.
        if (authentication == Authentication.LOW) {
            byte[] secret;
            if (this.getUseLogicalNameReferencing()) {
                GXDLMSAssociationLogicalName target =
                        (GXDLMSAssociationLogicalName) getItems()
                                .getObjects(ObjectType.ASSOCIATION_LOGICAL_NAME)
                                .get(0);
                secret = target.getSecret();
            } else {
                GXDLMSAssociationShortName target =
                        (GXDLMSAssociationShortName) getItems()
                                .getObjects(ObjectType.ASSOCIATION_SHORT_NAME)
                                .get(0);
                secret = target.getSecret();
            }

            if (secret != null && !java.util.Arrays.equals(password, secret)) {
                String actual = new String(password);
                String expected = new String(secret);
                LOGGER.log(Level.INFO, "Password does not match. Actual: '"
                        + actual + "' Expected: '" + expected + "'");
                return SourceDiagnostic.AUTHENTICATION_FAILURE;
            }
        }
        return SourceDiagnostic.NONE;
    }

    @Override
    protected void onConnected(final GXDLMSConnectionEventArgs connectionInfo) {

    }

    @Override
    protected void
            onDisconnected(final GXDLMSConnectionEventArgs connectionInfo) {
    }

    AccessMode attributeAccess = AccessMode.READ_WRITE;

    @Override
    protected AccessMode onGetAttributeAccess(final ValueEventArgs arg) {
        return attributeAccess;
    }

    MethodAccessMode methodAccessMode = MethodAccessMode.ACCESS;

    @Override
    protected MethodAccessMode onGetMethodAccess(final ValueEventArgs arg) {
        return methodAccessMode;

    }

    @Override
    protected void onInvalidConnection(
            final GXDLMSConnectionEventArgs connectionInfo) {
    }

    @Override
    public void onPreGet(final ValueEventArgs[] e) {

    }

    @Override
    public void onPostGet(final ValueEventArgs[] e) {

    }

    @Override
    public void onPostRead(final ValueEventArgs[] args) {

    }

    @Override
    protected void onPostWrite(final ValueEventArgs[] args) {

    }

    @Override
    protected void onPostAction(final ValueEventArgs[] args) {

    }
}
