//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSData;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectCollection;

/**
 * @author Gurux Ltd
 */
public class ServerLNTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    private void init() {
        server.initialize();
        GXReplyData info = new GXReplyData();
        byte[] data = server.handleRequest(target.aarqRequest()[0]);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        info.clear();
        data = server.handleRequest(target.getObjectsRequest());
        target.getData(data, info);
        target.parseObjects(info.getData(), true);
    }

    @Before
    public final void setUp() {
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        target = new GXDLMSClient(true, 1, 1, Authentication.NONE, null,
                InterfaceType.WRAPPER);
    }

    @After
    public void tearDown() {
    }

    /**
     * A test for server list read.
     */
    @Test
    public final void serverListRead() {
        List<Entry<GXDLMSObject, Integer>> list;
        list = new ArrayList<Entry<GXDLMSObject, Integer>>();
        GXReplyData info = new GXReplyData();
        GXDLMSData item = new GXDLMSData("0.0.0.0.0.0");
        server.getItems().add(item);
        init();
        byte[] data = target.getObjectsRequest();
        data = server.handleRequest(data);
        target.getData(data, info);
        GXDLMSObjectCollection objs =
                target.parseObjects(info.getData(), false);
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(0), 1));
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(0), 1));
        data = target.readList(list)[0];
        data = server.handleRequest(data);
        info.clear();
        target.getData(data, info);
        List<Object> values = new ArrayList<Object>();
        values.addAll(Arrays.asList((Object[]) info.getValue()));
        target.updateValues(list, values);
    }
}
