//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.TimeZone;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.Conformance;
import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.ObjectType;
import gurux.dlms.enums.Priority;
import gurux.dlms.enums.RequestTypes;
import gurux.dlms.enums.ServiceClass;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectCollection;
import gurux.dlms.objects.GXDLMSProfileGeneric;
import gurux.dlms.objects.GXDLMSRegister;
import gurux.dlms.objects.IGXDLMSBase;

/**
 * @author Gurux Ltd
 */
public class IskraTest {
    private GXDLMSClient target = null;

    public IskraTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setClientAddress(100);
        target.setServerAddress(GXDLMSClient.getServerAddress(1, 17));
        target.setAuthentication(Authentication.LOW);
        target.setPassword("Gurux");
        target.setUseLogicalNameReferencing(true);
        target.setServiceClass(ServiceClass.UN_CONFIRMED);
    }

    @After
    public final void tearDown() {
    }

    /**
     * A test for SNRM Request
     */
    @Test
    public final void snrmRequestTest() {
        byte[] expected = Helpers2.getMessage("/Iskra/SNRMRequest.txt");
        byte[] actual = target.snrmRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for UA response
     */
    @Test
    public final void uaResponseTest() {
        byte[] data = Helpers2.getMessage("/Iskra/UAResponse.txt");
        GXReplyData reply = new GXReplyData();
        target.getData(data, reply);
        target.parseUAResponse(reply.getData());
        assertEquals((short) 126, target.getLimits().getMaxInfoRX());
        assertEquals((short) 126, target.getLimits().getMaxInfoTX());
        assertEquals((long) 1, target.getLimits().getWindowSizeRX());
        assertEquals((long) 1, target.getLimits().getWindowSizeTX());
    }

    /**
     * A test for AARQ Request
     */
    @Test
    public final void aarqRequestTest() {
        byte[] data = Helpers2.getMessage("/Iskra/UAResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseUAResponse(info.getData());

        target.setAuthentication(Authentication.LOW);
        target.getProposedConformance().remove(Conformance.UN_CONFIRMED_WRITE);
        target.getProposedConformance().remove(Conformance.GENERAL_PROTECTION);
        target.getProposedConformance().add(Conformance.EVENT_NOTIFICATION);
        target.getProposedConformance()
                .add(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_GET);
        target.getProposedConformance()
                .add(Conformance.PRIORITY_MGMT_SUPPORTED);
        target.setPassword("12345678".getBytes());
        byte[] expected = Helpers2.getMessage("/Iskra/AARQRequest.txt");
        byte[] actual = target.aarqRequest()[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for AARE Response
     */
    @Test
    public final void aareResponseTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());
    }

    /**
     * A test for LNSettings
     */
    @Test
    public final void lnSettingsTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.ACTION));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_ACTION));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_GET));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_SET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.EVENT_NOTIFICATION));
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.GET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_GET_OR_READ));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.MULTIPLE_REFERENCES));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.PRIORITY_MGMT_SUPPORTED));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.SELECTIVE_ACCESS));
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.SET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_SET_OR_WRITE));
    }

    /**
     * A test for Disconnected Request
     */
    @Test
    public final void disconnectRequestTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        byte[] expected = Helpers2.getMessage("/Iskra/DisconnectRequest.txt");
        byte[] actual = (byte[]) target.disconnectRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Get Objects Request
     */
    @Test
    public final void getObjectsTest() {
        byte[] expected = Helpers2.getMessage("/Iskra/GetObjects.txt");
        target.setServiceClass(ServiceClass.UN_CONFIRMED);
        byte[] actual = target.getObjectsRequest();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Keep Alive request.
     */
    @Test
    public final void keepAliveTest() {
        byte[] expected = Helpers2.getMessage("/Iskra/KeepAlive.txt");
        byte[] actual = (byte[]) target.keepAlive();
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Is More Data Available Frame test.
     */
    @Test
    public final void isMoreDataAvailableFrameTest() {
        byte[] data =
                Helpers2.getMessage("/Iskra/IsMoreDataAvailableFrame.txt");
        GXReplyData info = new GXReplyData();
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        assertEquals(RequestTypes.FRAME, info.getMoreData());
    }

    /**
     * A test for Is More Data Available None Test.
     */
    @Test
    public final void isMoreDataAvailableNoneTest() {
        byte[] data = Helpers2.getMessage("/Iskra/IsMoreDataAvailableNone.txt");
        GXReplyData info = new GXReplyData();
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        assertEquals(RequestTypes.NONE, info.getMoreData());
    }

    /**
     * A test for Is More Data Available Both Test.
     */
    @Test
    public final void isMoreDataAvailableBothTest() {
        byte[] data = Helpers2.getMessage("/Iskra/IsMoreDataAvailableBoth.txt");
        GXReplyData info = new GXReplyData();
        target.setStartingPacketIndex(0);
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        assertEquals(RequestTypes.BOTH, info.getMoreData());
    }

    /**
     * A test for Is is frame set when frame and data block are both set.
     */
    @Test
    public final void isMoreDataAvailableFrameInBothTest() {
        byte[] data = Helpers2.getMessage("/Iskra/IsMoreDataAvailableBoth.txt");
        GXReplyData info = new GXReplyData();
        target.setStartingPacketIndex(0);
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        assertTrue(info.getMoreData() == RequestTypes.BOTH);
    }

    /**
     * A test for Is is data block set when frame and data block are both set.
     */
    @Test
    public final void isMoreDataAvailableBlockInBothTest() {
        byte[] data = Helpers2.getMessage("/Iskra/IsMoreDataAvailableBoth.txt");
        GXReplyData info = new GXReplyData();
        target.setStartingPacketIndex(0);
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        assertTrue(info.getMoreData() == RequestTypes.BOTH);
    }

    /**
     * A test for Parse Objects.
     */
    @Test
    public final void parseObjectsTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        data = Helpers2.getMessage("/Iskra/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), true);
        assertEquals(287, objects.size());
    }

    /**
     * A test for Parse Objects using new interfaces.
     */
    @Test
    public final void parseObjectsUsingNewInterfaceTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        data = Helpers2.getMessage("/Iskra/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), true);
        for (GXDLMSObject it : objects) {
            if (!(it instanceof IGXDLMSBase)) {
                throw new RuntimeException(it.getClass().getSimpleName());
            }
        }
    }

    /**
     * A test for Parse Objects.
     */
    @Test
    public final void parseObjectsMessagesTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        target.getSettings().setSkipFrameCheck(true);
        GXReplyData info = new GXReplyData();
        info.setPeek(true);
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        String[] messages =
                Helpers2.getMessages("/Iskra/ParseObjectsMessages.txt");
        int cnt = messages.length;
        info.clear();
        target.setStartingPacketIndex(0);
        for (int pos = 0; pos < cnt; pos += 2) {
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            if (info.getMoreData() != RequestTypes.NONE) {
                target.receiverReady(info.getMoreData());
            }
            assertEquals(287, info.getTotalCount());
        }
        GXDLMSObjectCollection objects =
                target.parseObjects(info.getData(), false);
        assertEquals(287, objects.size());
    }

    /**
     * Server initial function test.
     */
    @Test
    public final void serverConnectionTest() {
        GXReplyData info = new GXReplyData();
        TestServer server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
        GXDLMSClock clock = new GXDLMSClock("0.0.1.0.0.255");
        server.getItems().add(clock);
        server.initialize();
        byte[] data = target.snrmRequest();
        data = server.handleRequest(data);
        target.getData(data, info);
        target.parseUAResponse(info.getData());
        info.clear();
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        info.clear();
        data = target.disconnectRequest();
        data = server.handleRequest(data);
        target.getData(data, info);
    }

    /**
     * A test server send all objects.
     */
    @Test
    public final void serverObjectsMessagesTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        info.setPeek(true);
        target.getSettings().setSkipFrameCheck(true);
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        String[] messages =
                Helpers2.getMessages("/Iskra/ParseObjectsMessages.txt");
        int cnt = messages.length;
        info.clear();
        int pos;
        for (pos = 0; pos < cnt; pos += 2) {
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            if (info.getMoreData() != RequestTypes.NONE) {
                target.receiverReady(info.getMoreData());
            }
            assertEquals(287, info.getTotalCount());
        }
        assertEquals(cnt, pos);
        GXDLMSObjectCollection objects =
                target.parseObjects(info.getData(), false);
        assertEquals(287, objects.size());

        info.clear();
        TestServer server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
        server.getSettings().setSkipFrameCheck(true);
        server.getItems().clear();
        server.getItems().addAll(objects);
        server.initialize();
        server.getLimits().setMaxInfoTX(136);
        server.getLimits().setMaxInfoRX(target.getLimits().getMaxInfoRX());
        data = target.aarqRequest()[0];
        byte[] reply = server.handleRequest(data);
        target.getData(reply, info);
        target.parseAareResponse(info.getData());

        target.setPriority(Priority.NORMAL);
        target.setServiceClass(ServiceClass.CONFIRMED);
        target.setInvokeID(0);
        server.setPriority(Priority.NORMAL);
        server.setServiceClass(ServiceClass.CONFIRMED);
        server.setInvokeID(0);
        // Get objects from the server.
        server.setMaxReceivePDUSize(424);
        info.clear();
        // Read clock object to make frame id match.
        data = target.read(objects.getObjects(ObjectType.CLOCK).get(0), 2)[0];
        reply = server.handleRequest(data);
        data = target.getObjectsRequest();
        do {
            reply = server.handleRequest(data);
            target.getData(reply, info);
            if (info.isMoreData()) {
                data = target.receiverReady(info.getMoreData());
            }
        } while (info.isMoreData());
        assertEquals(cnt, pos);
        GXDLMSObjectCollection objects2 =
                target.parseObjects(info.getData(), false);
        assertEquals(287, objects2.size());
    }

    /**
     * A test for Parse Objects for Iscra 2008 EM.
     */
    @Test
    public final void parseObjectsMessages2008Test() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());
        String[] messages =
                Helpers2.getMessages("/Iskra/ParseObjectsMessages.txt");
        int cnt = messages.length;
        info.clear();
        info.setPeek(true);
        target.getSettings().setSkipFrameCheck(true);
        target.setStartingPacketIndex(0);
        for (int pos = 0; pos < cnt; pos += 2) {
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            assertEquals(287, info.getTotalCount());
            if (info.isMoreData()) {
                target.receiverReady(info.getMoreData());
            }
        }
        GXDLMSObjectCollection objects =
                target.parseObjects(info.getData(), false);
        assertEquals(287, objects.size());
    }

    /**
     * A test for Keep Alive request.
     */
    @Test
    public final void receiverReadyFrameTest() {
        byte[] expected = Helpers2.getMessage("/Iskra/ReceiverReadyFrame.txt");
        byte[] actual = (byte[]) target.receiverReady(RequestTypes.FRAME);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for Keep Alive request.
     */
    @Test
    public final void receiverReadyBlockTest() {
        byte[] expected = Helpers2.getMessage("/Iskra/ReceiverReadyBlock.txt");
        byte[] actual = (byte[]) target.receiverReady(RequestTypes.DATABLOCK);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for write message.
     */
    @Test
    public final void writeTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        byte[] expected = { (byte) 0x7e, (byte) 0xa0, (byte) 0x1c, (byte) 0x02,
                (byte) 0x23, (byte) 0xc9, (byte) 0x32, (byte) 0x37, (byte) 0x6E,
                (byte) 0xe6, (byte) 0xe6, (byte) 0x00, (byte) 0xc1, (byte) 0x01,
                (byte) 0x81, (byte) 0x00, (byte) 0x01, (byte) 0x00, (byte) 0x00,
                (byte) 0x80, (byte) 0x1e, (byte) 0x01, (byte) 0xff, (byte) 0x02,
                (byte) 0x00, (byte) 0x11, (byte) 0x01, (byte) 0xD7, (byte) 0xF7,
                (byte) 0x7e };
        byte[][] actual = target.write("0.0.128.30.1.255", (byte) 1,
                DataType.UINT8, ObjectType.DATA, 2);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual[0]));
    }

    /**
     * A test for Get Profile Generic columns. @
     */
    @Test
    public final void getProfileGenericColumnsTest() {
        byte[] expected = { (byte) 0x7e, (byte) 0xa0, (byte) 0x1a, (byte) 0x02,
                (byte) 0x23, (byte) 0xc9, (byte) 0x32, (byte) 0xaf, (byte) 0x55,
                (byte) 0xe6, (byte) 0xe6, (byte) 0x00, (byte) 0xc0, (byte) 0x01,
                (byte) 0x81, (byte) 0x00, (byte) 0x07, (byte) 0x00, (byte) 0x00,
                (byte) 0x15, (byte) 0x00, (byte) 0x00, (byte) 0xff, (byte) 0x03,
                (byte) 0x00, (byte) 0x89, (byte) 0x0a, (byte) 0x7e };
        byte[] actual =
                target.read("0.0.21.0.0.255", ObjectType.PROFILE_GENERIC, 3)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for read rows by entry message.
     */
    @Test
    public final void readRowsByEntry() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/Iskra/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), true);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 2D 02 23 C9 32 A2 B1 E6 E6 00 C0 01 81 00 07 00 00 15 00 00 FF 02 01 02 02 04 06 00 00 00 00 06 00 00 00 01 12 00 01 12 00 00 47 E1 7E");
        // CHECKSTYLE:ON
        GXDLMSProfileGeneric pg = (GXDLMSProfileGeneric) objects
                .getObjects(ObjectType.PROFILE_GENERIC).get(0);
        byte[] actual = target.readRowsByEntry(pg, 0, 1)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for read rows by range message.
     */
    @Test
    public final void readRowsByRange() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/Iskra/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), true);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 4D 02 23 C9 32 11 10 E6 E6 00 C0 01 81 00 07 00 00 15 00 00 FF 02 01 01 02 04 02 04 12 00 08 09 06 00 00 01 00 00 FF 0F 02 12 00 00 09 0C 07 D0 07 01 FF 00 00 00 FF FF 88 80 09 0C 07 E5 01 01 FF 00 00 00 FF FF 88 80 01 00 1D 5F 7E");
        // CHECKSTYLE:ON
        TimeZone fi;
        fi = TimeZone.getTimeZone("Europe/Helsinki");
        java.util.Calendar start = java.util.Calendar.getInstance(fi);
        // Summer time.
        start.set(2000, 6, 1, 0, 0, 0);
        // Winter time.
        java.util.Calendar end = java.util.Calendar.getInstance(fi);
        end.set(2020, 11, 31, 24, 0, 0);
        GXDLMSProfileGeneric pg = (GXDLMSProfileGeneric) objects
                .getObjects(ObjectType.PROFILE_GENERIC).get(0);
        pg.setSortObject(new GXDLMSClock("0.0.1.0.0.255"));
        byte[] actual = target.readRowsByRange(pg, start, end)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A action test.
     */
    @Test
    public final void actionTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Iskra/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        byte[] data = Helpers2.getMessage("/Iskra/ParseObjects.txt");
        GXDLMSObjectCollection objects =
                target.parseObjects(new GXByteBuffer(data), false);
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 1C 02 23 C9 32 37 6E E6 E6 00 C3 01 81 00 03 00 00 80 08 00 FF 01 01 0F 00 97 44 7E");
        // CHECKSTYLE:ON
        GXDLMSRegister register =
                (GXDLMSRegister) objects.getObjects(ObjectType.REGISTER).get(0);
        byte[] actual = target.method(register, 1, 0, DataType.INT8)[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for parsing profile generic columns. @
     */
    @Test
    public final void parseProfileGenericColumnsTest() {
        String[] messages =
                Helpers2.getMessages("/Iskra/ParseProfileGenericColumns.txt");
        int cnt = messages.length;
        target.getSettings().setSkipFrameCheck(true);
        GXReplyData info = new GXReplyData();
        info.setPeek(true);
        for (int pos = 0; pos < cnt; pos += 2) {
            // byte[] send = Helpers2.getBytes(messages[pos]);
            byte[] reply = Helpers2.getBytes(messages[pos + 1]);
            target.getData(reply, info);
            assertEquals(15, info.getTotalCount());
            assertTrue(0 != info.getCount());
        }
        GXDLMSProfileGeneric p = new GXDLMSProfileGeneric();
        ValueEventArgs e = new ValueEventArgs(p, 3, 0, null);
        e.setValue(info.getValue());
        p.setValue(target.getSettings(), e);
        assertEquals(15, p.getCaptureObjects().size());
    }

    /**
     * Read a list of objects.
     */
    @Test
    public final void readObjectsTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        data = Helpers2.getMessage("/Iskra/ParseObjects.txt");
        GXDLMSObjectCollection objs =
                target.parseObjects(new GXByteBuffer(data), false)
                        .getObjects(ObjectType.REGISTER);
        List<Entry<GXDLMSObject, Integer>> list =
                new ArrayList<Entry<GXDLMSObject, Integer>>();
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(0), 3));
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(1), 3));
        // CHECKSTYLE:OFF
        byte[] expected = Helpers2.getBytes(
                "7E A0 25 02 23 C9 32 82 EB E6 E6 00 C0 03 81 02 00 03 00 00 80 08 00 FF 03 00 00 03 00 00 80 08 01 FF 03 00 1E 0A 7E");
        // CHECKSTYLE:ON
        byte[][] actual = target.readList(list);
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual[0]));
    }

    /**
     * Read a list of objects.
     */
    @Test
    public final void readObjectsReplyTest() {
        byte[] data = Helpers2.getMessage("/Iskra/AAREResponse.txt");
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        target.parseAareResponse(info.getData());

        data = Helpers2.getMessage("/Iskra/ParseObjects.txt");
        info.clear();
        GXByteBuffer tmp = new GXByteBuffer(data);
        GXDLMSObjectCollection objs = target.parseObjects(tmp, false);
        objs = objs.getObjects(ObjectType.REGISTER);
        List<Entry<GXDLMSObject, Integer>> list =
                new ArrayList<Entry<GXDLMSObject, Integer>>();
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(0), 3));
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(1), 3));
        list.add(new GXSimpleEntry<GXDLMSObject, Integer>(objs.get(2), 3));
        data = null;
        // CHECKSTYLE:OFF
        target.getData(
                Helpers2.getBytes(
                        "7E A0 26 C9 02 23 52 8A 23 E6 E7 00 C4 03 81 03 00 02 02 0F 00 16 07 00 02 02 0F 00 16 23 00 02 02 0F 00 16 23 44 B4 7E"),
                info);
        // CHECKSTYLE:ON
        List<Object> values = new ArrayList<Object>();
        values.addAll(Arrays.asList((Object[]) info.getValue()));
        target.updateValues(list, values);
    }

    /**
     * Echo test.
     */
    @Test
    public final void echoTest() {
        GXByteBuffer data = new GXByteBuffer();
        GXByteBuffer tmp = new GXByteBuffer();
        tmp.set(Helpers2.getMessage("/Iskra/SNRMRequest.txt"));
        tmp.set(Helpers2.getMessage("/Iskra/UAResponse.txt"));
        GXReplyData reply = new GXReplyData();
        for (byte it : tmp.array()) {
            data.setUInt8(it);
            target.getData(data, reply);
            if (reply.isComplete()) {
                break;
            }
        }
        target.parseUAResponse(reply.getData());
        assertEquals((short) 126, target.getLimits().getMaxInfoRX());
        assertEquals((short) 126, target.getLimits().getMaxInfoTX());
        assertEquals((long) 1, target.getLimits().getWindowSizeRX());
        assertEquals((long) 1, target.getLimits().getWindowSizeTX());
    }
}