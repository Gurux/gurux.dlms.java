//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.Conformance;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.internal.GXCommon;

public class ZivTest {
    private GXDLMSClient target = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress((short) 0x1);
        target.setClientAddress((short) 0x1);
        target.setUseLogicalNameReferencing(true);
        target.setInterfaceType(InterfaceType.WRAPPER);
        target.getProposedConformance().remove(Conformance.GENERAL_PROTECTION);
        target.getProposedConformance().add(Conformance.EVENT_NOTIFICATION);
        target.getProposedConformance()
                .add(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_GET);
        target.getProposedConformance()
                .add(Conformance.PRIORITY_MGMT_SUPPORTED);
    }

    @After
    public final void tearDown() {
    }

    /*
     * A test for AARQ Request
     */
    @Test
    public final void aarqRequestTest() {
        byte[] expected = Helpers2.getMessage("/Ziv/AARQRequest.txt");
        target.setAuthentication(Authentication.LOW);
        target.setPassword("ZIV18032".getBytes());
        byte[] actual = target.aarqRequest()[0];
        assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
    }

    /**
     * A test for AARE Response
     */
    @Test
    public final void aareResponseTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Ziv/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());
    }

    /**
     * A test for LNSettings
     */
    @Test
    public final void lnSettingsTest() {
        GXReplyData info = new GXReplyData();
        target.getData(Helpers2.getMessage("/Ziv/AAREResponse.txt"), info);
        target.parseAareResponse(info.getData());

        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.ACTION));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_ACTION));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_GET));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.ATTRIBUTE_0_SUPPORTED_WITH_SET));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.EVENT_NOTIFICATION));
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.GET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_GET_OR_READ));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.MULTIPLE_REFERENCES));
        assertEquals(false, target.getNegotiatedConformance()
                .contains(Conformance.PRIORITY_MGMT_SUPPORTED));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.SELECTIVE_ACCESS));
        assertEquals(true,
                target.getNegotiatedConformance().contains(Conformance.SET));
        assertEquals(true, target.getNegotiatedConformance()
                .contains(Conformance.BLOCK_TRANSFER_WITH_SET_OR_WRITE));
    }
}
