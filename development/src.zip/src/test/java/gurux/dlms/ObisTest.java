//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ObisTest {

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {

    }

    @After
    public final void tearDown() {
    }

    /*
     * A test OBIS code description.
     */
    @Test
    public final void descriptionTest() {
        GXDLMSConverter converter = new GXDLMSConverter();
        String[] actual = converter.getDescription("1.0.31.25.0.255");
        assertEquals("Ch. 0 L1 Current Last avg. 3", actual[0]);
        assertEquals(
                "Ch. 0 L1 Current Last avg. 3 Harmonic / Distortion factor 0",
                actual[1]);
    }

    /*
     * A Get all descriptions description.
     */
    @Test
    public final void allDescriptionTest() {
        GXDLMSConverter converter = new GXDLMSConverter();
        String[] actual = converter.getDescription("");
        assertEquals(1338, actual.length);

    }

    /*
     * A Test hex.
     */
    @Test
    public final void hexDescriptionTest() {
        GXDLMSConverter converter = new GXDLMSConverter();
        String[] actual = converter.getDescription("0000010000FF");
        assertEquals(1, actual.length);

    }
}
