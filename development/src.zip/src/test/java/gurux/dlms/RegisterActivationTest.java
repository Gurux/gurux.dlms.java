//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.util.Map.Entry;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.ObjectType;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSObject;
import gurux.dlms.objects.GXDLMSObjectDefinition;
import gurux.dlms.objects.GXDLMSRegisterActivation;

/**
 * @author Gurux Ltd
 */
public class RegisterActivationTest {
    private GXDLMSClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSClient();
        target.setServerAddress(1);
        target.setClientAddress(16);
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.HDLC);
    }

    @After
    public final void tearDown() {
    }

    final Object readTest(final GXDLMSObject item, final int index) {
        return readTest(item, index, true);
    }

    final Object readTest(final GXDLMSObject item, final int index,
            final boolean reset) {
        GXReplyData reply = new GXReplyData();
        server.getItems().add(item);
        server.initialize();
        byte[] buff = server.handleRequest(target.snrmRequest());
        target.getData(buff, reply);
        buff = server.handleRequest(target.aarqRequest()[0]);
        target.getData(buff, reply);

        buff = target.read(item, index)[0];
        buff = server.handleRequest(buff);
        target.getData(buff, reply);
        if (reset) {
            for (int pos = 0; pos != item.getAttributeCount(); ++pos) {
                ValueEventArgs e = new ValueEventArgs(item, pos + 1, 0, null);
                item.setValue(null, e);
            }
        }
        return target.updateValue(item, index, reply.getValue());
    }

    /**
     * A test for Logical Name (1st) attribute of Register Activation Object.
     */
    @Test
    public final void registerActivationAttribute1Test() {
        String expected = "1.1.1.1.1.255";
        GXDLMSRegisterActivation item = new GXDLMSRegisterActivation(expected);
        assertEquals(expected, readTest(item, 1, false));
    }

    /**
     * A test for register assignment (2th) attribute of Register Activation
     * Object.
     */
    @Test
    public final void registerActivationAttribute2Test() {
        GXDLMSObjectDefinition expected =
                new GXDLMSObjectDefinition(ObjectType.REGISTER, "1.2.3.4.5.6");
        GXDLMSRegisterActivation item =
                new GXDLMSRegisterActivation("1.1.1.1.1.255");
        item.getRegisterAssignment().add(expected);
        readTest(item, 2);
        assertEquals(expected.getLogicalName(),
                item.getRegisterAssignment().get(0).getLogicalName());
    }

    /**
     * A test for mask list (3rt) attribute of Register Activation Object.
     */
    @Test
    public final void registerActivationAttribute3Test() {
        Entry<byte[], byte[]> expected = new GXSimpleEntry<byte[], byte[]>(
                new byte[] { 1 }, new byte[] { 1 });
        GXDLMSRegisterActivation item =
                new GXDLMSRegisterActivation("1.1.1.1.1.255");
        item.getMaskList().add(expected);
        readTest(item, 3);
        assertEquals(GXCommon.toHex(expected.getKey()),
                GXCommon.toHex(item.getMaskList().get(0).getKey()));
        assertEquals(GXCommon.toHex(expected.getValue()),
                GXCommon.toHex(item.getMaskList().get(0).getValue()));
    }

    /**
     * A test for active mask (4) attribute of Register Activation Object.
     */
    @Test
    public final void registerActivationAttribute4Test() {
        byte[] expected = "Gurux".getBytes();
        GXDLMSRegisterActivation item =
                new GXDLMSRegisterActivation("1.1.1.1.1.255");
        item.setActiveMask(expected);
        readTest(item, 4);
        assertEquals(new String(expected), new String(item.getActiveMask()));
    }
}
