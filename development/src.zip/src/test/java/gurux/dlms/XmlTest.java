//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.InterfaceType;
import gurux.dlms.internal.GXCommon;

public class XmlTest {
    private static final Logger LOGGER =
            Logger.getLogger(XmlTest.class.getName());

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
    }

    @After
    public final void tearDown() {
    }

    private String equals(final String expected, final String actual) {
        int cnt = expected.length();
        if (actual.length() < cnt) {
            cnt = actual.length();
        }
        for (int pos = 0; pos != actual.length(); ++pos) {
            if (expected.charAt(pos) != actual.charAt(pos)) {
                return actual.substring(pos);
            }
        }
        if (actual.length() != expected.length()) {
            return "Data is missing from the end.";
        }
        return expected;
    }

    /*
     * Association request SN test.
     */
    @Test
    public final void aarqSNTest() {
        // CHECKSTYLE:OFF
        String input =
                "601DA109060760857405080102BE10040E01000000065F1F0400180220FFFF";
        String expected =
                "<AssociationRequest>\r\n  <ApplicationContextName Value=\"SN\" />\r\n  <InitiateRequest>\r\n    <ProposedDlmsVersionNumber Value=\"06\" />\r\n    <ProposedConformance>\r\n      <ConformanceBit Name=\"ParameterizedAccess\" />\r\n      <ConformanceBit Name=\"MultipleReferences\" />\r\n      <ConformanceBit Name=\"Write\" />\r\n      <ConformanceBit Name=\"Read\" />\r\n    </ProposedConformance>\r\n    <ProposedMaxPduSize Value=\"FFFF\" />\r\n  </InitiateRequest>\r\n</AssociationRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Association request SN Low PW test.
     */
    @Test
    public final void aarqSNLowPwTest() {
        // CHECKSTYLE:OFF
        String input =
                "6036A1090607608574050801028A0207808B0760857405080201AC0A80083030303030303030BE10040E01000000065F1F0400180220FFFF";
        String expected =
                "<AssociationRequest>\r\n  <ApplicationContextName Value=\"SN\" />\r\n  <SenderACSERequirements Value=\"1\" />\r\n  <MechanismName Value=\"Low\" />\r\n  <CallingAuthentication Value=\"3030303030303030\" />\r\n  <InitiateRequest>\r\n    <ProposedDlmsVersionNumber Value=\"06\" />\r\n    <ProposedConformance>\r\n      <ConformanceBit Name=\"ParameterizedAccess\" />\r\n      <ConformanceBit Name=\"MultipleReferences\" />\r\n      <ConformanceBit Name=\"Write\" />\r\n      <ConformanceBit Name=\"Read\" />\r\n    </ProposedConformance>\r\n    <ProposedMaxPduSize Value=\"FFFF\" />\r\n  </InitiateRequest>\r\n</AssociationRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Association request LN test.
     */
    @Test
    public final void aarqLNTest() {
        // CHECKSTYLE:OFF
        String input =
                "601DA109060760857405080101BE10040E01000000065F1F040000FC1FFFFF";
        String expected =
                "<AssociationRequest>\r\n  <ApplicationContextName Value=\"LN\" />\r\n  <InitiateRequest>\r\n    <ProposedDlmsVersionNumber Value=\"06\" />\r\n    <ProposedConformance>\r\n      <ConformanceBit Name=\"Action\" />\r\n      <ConformanceBit Name=\"EventNotification\" />\r\n      <ConformanceBit Name=\"SelectiveAccess\" />\r\n      <ConformanceBit Name=\"Set\" />\r\n      <ConformanceBit Name=\"Get\" />\r\n      <ConformanceBit Name=\"BlockTransferWithAction\" />\r\n      <ConformanceBit Name=\"BlockTransferWithSetOrWrite\" />\r\n      <ConformanceBit Name=\"BlockTransferWithGetOrRead\" />\r\n      <ConformanceBit Name=\"Attribute0SupportedWithGet\" />\r\n      <ConformanceBit Name=\"PriorityMgmtSupported\" />\r\n      <ConformanceBit Name=\"Attribute0SupportedWithSet\" />\r\n    </ProposedConformance>\r\n    <ProposedMaxPduSize Value=\"FFFF\" />\r\n  </InitiateRequest>\r\n</AssociationRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        String tmp = equals(expected, actual);
        assertEquals(expected, tmp);
        assertEquals(expected, actual);
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Association request LN test.
     */
    @Test
    public final void aareLNTest() {
        // CHECKSTYLE:OFF
        String input =
                "6129A109060760857405080101A203020100A305A103020100BE10040E0800065F1F0400007C1F02000007";
        String expected =
                "<AssociationResponse>\r\n  <ApplicationContextName Value=\"LN\" />\r\n  <AssociationResult Value=\"00\" />\r\n  <ResultSourceDiagnostic>\r\n    <ACSEServiceUser Value=\"00\" />\r\n  </ResultSourceDiagnostic>\r\n  <InitiateResponse>\r\n    <NegotiatedDlmsVersionNumber Value=\"06\" />\r\n    <NegotiatedConformance>\r\n      <ConformanceBit Name=\"Action\" />\r\n      <ConformanceBit Name=\"EventNotification\" />\r\n      <ConformanceBit Name=\"SelectiveAccess\" />\r\n      <ConformanceBit Name=\"Set\" />\r\n      <ConformanceBit Name=\"Get\" />\r\n      <ConformanceBit Name=\"BlockTransferWithAction\" />\r\n      <ConformanceBit Name=\"BlockTransferWithSetOrWrite\" />\r\n      <ConformanceBit Name=\"BlockTransferWithGetOrRead\" />\r\n      <ConformanceBit Name=\"Attribute0SupportedWithGet\" />\r\n      <ConformanceBit Name=\"PriorityMgmtSupported\" />\r\n    </NegotiatedConformance>\r\n    <NegotiatedMaxPduSize Value=\"0200\" />\r\n    <VaaName Value=\"0007\" />\r\n  </InitiateResponse>\r\n</AssociationResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Get request test.
     */
    @Test
    public final void getRequestTest() {
        String input = "C00181000F0000280000FF0200";
        // CHECKSTYLE:OFF
        String expected =
                "<GetRequest>\r\n  <GetRequestNormal>\r\n    <InvokeIdAndPriority Value=\"81\" />\r\n    <AttributeDescriptor>\r\n      <ClassId Value=\"000F\" />\r\n      <InstanceId Value=\"0000280000FF\" />\r\n      <AttributeId Value=\"02\" />\r\n    </AttributeDescriptor>\r\n  </GetRequestNormal>\r\n</GetRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Get request next data block test.
     */
    @Test
    public final void getRequestNextDataBlockTest() {
        String input = "C0028100000001";
        // CHECKSTYLE:OFF
        String expected =
                "<GetRequest>\r\n  <GetRequestForNextDataBlock>\r\n    <InvokeIdAndPriority Value=\"81\" />\r\n    <BlockNumber Value=\"00000001\" />\r\n  </GetRequestForNextDataBlock>\r\n</GetRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Read request test.
     */
    @Test
    public final void readRequestTest() {
        String input = "0501022BC8";
        // CHECKSTYLE:OFF
        String expected =
                "<ReadRequest Qty=\"01\" >\r\n  <VariableName Value=\"2BC8\" />\r\n</ReadRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Read request test.
     */
    @Test
    public final void readRequest2Test() {
        String input = "0502021778021780";
        // CHECKSTYLE:OFF
        String expected =
                "<ReadRequest Qty=\"02\" >\r\n  <VariableName Value=\"1778\" />\r\n  <VariableName Value=\"1780\" />\r\n</ReadRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Write request test.
     */
    @Test
    public final void writeRequestTest() {
        String input = "0601022BC8010900";
        // CHECKSTYLE:OFF
        String expected =
                "<WriteRequest>\r\n  <ListOfVariableAccessSpecification Qty=\"01\" >\r\n    <VariableName Value=\"2BC8\" />\r\n  </ListOfVariableAccessSpecification>\r\n  <ListOfData Qty=\"01\" >\r\n    <OctetString Value=\"\" />\r\n  </ListOfData>\r\n</WriteRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Write response test.
     */
    @Test
    public final void writeResponseTest() {
        String input = "0D0100";
        // CHECKSTYLE:OFF
        String expected =
                "<WriteResponse Qty=\"01\" >\r\n  <Success />\r\n</WriteResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Write response test.
     */
    @Test
    public final void writeResponseReadWriteDeniedTest() {
        String input = "0D010103";
        // CHECKSTYLE:OFF
        String expected =
                "<WriteResponse Qty=\"01\" >\r\n  <DataAccessError Value=\"ReadWriteDenied\" />\r\n</WriteResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        String output = converter.xmlToHexPdu(actual);
        assertEquals(input, output);
    }

    /*
     * Snrm test.
     */
    @Test
    public final void snrmTest() {
        byte[] input = Helpers2.getMessage("/LG/SNRMRequest.txt");
        // CHECKSTYLE:OFF
        String expected =
                "<HDLC len=\"9\" >\r\n<TargetAddress Value=\"1\" />\r\n<SourceAddress Value=\"10\" />\r\n<Snrm>\r\n</Snrm>\r\n</HDLC>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.messageToXml(input);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Ciphering SN test.
     */
    @Test
    public final void cipheringSnTest() {
        // CHECKSTYLE:OFF
        byte[] input = Helpers2.getBytes(
                "6030A109060760857405080104A60A04084142434445464748BE170415211320000000001F584B3032AF2857076CDB7081F0");
        String expected =
                "<AssociationRequest>\r\n  <ApplicationContextName Value=\"SN_WITH_CIPHERING\" />\r\n  <CallingAPTitle Value=\"4142434445464748\" />\r\n  <glo_InitiateRequest Value=\"20000000001F584B3032AF2857076CDB7081F0\" />\r\n</AssociationRequest>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Aare test.
     */
    @Test
    public final void authenticatioFailedTest() {
        // CHECKSTYLE:OFF
        byte[] input = Helpers2.getBytes(
                "6129A109060760857405080102A203020101A305A10302010DBE10040E080100065F1F04001C0320FFFFFA00");
        String expected =
                "<AssociationResponse>\r\n  <ApplicationContextName Value=\"SN\" />\r\n  <AssociationResult Value=\"01\" />\r\n  <ResultSourceDiagnostic>\r\n    <ACSEServiceUser Value=\"0D\" />\r\n  </ResultSourceDiagnostic>\r\n  <InitiateResponse>\r\n    <NegotiatedQualityOfService Value=\"00\" />\r\n    <NegotiatedDlmsVersionNumber Value=\"06\" />\r\n    <NegotiatedConformance>\r\n      <ConformanceBit Name=\"ParameterizedAccess\" />\r\n      <ConformanceBit Name=\"InformationReport\" />\r\n      <ConformanceBit Name=\"MultipleReferences\" />\r\n      <ConformanceBit Name=\"UnconfirmedWrite\" />\r\n      <ConformanceBit Name=\"Write\" />\r\n      <ConformanceBit Name=\"Read\" />\r\n    </NegotiatedConformance>\r\n    <NegotiatedMaxPduSize Value=\"FFFF\" />\r\n    <VaaName Value=\"FA00\" />\r\n  </InitiateResponse>\r\n</AssociationResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        converter.xmlToHexPdu(actual);
    }

    /*
     * Binary Coded Desimal test.
     */
    @Test
    public final void bdcTest() {
        byte[] input = Helpers2.getBytes("0C01000D0A");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <BCD Value=\"0A\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * DateTime test.
     */
    @Test
    public final void timeTest() {
        byte[] input = Helpers2.getBytes("0C 01 00 1B 01 02 03 04");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <Time Value=\"01020304\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        LOGGER.log(Level.INFO, expected + " " + actual);

        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Date Time test.
     */
    @Test
    public final void dateTimeTest() {
        byte[] input = Helpers2
                .getBytes("0C 01 00 19 07 E0 01 02 ff 04 05 06 07 80 00 80");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <DateTime Value=\"07E00102FF04050607800080\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Date test.
     */
    @Test
    public final void dateTest() {
        byte[] input = Helpers2.getBytes("0C 01 00 1A 07 E0 01 02 FF");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <Date Value=\"07E00102FF\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Float32 test.
     */
    @Test
    public final void float32Test() {
        byte[] input = Helpers2.getBytes("0C 01 00 17 01 02 03 04");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <Float32 Value=\"01020304\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Float64 test.
     */
    @Test
    public final void float64Test() {
        byte[] input = Helpers2.getBytes("0C 01 00 18 01 02 03 04 05 06 07 08");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <Float64 Value=\"0102030405060708\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Bit string test.
     */
    @Test
    public final void bitStringTest() {
        byte[] input = Helpers2.getBytes("0C01000410AB54");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <BitString Value=\"1010101101010100\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * String test.
     */
    @Test
    public final void stringTest() {
        byte[] input = Helpers2.getBytes("0C01000A054775727578");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <String Value=\"Gurux\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Utf String test.
     */
    @Test
    public final void uftStringTest() {
        byte[] input = Helpers2.getBytes("0C01000C0BE282AC4775727578E282AC");
        // CHECKSTYLE:OFF
        String expected =
                "<ReadResponse Qty=\"01\" >\r\n  <Data>\r\n    <StringUTF8 Value=\"€Gurux€\" />\r\n  </Data>\r\n</ReadResponse>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Data notification test.
     */
    @Test
    public final void dataNotificationTest() {
        // CHECKSTYLE:OFF
        byte[] input = Helpers2.getBytes(
                "0F400000010C07D00101060000000000000002060106020412002809060004190900FF0F021200000204120001090600002A0000FF0F02120000020412000809060000010000FF0F02120000020412000109060000616214FF0F02120000020412000109060000616215FF0F02120000020412000109060000600B01FF0F0212000009104D454C31303130373130353030313031090C07E00310030D392A00FFC400060000200006000000001628");
        String expected =
                "<DataNotification>\r\n  <LongInvokeIdAndPriority Value=\"40000001\" />\r\n  <DateTime Value=\"07D001010600000000000000\" />\r\n  <NotificationBody>\r\n    <DataValue>\r\n      <Structure Qty=\"06\" >\r\n        <Array Qty=\"06\" >\r\n          <Structure Qty=\"04\" >\r\n            <UInt16 Value=\"0028\" />\r\n            <OctetString Value=\"0004190900FF\" />\r\n            <Int8 Value=\"02\" />\r\n            <UInt16 Value=\"0000\" />\r\n          </Structure>\r\n          <Structure Qty=\"04\" >\r\n            <UInt16 Value=\"0001\" />\r\n            <OctetString Value=\"00002A0000FF\" />\r\n            <Int8 Value=\"02\" />\r\n            <UInt16 Value=\"0000\" />\r\n          </Structure>\r\n          <Structure Qty=\"04\" >\r\n            <UInt16 Value=\"0008\" />\r\n            <OctetString Value=\"0000010000FF\" />\r\n            <Int8 Value=\"02\" />\r\n            <UInt16 Value=\"0000\" />\r\n          </Structure>\r\n          <Structure Qty=\"04\" >\r\n            <UInt16 Value=\"0001\" />\r\n            <OctetString Value=\"0000616214FF\" />\r\n            <Int8 Value=\"02\" />\r\n            <UInt16 Value=\"0000\" />\r\n          </Structure>\r\n          <Structure Qty=\"04\" >\r\n            <UInt16 Value=\"0001\" />\r\n            <OctetString Value=\"0000616215FF\" />\r\n            <Int8 Value=\"02\" />\r\n            <UInt16 Value=\"0000\" />\r\n          </Structure>\r\n          <Structure Qty=\"04\" >\r\n            <UInt16 Value=\"0001\" />\r\n            <OctetString Value=\"0000600B01FF\" />\r\n            <Int8 Value=\"02\" />\r\n            <UInt16 Value=\"0000\" />\r\n          </Structure>\r\n        </Array>\r\n        <OctetString Value=\"4D454C31303130373130353030313031\" />\r\n        <OctetString Value=\"07E00310030D392A00FFC400\" />\r\n        <UInt32 Value=\"00002000\" />\r\n        <UInt32 Value=\"00000000\" />\r\n        <Enum Value=\"28\" />\r\n      </Structure>\r\n    </DataValue>\r\n  </NotificationBody>\r\n</DataNotification>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Data notification datetime test.
     */
    @Test
    public final void dataNotificationDateTimeTest() {
        byte[] input = Helpers2.getBytes(
                "0f40000001 0C 07 E0 01 02 ff 04 05 06 07 80 00 80 00");
        // CHECKSTYLE:OFF
        String expected =
                "<DataNotification>\r\n  <LongInvokeIdAndPriority Value=\"40000001\" />\r\n  <DateTime Value=\"07E00102FF04050607800080\" />\r\n  <NotificationBody>\r\n    <DataValue>\r\n      <None />\r\n    </DataValue>\r\n  </NotificationBody>\r\n</DataNotification>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Data notification date test.
     */
    @Test
    public final void dataNotificationDateTest() {
        byte[] input = Helpers2.getBytes("0f40000001 05 07 E0 01 02 FF 00");
        // CHECKSTYLE:OFF
        String expected =
                "<DataNotification>\r\n  <LongInvokeIdAndPriority Value=\"40000001\" />\r\n  <DateTime Value=\"07E00102FF\" />\r\n  <NotificationBody>\r\n    <DataValue>\r\n      <None />\r\n    </DataValue>\r\n  </NotificationBody>\r\n</DataNotification>\r\n";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(input);
        assertEquals(expected, actual);
        assertEquals(expected, equals(expected, actual));
        String output = converter.xmlToHexPdu(actual);
        assertEquals(GXCommon.toHex(input, false, 0, input.length), output);
    }

    /*
     * Data notification date test.
     */
    @Test
    public final void uaTest() {
        // CHECKSTYLE:OFF
        String input =
                "7E A0 07 03 21 93 0F 01 7E 7E A0 1E 21 03 73 C3 7A 81 80 12 05 01 80 06 01 3E 07 04 00 00 00 01 08 04 00 00 00 01 07 22 7E";
        // CHECKSTYLE:ON
        GXByteBuffer bb = new GXByteBuffer();
        StringBuilder sb = new StringBuilder();
        GXByteBuffer pdu = new GXByteBuffer();
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);

        bb.set(GXDLMSTranslator.hexToBytes(input));
        while (converter.findNextFrame(bb, pdu)) {
            sb.setLength(0);
            sb.append(converter.messageToXml(bb));
        }
        // CHECKSTYLE:OFF
        assertEquals(
                "<HDLC len=\"1D\" >\r\n<TargetAddress Value=\"10\" />\r\n<SourceAddress Value=\"1\" />\r\n<PDU>\r\n<Ua>\r\n  <MaxInfoRX Value=\"128\" />\r\n  <MaxInfoTX Value=\"62\" />\r\n  <WindowSizeRX Value=\"1\" />\r\n  <WindowSizeTX Value=\"1\" />\r\n</Ua>\r\n</PDU>\r\n</HDLC>\r\n",
                sb.toString());
        // CHECKSTYLE:ON
    }

    /*
     * HDLC LN test.
     */
    @Test
    public final void hdlcLnTest() {
        // CHECKSTYLE:OFF
        String input =
                "7E A0 07 03 21 93 0F 01 7E7E A0 20 21 03 73 73 98 81 80 14 05 02 00 80 06 02 00 80 07 04 00 00 00 01 08 04 00 00 00 01 CE 6A 7E7E A0 2B 03 21 10 FB AF E6 E6 00 60 1D A1 09 06 07 60 85 74 05 08 01 01 BE 10 04 0E 01 00 00 00 06 5F 1F 04 00 00 7E 1F FF FF 99 C8 7E7E A0 37 21 03 30 6C 7C E6 E7 00 61 29 A1 09 06 07 60 85 74 05 08 01 01 A2 03 02 01 00 A3 05 A1 03 02 01 00 BE 10 04 0E 08 00 06 5F 1F 04 00 00 10 10 03 EF 00 07 71 F7 7E7E A0 19 03 21 32 6F D8 E6 E6 00 C0 01 81 00 0F 00 00 28 00 00 FF 02 00 94 9E 7E7E A8 89 21 03 42 07 B9 E6 E7 00 C4 01 81 00 01 0F 02 04 12 00 01 11 00 09 06 01 01 00 00 01 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 00 02 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 00 03 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 82 01 D5 94 7E7E A0 07 03 21 51 11 E4 7E7E A8 89 21 03 44 31 DC FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 82 02 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 60 01 00 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 00 00 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 42 07 7E 7E A0 07 03 21 71 13 C5 7E7E A8 89 21 03 46 23 FF 12 00 01 11 00 09 06 01 01 60 01 01 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 02 00 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 02 02 80 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 01 11 00 09 06 01 01 00 00 04 FF 02 02 01 02 02 03 0F 01 16 01 11 BB 7E7E A0 07 03 21 91 1D 22 7E 7E A8 89 21 03 48 5D 16 00 02 03 0F 02 16 01 00 01 00 02 04 12 00 08 11 00 09 06 00 01 01 00 00 FF 02 02 01 09 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 02 03 0F 03 16 00 00 02 03 0F 04 16 01 00 02 03 0F 05 16 01 00 02 03 0F 06 16 01 00 02 03 0F 07 16 01 00 02 03 0F 08 16 01 00 02 03 0F 09 16 01 00 01 00 02 04 12 00 11 11 00 09 06 00 00 29 00 00 FF 02 02 01 02 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 01 E8 E9 7E 7E A0 07 03 21 B1 1F 03 7E7E A8 89 21 03 4A 4F 35 00 02 04 12 00 0F 11 00 09 06 00 00 28 00 00 FF 02 02 01 08 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 02 03 0F 03 16 01 00 02 03 0F 04 16 01 00 02 03 0F 05 16 01 00 02 03 0F 06 16 01 00 02 03 0F 07 16 00 00 02 03 0F 08 16 01 00 01 00 02 04 12 00 17 11 01 09 06 00 00 16 00 00 FF 02 02 01 0A 02 03 0F 01 16 01 00 02 03 0F 02 16 01 00 02 03 0F 03 16 01 00 02 03 0F 04 16 01 00 02 03 0F F5 7D 7E7E A0 07 03 21 D1 19 60 7E7E A0 32 21 03 5C 51 BB 05 16 01 00 02 03 0F 06 16 01 00 02 03 0F 07 16 01 00 02 03 0F 08 16 01 00 02 03 0F 09 16 01 00 02 03 0F FF 16 01 00 01 00 2E B1 7E";
        // CHECKSTYLE:ON
        GXByteBuffer bb = new GXByteBuffer();
        GXByteBuffer pdu = new GXByteBuffer();
        bb.set(GXDLMSTranslator.hexToBytes(input));
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        StringBuilder sb = new StringBuilder();
        while (converter.findNextFrame(bb, pdu)) {
            sb.setLength(0);
            sb.append(converter.messageToXml(bb));
        }
    }

    /*
     * HDLC LN test.
     */
    @Test
    public final void notifyTest() {
        // CHECKSTYLE:OFF
        String input =
                "0F8000000000020D09104352593030303030303030323334353109060001190900FF0906FF00630100FF013B020912000809060000010000FF0F021200000209120003090601001F0700FF0F02120000020912000309060100330700FF0F02120000020912000309060100470700FF0F02120000020912000309060100200700FF0F02120000020912000309060100340700FF0F02120000020912000309060100480700FF0F02120000020912000309060100210700FF0F02120000020912000309060100350700FF0F02120000020912000309060100490700FF0F021200000209120003090601000D0700FF0F021200000209120003090601000E0700FF0F02120000020912000309060100090700FF0F02120000020912000309060100010700FF0F02120000020912000309060100030700FF0F02120000020912000309060100600700FF0F021200000209120003090600005E5B08FF0F021200000209120001090600005E5B00FF0F02120000020912000109060000000100FF0F02120000020912000109060000600200FF0F02120000020912000309060000000102FF0F02120000020912000309060100010800FF0F02120000020912000309060100050800FF0F02120000020912000309060100080800FF0F02120000020912000309060100090800FF0F02120000020912000309060100010600FF0F02120000020912000309060100010600FF0F05120000020912000309060100090600FF0F02120000020912000309060100090600FF0F051200000103023B090C07E0091DFF0D2818FFFCD0001200A31200851200641209CA1209C31209C311641164116411641201F21200B41200B41200001200061200000600000001120000120000090C084F0F1FFF1F3F1FFFFCD000060000065506000000000600000000060000065412011C090C07E0091CFF151E00FFFCD00012011C090C07E0091CFF151E00FFFCD000013302050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F00160002050F001600";
        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.pduToXml(GXDLMSTranslator.hexToBytes(input));
        converter.xmlToHexPdu(actual);
    }

    /*
     * Issuetest.
     */
    @Test
    public final void issueTest() {
        String expected = "0F800000000002020F001600";
        // CHECKSTYLE:OFF
        String input =
                "<DataNotification>  <LongInvokeIdAndPriority Value=\"80000000\" />  <Data>         <Structure Qty=\"02\" >          <Int8 Value=\"00\" />          <Enum Value=\"00\" />        </Structure>   </Data></DataNotification>";

        // CHECKSTYLE:ON
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        String actual = converter.xmlToHexPdu(input);
        assertEquals(expected, actual);
    }

    /*
     * A test for unacceptable frame response.
     */
    @Test
    public final void unacceptableFrameTest() {
        // CHECKSTYLE:OFF
        String input = "7E A0 0A 03 00 02 00 23 97 50 CB 7E";
        // CHECKSTYLE:ON
        GXByteBuffer bb = new GXByteBuffer();
        GXByteBuffer pdu = new GXByteBuffer();
        bb.set(GXDLMSTranslator.hexToBytes(input));
        GXDLMSTranslator converter =
                new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
        StringBuilder sb = new StringBuilder();
        while (converter.findNextFrame(bb, pdu)) {
            sb.setLength(0);
            sb.append(converter.messageToXml(bb));
        }
        assertEquals(
                "<HDLC len=\"C\" >\r\n<TargetAddress Value=\"1\" />\r\n<SourceAddress Value=\"4011\" />\r\n<UnacceptableFrame>\r\n</UnacceptableFrame>\r\n</HDLC>\r\n",
                sb.toString());
    }

    /*
     * Read test file.
     */
    @Test
    public final void fileTest() throws IOException {
        String name = "test.log";
        if (new File(name).exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(name))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\r\n");
                }
                GXByteBuffer str = new GXByteBuffer();
                str.add(GXDLMSTranslator.hexToBytes(sb.toString()));
                GXByteBuffer pdu = new GXByteBuffer();
                GXDLMSTranslator converter =
                        new GXDLMSTranslator(TranslatorOutputType.SIMPLE_XML);
                InterfaceType type = GXDLMSTranslator.getDlmsFraming(str);
                while (converter.findNextFrame(str, pdu, type)) {
                    System.out.println(converter.messageToXml(str));
                    pdu.clear();
                }
            }
        }
    }
}
