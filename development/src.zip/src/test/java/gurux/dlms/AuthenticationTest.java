//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.asn.GXAsn1Converter;
import gurux.dlms.asn.GXAsn1Integer;
import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.ObjectType;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSAssociationShortName;
import gurux.dlms.objects.GXDLMSSecuritySetup;
import gurux.dlms.secure.AesGcmParameter;
import gurux.dlms.secure.GXDLMSSecureClient;

/**
 * @author Gurux Ltd
 */
public class AuthenticationTest {
    private GXDLMSSecureClient target = null;
    private TestServer server = null;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
        target = new GXDLMSSecureClient();
        target.setServerAddress(1);
        target.setInterfaceType(InterfaceType.WRAPPER);
    }

    @After
    public final void tearDown() {
    }

    /**
     * A test for High authentication for LN.
     */
    @Test
    public final void highAuthenticationLNTest() {
        byte[] secret1 = "Gurux".getBytes();

        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        GXDLMSAssociationLogicalName item =
                new GXDLMSAssociationLogicalName("0.0.40.0.0.255");
        // item.setSecret(secret1);
        server.getItems().add(item);
        server.initialize();
        target.setAuthentication(Authentication.HIGH);
        server.getSettings().setUseCustomChallenge(true);
        target.getSettings().setUseCustomChallenge(true);
        server.getSettings()
                .setStoCChallenge(GXCommon.hexToBytes("AA0237C0D76C1245"));
        target.getSettings().setCtoSChallenge("12345678".getBytes());
        target.setPassword(secret1);
        target.setClientAddress(1);
        byte[][] buff = target.aarqRequest();
        byte[] reply = server.handleRequest(buff[0]);
        GXReplyData info = new GXReplyData();
        target.getData(reply, info);
        target.parseAareResponse(info.getData());
        assertEquals(true, target.getIsAuthenticationRequired());
        if (target.getIsAuthenticationRequired()) {
            buff = target.getApplicationAssociationRequest();
            reply = server.handleRequest(buff[0]);
            info.clear();
            target.getData(reply, info);
            target.parseApplicationAssociationResponse(info.getData());
        }
    }

    /**
     * A test for High SHA1 authentication for LN.
     */
    @Test
    public final void highSha1AuthenticationLNTest() {
        target.setUseLogicalNameReferencing(true);
        GXDLMSAssociationLogicalName item =
                new GXDLMSAssociationLogicalName("0.0.40.0.0.255");
        server = new TestServer(item, InterfaceType.WRAPPER);
        item.setHlsSecret("ABCDEFGH".getBytes());
        server.getItems().add(item);
        server.initialize();
        target.setAuthentication(Authentication.HIGH_SHA1);
        server.getSettings().setUseCustomChallenge(true);
        target.getSettings().setUseCustomChallenge(true);
        server.getSettings()
                .setStoCChallenge(GXCommon.hexToBytes("AA0237C0D76C1245"));
        target.getSettings().setCtoSChallenge("12345678".getBytes());
        target.setPassword("ABCDEFGH");
        target.setClientAddress(0x1);
        byte[][] buff = target.aarqRequest();
        byte[] reply = server.handleRequest(buff[0]);
        GXReplyData info = new GXReplyData();
        target.getData(reply, info);
        target.parseAareResponse(info.getData());
        assertEquals(true, target.getIsAuthenticationRequired());
        if (target.getIsAuthenticationRequired()) {
            buff = target.getApplicationAssociationRequest();
            reply = server.handleRequest(buff[0]);
            info.clear();
            target.getData(reply, info);
            target.parseApplicationAssociationResponse(info.getData());
        }
    }

    /**
     * A test for High SHA1 authentication for SN.
     */
    @Test
    public final void highSha1AuthenticationSNTest() {
        byte[] secret = "ABCDEFGH".getBytes();
        target.setUseLogicalNameReferencing(false);
        GXDLMSAssociationShortName item = new GXDLMSAssociationShortName();
        server = new TestServer(item, InterfaceType.WRAPPER);
        item.setSecret(secret);
        server.getItems().add(item);
        server.initialize();

        GXDLMSAssociationShortName sn =
                (GXDLMSAssociationShortName) server.getItems().findByLN(
                        ObjectType.ASSOCIATION_SHORT_NAME, "0.0.40.0.0.255");
        sn.setHlsSecret(secret);

        target.setAuthentication(Authentication.HIGH_SHA1);
        server.getSettings().setUseCustomChallenge(true);
        target.getSettings().setUseCustomChallenge(true);
        server.getSettings()
                .setStoCChallenge(GXCommon.hexToBytes("AA0237C0D76C1245"));
        target.getSettings().setCtoSChallenge("12345678".getBytes());
        target.setPassword("ABCDEFGH");
        target.setClientAddress(1);
        byte[][] buff = target.aarqRequest();
        byte[] reply = server.handleRequest(buff[0]);
        GXReplyData info = new GXReplyData();
        target.getData(reply, info);
        target.parseAareResponse(info.getData());
        assertEquals(true, target.getIsAuthenticationRequired());
        if (target.getIsAuthenticationRequired()) {
            buff = target.getApplicationAssociationRequest();
            reply = server.handleRequest(buff[0]);
            info.clear();
            target.getData(reply, info);
            target.parseApplicationAssociationResponse(info.getData());
        }
    }

    public static Cipher getCipher(final AesGcmParameter p,
            final boolean encrypt)
            throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, InvalidAlgorithmParameterException {
        GXByteBuffer iv = new GXByteBuffer();
        iv.set(p.getSystemTitle());
        iv.setUInt32(p.getInvocationCounter());
        SecretKeySpec eks = new SecretKeySpec(p.getBlockCipherKey(), "AES");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        int mode;
        if (encrypt) {
            mode = Cipher.ENCRYPT_MODE;
        } else {
            mode = Cipher.DECRYPT_MODE;
        }
        c.init(mode, eks, new GCMParameterSpec(12 * 8, iv.array()));
        return c;
    }

    /*
     * A test for High ECDSA authentication.
     */
    @Test
    public final void highEcdsaAuthenticationTest() throws Exception {
        byte[] sysTc = GXCommon.hexToBytes("4D4D4D0000BC614E");
        byte[] sysTs = GXCommon.hexToBytes("4D4D4D0000000001");
        byte[] cToS = GXCommon.hexToBytes(
                "2CA1FC2DE9CD03B5E8E234CEA16F2853F6DC5F54526F4F4995772A50FB7E63B3");
        byte[] sToC = GXCommon.hexToBytes(
                "18E95FFE3AD0DCABDC5D0D141DC987E270CB0A395948D4231B09DE6579883657");
        // Client public key.
        PublicKey pubKc = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "917DBFECA43307375247989F07CC23F53D4B963AF8026C749DB"
                        + "33852011056DFDBE8327BD69CC149F018A8E446DD"
                        + "A6C55BCD78E596A56D403236233F93CC89B3"));
        // Client private key.
        PrivateKey priKc = GXAsn1Converter.getPrivateKey(
                GXCommon.hexToBytes("E9A045346B2057F1820318AB125493E9AB"
                        + "36CE590011C0FF30090858A118DD2E"));
        // Server public key.
        PublicKey pubKs = GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                "E4D07CEB0A5A6DA9D2228B054A1F5E295E1747A963974AF7509"
                        + "1A0B0BC2FB92DA7D2ABD9FDD41579F36A1C8171A0"
                        + "CB638221DF1949FD95C8FAE148896920450D"));

        // Server private key.
        PrivateKey priKs = GXAsn1Converter
                .getPrivateKey(GXCommon.hexToBytes("B582D8C910018302BA3131BAB9"
                        + "BB6838108BB9408C30B2E49285985256A59038"));

        // ECDSA(SystemTitle-C || SystemTitle-S ||StoC || CtoS) (calculated with
        // Pri-KC)

        // GXByteBuffer data = new GXByteBuffer();
        // data.set(sysTc);
        // data.set(sysTs);
        // data.set(sToC);
        // data.set(cToS);

        GXByteBuffer expected = new GXByteBuffer(GXCommon.hexToBytes(
                "C5C6D6620BDB1A39FCE50F4D64F0DB712D6FB57A64030B0C297E1250DC859660D3B1FA334AD80411807369F5DD3BC17B59894C9E9C11C59376580D15A2646D16"));

        Signature sig = Signature.getInstance("SHA256withECDSA");
        sig.initSign(priKc);
        GXByteBuffer bb = new GXByteBuffer();
        bb.set(sysTc);
        bb.set(sysTs);
        bb.set(sToC);
        bb.set(cToS);
        sig.update(bb.array());
        byte[] actual = sig.sign();

        Signature ver = Signature.getInstance("SHA256withECDSA");
        ver.initVerify(pubKc);
        bb = new GXByteBuffer();
        bb.set(sysTc);
        bb.set(sysTs);
        bb.set(sToC);
        bb.set(cToS);
        ver.update(bb.array());
        byte[] tmp = GXAsn1Converter.toByteArray(
                new Object[] { new GXAsn1Integer(expected.subArray(0, 32)),
                        new GXAsn1Integer(expected.subArray(32, 32)) });
        assertEquals(true, ver.verify(tmp));

        expected = new GXByteBuffer(GXCommon.hexToBytes(
                "946C2E3E4F18291571F4A45ACB7086100574694A3BAF67D2D147FE8F92481A5AB2186C5CBC3F80E94482D9388B85C6A73E5FD687F09773C1F615AA2A905ED057"));

        //
        // // ECDSA(SystemTitle-S || SystemTitle-C || CtoS || StoC) (calculated
        // // with Pri-KS)
        sig = Signature.getInstance("SHA256withECDSA");
        sig.initSign(priKs);
        bb.clear();
        bb.set(sysTs);
        bb.set(sysTc);
        bb.set(cToS);
        bb.set(sToC);
        sig.update(bb.array());
        actual = sig.sign();
        ver = Signature.getInstance("SHA256withECDSA");
        ver.initVerify(pubKs);
        bb = new GXByteBuffer();
        bb.set(sysTs);
        bb.set(sysTc);
        bb.set(cToS);
        bb.set(sToC);
        ver.update(bb.array());
        tmp = GXAsn1Converter.toByteArray(
                new Object[] { new GXAsn1Integer(expected.subArray(0, 32)),
                        new GXAsn1Integer(expected.subArray(32, 32)) });
        assertEquals(true, ver.verify(tmp));
    }

    /*
     * A test for High ECDSA authentication for LN.
     */
    @Test
    public final void highEcdsaAuthenticationLNTest() throws Exception {
        target.setUseLogicalNameReferencing(true);
        server = new TestServer(new GXDLMSAssociationLogicalName(),
                InterfaceType.WRAPPER);
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        target.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000BC614E"));
        server.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000000001"));
        // Client public key.
        PublicKey clientPublic =
                GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                        "917DBFECA43307375247989F07CC23F53D4B963AF8026C749DB"
                                + "33852011056DFDBE8327BD69CC149F018A8E446DD"
                                + "A6C55BCD78E596A56D403236233F93CC89B3"));
        // Client private key.
        PrivateKey clientPrivate = GXAsn1Converter.getPrivateKey(
                GXCommon.hexToBytes("E9A045346B2057F1820318AB125493E9AB"
                        + "36CE590011C0FF30090858A118DD2E"));

        target.getCiphering().setKeyAgreementKeyPair(
                new KeyPair(clientPublic, clientPrivate));
        // Server public key.
        PublicKey serverPublic =
                GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                        "E4D07CEB0A5A6DA9D2228B054A1F5E295E1747A963974AF7509"
                                + "1A0B0BC2FB92DA7D2ABD9FDD41579F36A1C8171A0"
                                + "CB638221DF1949FD95C8FAE148896920450D"));

        // Server private key.
        PrivateKey serverPrivate = GXAsn1Converter
                .getPrivateKey(GXCommon.hexToBytes("B582D8C910018302BA3131BAB9"
                        + "BB6838108BB9408C30B2E49285985256A59038"));

        server.getCiphering().setKeyAgreementKeyPair(
                new KeyPair(serverPublic, serverPrivate));
        // TODO: This is removed for now because all JVMs are not supporting
        // this.
        // KeyPair clientKp = new KeyPair(clientPublic, clientPrivate);
        // X509Certificate clientCertificate =
        // Helpers2.createSelfSignedCertificate(clientKp);
        //
        // KeyPair serverKp = new KeyPair(serverPublic, serverPrivate);
        // X509Certificate serverCertificate =
        // Helpers2.createSelfSignedCertificate(serverKp);
        // System.out.println(GXCommon.toBase64(serverCertificate.getEncoded()));
        // target.setClientCertificate(clientCertificate);
        // target.getCertificates().add(serverCertificate);
        // server.getItems().add(item);
        // server.initialize();
        // target.setClientAddress(0x1);
        // // Make connection and update client certificate for the server.
        // byte[][] buff = target.aarqRequest();
        // byte[] reply = server.handleRequest(buff[0]);
        // GXReplyData info = new GXReplyData();
        // target.getData(reply, info);
        // target.parseAareResponse(info.getData());
        //
        // // Import client certificate to the server.
        // buff = item.importCertificate(target, clientCertificate);
        // reply = server.handleRequest(buff[0]);
        // // Close connection.
        // server.handleRequest(target.disconnectRequest());
        // // Make new connection using ECDSA.
        // target.setAuthentication(Authentication.HIGH_ECDSA);
        // server.getSettings().setUseCustomChallenge(true);
        // target.getSettings().setUseCustomChallenge(true);
        // server.getSettings().setStoCChallenge(
        // GXCommon.hexToBytes("18E95FFE3AD0DCABDC5D0D141DC987E"
        // + "270CB0A395948D4231B09DE6579883657"));
        // target.getSettings().setCtoSChallenge(
        // GXCommon.hexToBytes("2CA1FC2DE9CD03B5E8E234CEA16F285"
        // + "3F6DC5F54526F4F4995772A50FB7E63B3"));
        // buff = target.aarqRequest();
        // reply = server.handleRequest(buff[0]);
        // info = new GXReplyData();
        // target.getData(reply, info);
        // target.parseAareResponse(info.getData());
        // assertEquals(true, target.getIsAuthenticationRequired());
        // if (target.getIsAuthenticationRequired()) {
        // buff = target.getApplicationAssociationRequest();
        // reply = server.handleRequest(buff[0]);
        // info.clear();
        // target.getData(reply, info);
        // target.parseApplicationAssociationResponse(info.getData());
        // }
    }

    /*
     * A test for High ECDSA authentication for SN.
     */
    @Test
    public final void highEcdsaAuthenticationSNTest() throws Exception {
        target.setUseLogicalNameReferencing(false);
        server = new TestServer(new GXDLMSAssociationShortName(),
                InterfaceType.WRAPPER);
        GXDLMSSecuritySetup item = new GXDLMSSecuritySetup();
        target.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000BC614E"));
        server.getCiphering()
                .setSystemTitle(GXCommon.hexToBytes("4D4D4D0000000001"));
        // Client public key.
        PublicKey clientPublic =
                GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                        "917DBFECA43307375247989F07CC23F53D4B963AF8026C749DB"
                                + "33852011056DFDBE8327BD69CC149F018A8E446DD"
                                + "A6C55BCD78E596A56D403236233F93CC89B3"));
        // Client private key.
        PrivateKey clientPrivate = GXAsn1Converter.getPrivateKey(
                GXCommon.hexToBytes("E9A045346B2057F1820318AB125493E9AB"
                        + "36CE590011C0FF30090858A118DD2E"));

        target.getCiphering().setKeyAgreementKeyPair(
                new KeyPair(clientPublic, clientPrivate));
        // Server public key.
        PublicKey serverPublic =
                GXAsn1Converter.getPublicKey(GXCommon.hexToBytes(
                        "E4D07CEB0A5A6DA9D2228B054A1F5E295E1747A963974AF7509"
                                + "1A0B0BC2FB92DA7D2ABD9FDD41579F36A1C8171A0"
                                + "CB638221DF1949FD95C8FAE148896920450D"));

        // Server private key.
        PrivateKey serverPrivate = GXAsn1Converter
                .getPrivateKey(GXCommon.hexToBytes("B582D8C910018302BA3131BAB9"
                        + "BB6838108BB9408C30B2E49285985256A59038"));

        server.getCiphering().setKeyAgreementKeyPair(
                new KeyPair(serverPublic, serverPrivate));
        // TODO: This is removed for now because all JVMs are not supporting
        // this.
        // KeyPair clientKp = new KeyPair(clientPublic, clientPrivate);
        // X509Certificate clientCertificate =
        // Helpers2.createSelfSignedCertificate(clientKp);
        //
        // KeyPair serverKp = new KeyPair(serverPublic, serverPrivate);
        // X509Certificate serverCertificate =
        // Helpers2.createSelfSignedCertificate(serverKp);
        // target.setClientCertificate(clientCertificate);
        // target.getCertificates().add(serverCertificate);
        // server.getItems().add(item);
        // server.initialize();
        // target.setClientAddress(0x1);
        // // Make connection and update client certificate for the server.
        // byte[][] buff = target.aarqRequest();
        // byte[] reply = server.handleRequest(buff[0]);
        // GXReplyData info = new GXReplyData();
        // target.getData(reply, info);
        // target.parseAareResponse(info.getData());
        //
        // // Import client certificate to the server.
        // buff = item.importCertificate(target, clientCertificate);
        // reply = server.handleRequest(buff[0]);
        // // Close connection.
        // server.handleRequest(target.disconnectRequest());
        // // Make new connection using ECDSA.
        // target.setAuthentication(Authentication.HIGH_ECDSA);
        // server.getSettings().setUseCustomChallenge(true);
        // target.getSettings().setUseCustomChallenge(true);
        // server.getSettings().setStoCChallenge(
        // GXCommon.hexToBytes("18E95FFE3AD0DCABDC5D0D141DC987E"
        // + "270CB0A395948D4231B09DE6579883657"));
        // target.getSettings().setCtoSChallenge(
        // GXCommon.hexToBytes("2CA1FC2DE9CD03B5E8E234CEA16F285"
        // + "3F6DC5F54526F4F4995772A50FB7E63B3"));
        // buff = target.aarqRequest();
        // reply = server.handleRequest(buff[0]);
        // info = new GXReplyData();
        // target.getData(reply, info);
        // target.parseAareResponse(info.getData());
        // assertEquals(true, target.getIsAuthenticationRequired());
        // if (target.getIsAuthenticationRequired()) {
        // buff = target.getApplicationAssociationRequest();
        // reply = server.handleRequest(buff[0]);
        // info.clear();
        // target.getData(reply, info);
        // target.parseApplicationAssociationResponse(info.getData());
        // }
    }
}
