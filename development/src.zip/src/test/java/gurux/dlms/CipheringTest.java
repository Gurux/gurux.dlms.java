//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import gurux.dlms.enums.Authentication;
import gurux.dlms.enums.DataType;
import gurux.dlms.enums.InterfaceType;
import gurux.dlms.enums.ObjectType;
import gurux.dlms.enums.Priority;
import gurux.dlms.enums.Security;
import gurux.dlms.enums.ServiceClass;
import gurux.dlms.internal.GXCommon;
import gurux.dlms.objects.GXDLMSAssociationLogicalName;
import gurux.dlms.objects.GXDLMSAssociationShortName;
import gurux.dlms.objects.GXDLMSClock;
import gurux.dlms.secure.GXDLMSSecureClient;

/**
 * Ciphering tests.
 * 
 * @author Gurux Ltd
 */
public class CipheringTest {
    private GXDLMSSecureClient target;
    private TestServer server;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public final void setUp() {
    }

    @After
    public final void tearDown() {
    }

    private void initialize(final GXDLMSAssociationLogicalName ln,
            final int clientaddress, final int serverID,
            final InterfaceType type) {
        server = new TestServer(ln, type);
        initialize(clientaddress, serverID, type);
    }

    private void initialize(final GXDLMSAssociationShortName sn,
            final int clientaddress, final int serverID,
            final InterfaceType type) {
        server = new TestServer(sn, type);
        initialize(clientaddress, serverID, type);
    }

    private void initialize(final int clientaddress, final int serverID,
            final InterfaceType type) {

        target = new GXDLMSSecureClient();
        target.setUseLogicalNameReferencing(
                server.getUseLogicalNameReferencing());
        server.getLimits().setMaxInfoRX((byte) 128);

        target.setInvokeID(0);
        target.setPriority(Priority.NORMAL);
        byte[] st =
                new byte[] { (byte) 0x4D, (byte) 0x4D, (byte) 0x4D, (byte) 0x00,
                        (byte) 0x00, (byte) 0xBC, (byte) 0x61, (byte) 0x4E };
        server.getCiphering().setSystemTitle(st);
        target.getCiphering().setSystemTitle(st);
        byte[] ak = new byte[] { (byte) 0xD0, (byte) 0xD1, (byte) 0xD2,
                (byte) 0xD3, (byte) 0xD4, (byte) 0xD5, (byte) 0xD6, (byte) 0xD7,
                (byte) 0xD8, (byte) 0xD9, (byte) 0xDA, (byte) 0xDB, (byte) 0xDC,
                (byte) 0xDD, (byte) 0xDE, (byte) 0xDF };
        server.getCiphering().setAuthenticationKey(ak);
        target.getCiphering().setAuthenticationKey(ak);
        byte[] b = new byte[] { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F };
        server.getCiphering().setBlockCipherKey(b);
        target.getCiphering().setBlockCipherKey(b);
        GXDLMSClock clock = new GXDLMSClock();
        java.util.Calendar tm = Calendar.getInstance();
        java.util.Date now = tm.getTime();
        clock.setTime(new GXDateTime(now));
        server.getItems().add(clock);

        target.setClientAddress(clientaddress);
        target.setServerAddress(serverID);
        target.setInterfaceType(type);
        server.initialize();
    }

    /**
     * An encrypt test for authentication using LN and Interface type is
     * General.
     */
    @Test
    public final void authenticationEncryptGeneralLNTest() {
        initialize(new GXDLMSAssociationLogicalName(), 16, 1,
                InterfaceType.HDLC);
        target.getCiphering().setInvocationCounter(0x01234567);
        target.getCiphering().setSecurity(Security.AUTHENTICATION);
        target.setServiceClass(ServiceClass.UN_CONFIRMED);
        byte[] actual;
        java.nio.ByteBuffer tmp = java.nio.ByteBuffer
                .wrap(target.read(server.getItems().get(0).getName(),
                        ObjectType.CLOCK, 2)[0]);
        if (server.getInterfaceType() == InterfaceType.HDLC) {
            actual = new byte[tmp.capacity() - 14];
        } else {
            actual = new byte[tmp.capacity() - 11];
        }
        tmp.position(11);
        tmp.get(actual);
        if (target.getUseLogicalNameReferencing()) {
            // CHECKSTYLE:OFF
            byte[] expected = GXCommon.hexToBytes(
                    "C81E1001234567C0010000080000010000FF020006725D910F9221D263877516");
            // CHECKSTYLE:ON
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        } else {
            byte[] expected = GXCommon.hexToBytes(
                    "C816100123456705010200A800C63608B95F9543DB806BEC");
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        }
    }

    /**
     * An encrypt test for authentication using SN and Interface type is
     * General.
     */
    @Test
    public final void authenticationEncryptGeneralSNTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1, InterfaceType.HDLC);
        target.getCiphering().setInvocationCounter(0x01234567);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        byte[] actual;
        java.nio.ByteBuffer tmp = java.nio.ByteBuffer
                .wrap(target.read(server.getItems().get(0).getName(),
                        ObjectType.CLOCK, 2)[0]);
        if (server.getInterfaceType() == InterfaceType.HDLC) {
            actual = new byte[tmp.capacity() - 14];
            tmp.position(11);
        } else {
            actual = new byte[tmp.capacity() - 8];
            tmp.position(8);
        }
        tmp.get(actual);
        if (target.getUseLogicalNameReferencing()) {
            // CHECKSTYLE:OFF
            byte[] expected = GXCommon.hexToBytes(
                    "C81E1001234567C0010000080000010000FF020006725D910F9221D263877516");
            // CHECKSTYLE:ON
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        } else {
            byte[] expected = GXCommon.hexToBytes(
                    "25163001234567841310FF33BA2F4265ECAE1973BC1A4C5E");
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        }
    }

    /**
     * An encrypt test for authentication using LN and Interface type is
     * General.
     */
    @Test
    public final void authenticationEncryptNetLNTest() {
        initialize(new GXDLMSAssociationLogicalName(), 16, 1,
                InterfaceType.WRAPPER);
        target.getCiphering().setInvocationCounter(0x01234567);
        target.getCiphering().setSecurity(Security.AUTHENTICATION);
        target.setServiceClass(ServiceClass.UN_CONFIRMED);
        byte[] actual;
        java.nio.ByteBuffer tmp = java.nio.ByteBuffer
                .wrap(target.read(server.getItems().get(0).getName(),
                        ObjectType.CLOCK, 2)[0]);
        if (server.getInterfaceType() == InterfaceType.HDLC) {
            actual = new byte[tmp.capacity() - 14];
            tmp.position(11);
        } else {
            actual = new byte[tmp.capacity() - 8];
            tmp.position(8);
        }
        tmp.get(actual);
        if (target.getUseLogicalNameReferencing()) {
            // CHECKSTYLE:OFF
            byte[] expected = GXCommon.hexToBytes(
                    "C81E1001234567C0010000080000010000FF020006725D910F9221D263877516");
            // CHECKSTYLE:ON
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        } else {
            byte[] expected = GXCommon.hexToBytes(
                    "C816100123456705010200A800C63608B95F9543DB806BEC");
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        }
    }

    /**
     * An encrypt test for authentication using SN and Interface type is
     * General.
     */
    @Test
    public final void authenticationEncryptNetSNTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1,
                InterfaceType.WRAPPER);
        target.getCiphering().setInvocationCounter(0x01234567);
        target.getCiphering().setSecurity(Security.AUTHENTICATION);
        byte[] actual;
        java.nio.ByteBuffer tmp = java.nio.ByteBuffer
                .wrap(target.read(server.getItems().get(0).getName(),
                        ObjectType.CLOCK, 2)[0]);
        if (server.getInterfaceType() == InterfaceType.HDLC) {
            actual = new byte[tmp.capacity() - 14];
            tmp.position(11);
        } else {
            actual = new byte[tmp.capacity() - 8];
            tmp.position(8);
        }
        tmp.get(actual);
        if (target.getUseLogicalNameReferencing()) {
            // CHECKSTYLE:OFF
            byte[] expected = GXCommon.hexToBytes(
                    "C81E1001234567C0010000080000010000FF020006725D910F9221D263877516");
            // CHECKSTYLE:ON
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        } else {
            byte[] expected = GXCommon.hexToBytes(
                    "2516100123456705010200A800C63608B95F9543DB806BEC");
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        }
    }

    /**
     * An encrypt test for Encryption.
     */
    @Test
    public final void encryptionEncryptTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1, InterfaceType.HDLC);
        target.getCiphering().setInvocationCounter(0x01234567);
        target.getCiphering().setSecurity(Security.ENCRYPTION);
        byte[] actual;
        java.nio.ByteBuffer tmp = java.nio.ByteBuffer
                .wrap(target.read(server.getItems().get(0).getName(),
                        ObjectType.CLOCK, 2)[0]);
        if (server.getInterfaceType() == InterfaceType.HDLC) {
            actual = new byte[tmp.capacity() - 14];
            tmp.position(11);
        } else {
            actual = new byte[tmp.capacity() - 8];
            tmp.position(8);
        }
        tmp.get(actual);
        if (target.getUseLogicalNameReferencing()) {
            byte[] expected = Helpers2
                    .getBytes("C8122001234567411312FF935A47566827C467BC");
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        } else {
            byte[] expected = GXCommon.hexToBytes("250A2001234567841310FF33");
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        }
    }

    /**
     * An encrypt test for authentication and encryption.
     */
    @Test
    public final void authenticatedencryptionEncryptTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1, InterfaceType.HDLC);
        target.getCiphering().setInvocationCounter(0x01234567);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        byte[] actual;
        java.nio.ByteBuffer tmp = java.nio.ByteBuffer
                .wrap(target.read(server.getItems().get(0), 2)[0]);
        if (server.getInterfaceType() == InterfaceType.HDLC) {
            actual = new byte[tmp.capacity() - 14];
            tmp.position(11);
        } else {
            actual = new byte[tmp.capacity() - 8];
            tmp.position(8);
        }
        tmp.get(actual);
        if (target.getUseLogicalNameReferencing()) {
            // CHECKSTYLE:OFF
            byte[] expected = GXCommon.hexToBytes(
                    "C81E3001234567411312FF935A47566827C467BC7D825C3BE4A77C3FCC056B6B");
            // CHECKSTYLE:ON
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        } else {
            byte[] expected = GXCommon.hexToBytes(
                    "25163001234567841310FF33BA2F4265ECAE1973BC1A4C5E");
            assertEquals(GXCommon.toHex(expected), GXCommon.toHex(actual));
        }
    }

    /**
     * An decrypt test for authentication.
     */
    @Test
    public final void authenticationDecryptTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1, InterfaceType.HDLC);
        target.getCiphering().setSecurity(Security.AUTHENTICATION);
        target.getCiphering().setSystemTitle("Gurux111".getBytes());
        GXReplyData reply = new GXReplyData();
        byte[] data = target.snrmRequest();
        if (data.length != 0) {
            data = server.handleRequest(data);
            target.getData(data, reply);
            target.parseUAResponse(reply.getData());
        }
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        data = target.read(server.getItems().get(0).getName(), ObjectType.CLOCK,
                2)[0];
        data = server.handleRequest(data);
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        data = (byte[]) GXDLMSClient.getValue(info.getData());
        GXDateTime value =
                (GXDateTime) GXDLMSClient.changeType(data, DataType.DATETIME);
        java.util.Date now = Calendar.getInstance().getTime();
        SimpleDateFormat sd = new SimpleDateFormat();
        assert sd.format(now).equals(sd.format(value.getCalendar().getTime()));
    }

    /**
     * An decrypt test for Encryption.
     */
    @Test
    public final void encryptionDecryptTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1, InterfaceType.HDLC);
        target.getCiphering().setSecurity(Security.ENCRYPTION);
        target.getCiphering().setSystemTitle("Gurux111".getBytes());
        byte[] data = target.snrmRequest();
        GXReplyData reply = new GXReplyData();
        if (data.length != 0) {
            data = server.handleRequest(data);
            target.getData(data, reply);
            target.parseUAResponse(reply.getData());
        }
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        data = target.read(server.getItems().get(0).getName(), ObjectType.CLOCK,
                2)[0];
        data = server.handleRequest(data);
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        data = (byte[]) GXDLMSClient.getValue(info.getData());
        GXDateTime value =
                (GXDateTime) GXDLMSClient.changeType(data, DataType.DATETIME);
        java.util.Date now = Calendar.getInstance().getTime();
        SimpleDateFormat sd = new SimpleDateFormat();
        assert sd.format(now).equals(sd.format(value.getCalendar().getTime()));
    }

    /**
     * An decrypt test for authentication and encryption.
     */
    @Test
    public final void authenticatedencryptionDecryptTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1, InterfaceType.HDLC);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        GXReplyData reply = new GXReplyData();
        byte[] data = target.snrmRequest();
        if (data.length != 0) {
            data = server.handleRequest(data);
            target.getData(data, reply);
            target.parseUAResponse(reply.getData());
        }
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        data = target.read(server.getItems().get(0).getName(), ObjectType.CLOCK,
                2)[0];
        java.util.Date now = Calendar.getInstance().getTime();
        data = server.handleRequest(data);
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        data = (byte[]) GXDLMSClient.getValue(info.getData());
        GXDateTime value =
                (GXDateTime) GXDLMSClient.changeType(data, DataType.DATETIME);
        SimpleDateFormat sd = new SimpleDateFormat();
        assert sd.format(now).equals(sd.format(value.getCalendar().getTime()));
    }

    /**
     * An ciphering test for LN with HDLC interface.
     */
    @Test
    public final void securityGeneralLNTest() {
        initialize(new GXDLMSAssociationLogicalName(), 16, 1,
                InterfaceType.HDLC);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        GXReplyData reply = new GXReplyData();
        byte[] data = target.snrmRequest();
        if (data.length != 0) {
            data = server.handleRequest(data);
            target.getData(data, reply);
            target.parseUAResponse(reply.getData());
        }
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        data = target.read(server.getItems().get(0).getName(), ObjectType.CLOCK,
                2)[0];
        data = server.handleRequest(data);
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        data = (byte[]) GXDLMSClient.getValue(info.getData());
        GXDateTime value =
                (GXDateTime) GXDLMSClient.changeType(data, DataType.DATETIME);
        java.util.Date now = Calendar.getInstance().getTime();
        SimpleDateFormat sd = new SimpleDateFormat();
        assert sd.format(now).equals(sd.format(value.getCalendar().getTime()));
    }

    /**
     * An ciphering test for SN with general interface.
     */
    @Test
    public final void securityGeneralSNTest() {
        initialize(new GXDLMSAssociationShortName(), 16, 1, InterfaceType.HDLC);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        GXReplyData reply = new GXReplyData();
        byte[] data = target.snrmRequest();
        if (data.length != 0) {
            data = server.handleRequest(data);
            target.getData(data, reply);
            target.parseUAResponse(reply.getData());
        }
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        data = target.read(server.getItems().get(0).getName(), ObjectType.CLOCK,
                2)[0];
        data = server.handleRequest(data);
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        data = (byte[]) GXDLMSClient.getValue(info.getData());
        GXDateTime value =
                (GXDateTime) GXDLMSClient.changeType(data, DataType.DATETIME);
        java.util.Date now = Calendar.getInstance().getTime();
        SimpleDateFormat sd = new SimpleDateFormat();
        assert sd.format(now).equals(sd.format(value.getCalendar().getTime()));
    }

    /**
     * An ciphering test for LN with Net interface.
     */
    @Test
    public final void securityNetLNTest() {
        initialize(new GXDLMSAssociationLogicalName(), 1, 1,
                InterfaceType.WRAPPER);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        GXReplyData reply = new GXReplyData();
        byte[] data = target.snrmRequest();
        if (data.length != 0) {
            data = server.handleRequest(data);
            target.getData(data, reply);
            target.parseUAResponse(reply.getData());
        }
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        data = target.read(server.getItems().get(0).getName(), ObjectType.CLOCK,
                2)[0];
        data = server.handleRequest(data);
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        data = (byte[]) GXDLMSClient.getValue(info.getData());
        GXDateTime value =
                (GXDateTime) GXDLMSClient.changeType(data, DataType.DATETIME);
        java.util.Date now = Calendar.getInstance().getTime();
        SimpleDateFormat sd = new SimpleDateFormat();
        assert sd.format(now).equals(sd.format(value.getCalendar().getTime()));
    }

    /**
     * An ciphering test for SN with Net interface.
     */
    @Test
    public final void securityNetSNTest() {
        initialize(new GXDLMSAssociationShortName(), 1, 1,
                InterfaceType.WRAPPER);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        GXReplyData reply = new GXReplyData();
        byte[] data = target.snrmRequest();
        if (data.length != 0) {
            data = server.handleRequest(data);
            target.getData(data, reply);
            target.parseUAResponse(reply.getData());
        }
        data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        data = target.read(server.getItems().get(0).getName(), ObjectType.CLOCK,
                2)[0];
        data = server.handleRequest(data);
        GXReplyData info = new GXReplyData();
        target.getData(data, info);
        data = (byte[]) GXDLMSClient.getValue(info.getData());
        GXDateTime value =
                (GXDateTime) GXDLMSClient.changeType(data, DataType.DATETIME);
        java.util.Date now = Calendar.getInstance().getTime();
        SimpleDateFormat sd = new SimpleDateFormat();
        assert sd.format(now).equals(sd.format(value.getCalendar().getTime()));
    }

    /**
     * An ciphering test using Low authentication.
     */
    @Test
    public final void securityLowAuthenticationTest() {
        initialize(new GXDLMSAssociationLogicalName(), 1, 1,
                InterfaceType.WRAPPER);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        target.setAuthentication(Authentication.LOW);
        target.setPassword("Gurux");
        GXReplyData reply = new GXReplyData();
        byte[] data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        assertEquals(false, target.getIsAuthenticationRequired());
    }

    /**
     * An ciphering test using MD5 authentication.
     */
    @Test
    public final void securityMD5AuthenticationTest() {
        byte[] secret = "Gurux".getBytes();
        initialize(new GXDLMSAssociationLogicalName(), 1, 1,
                InterfaceType.WRAPPER);
        GXDLMSAssociationLogicalName ln =
                (GXDLMSAssociationLogicalName) server.getItems().findByLN(
                        ObjectType.ASSOCIATION_LOGICAL_NAME, "0.0.40.0.0.255");
        ln.setSecret(secret);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        target.setAuthentication(Authentication.HIGH_MD5);
        target.setPassword(secret);
        GXReplyData reply = new GXReplyData();
        byte[] data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        assertEquals(true, target.getIsAuthenticationRequired());
        data = target.getApplicationAssociationRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseApplicationAssociationResponse(reply.getData());
    }

    /**
     * An ciphering test using SHA1 authentication.
     */
    @Test
    public final void securitySHA1AuthenticationTest() {
        initialize(new GXDLMSAssociationLogicalName(), 1, 1,
                InterfaceType.WRAPPER);
        byte[] secret = "Gurux".getBytes();
        GXDLMSAssociationLogicalName ln =
                (GXDLMSAssociationLogicalName) server.getItems().findByLN(
                        ObjectType.ASSOCIATION_LOGICAL_NAME, "0.0.40.0.0.255");
        ln.setSecret(secret);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        target.setAuthentication(Authentication.HIGH_SHA1);
        target.setPassword(secret);
        GXReplyData reply = new GXReplyData();
        byte[] data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        assertEquals(true, target.getIsAuthenticationRequired());
        data = target.getApplicationAssociationRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseApplicationAssociationResponse(reply.getData());
    }

    /**
     * An ciphering test using GMAC authentication.
     */
    @Test
    public final void securityGMACAuthenticationTest() {
        initialize(new GXDLMSAssociationLogicalName(), 1, 1,
                InterfaceType.WRAPPER);
        target.getCiphering().setSecurity(Security.AUTHENTICATION_ENCRYPTION);
        target.setAuthentication(Authentication.HIGH_GMAC);
        target.setPassword("Gurux");
        GXReplyData reply = new GXReplyData();
        byte[] data = target.aarqRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseAareResponse(reply.getData());
        assertEquals(true, target.getIsAuthenticationRequired());
        data = target.getApplicationAssociationRequest()[0];
        data = server.handleRequest(data);
        reply.clear();
        target.getData(data, reply);
        target.parseApplicationAssociationResponse(reply.getData());
    }
}
