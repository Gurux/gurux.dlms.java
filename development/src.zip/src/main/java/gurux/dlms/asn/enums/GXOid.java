package gurux.dlms.asn.enums;

public interface GXOid {
    /*
     * Get string value for enumeration.
     */
    String getValue();
}
