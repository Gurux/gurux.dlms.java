//
// --------------------------------------------------------------------------
//  Gurux Ltd
// 
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License 
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.
//
// More information of Gurux products: http://www.gurux.org
//
// This code is licensed under the GNU General Public License v2. 
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

package gurux.dlms;

import java.util.Map;

/**
 * Java ME is not implementing SimpleEntry.
 * 
 * @author Gurux Ltd.
 */
public final class GXSimpleEntry<K, V> implements Map.Entry<K, V> {
    private final K key;
    private V value;

    /**
     * Constructor for Parameterized type public GXSimpleEntry(K key, V value)
     * 
     * @param forKey
     *            Key
     * @param forValue
     *            Value
     */
    public GXSimpleEntry(final K forKey, final V forValue) {
        this.key = forKey;
        this.value = forValue;
    }

    // @Override
    public K getKey() {
        return key;
    }

    // @Override
    public V getValue() {
        return value;
    }

    // @Override
    public V setValue(final V forValue) {
        V old = value;
        value = forValue;
        return old;
    }
}
